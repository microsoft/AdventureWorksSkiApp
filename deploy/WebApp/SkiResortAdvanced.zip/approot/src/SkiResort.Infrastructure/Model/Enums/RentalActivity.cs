﻿
namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum RentalActivity
    {
        Ski = 0,
        Snowboard = 1
    }
}
