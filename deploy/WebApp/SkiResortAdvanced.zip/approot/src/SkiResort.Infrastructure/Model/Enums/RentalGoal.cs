﻿
namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum RentalGoal
    {
        Unknown = 0,
        Demo = 1,
        Performance = 2,
        Sport = 3,
    }
}
