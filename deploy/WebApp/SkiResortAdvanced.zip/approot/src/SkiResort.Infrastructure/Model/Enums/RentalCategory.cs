﻿namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum RentalCategory
    {
        Unknown = 0,
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3
    }
}
