﻿using System;

namespace AdventureWorks.SkiResort.Infrastructure.Model
{
    public class Holiday
    {
        public DateTimeOffset Date { get; set; }
    }
}
