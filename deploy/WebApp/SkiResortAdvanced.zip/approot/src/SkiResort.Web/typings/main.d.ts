/// <reference path="main\ambient\angular-ui-router\angular-ui-router.d.ts" />
/// <reference path="main\ambient\angular\angular.d.ts" />
/// <reference path="main\ambient\ionic\ionic.d.ts" />
/// <reference path="main\ambient\jquery\jquery.d.ts" />
/// <reference path="main\ambient\lodash\lodash.d.ts" />
