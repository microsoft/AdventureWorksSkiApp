/// <reference path="browser\ambient\angular-ui-router\angular-ui-router.d.ts" />
/// <reference path="browser\ambient\angular\angular.d.ts" />
/// <reference path="browser\ambient\ionic\ionic.d.ts" />
/// <reference path="browser\ambient\jquery\jquery.d.ts" />
/// <reference path="browser\ambient\lodash\lodash.d.ts" />
