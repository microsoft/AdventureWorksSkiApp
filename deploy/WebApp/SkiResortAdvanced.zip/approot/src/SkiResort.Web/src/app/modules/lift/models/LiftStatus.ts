module SkiResort.App.Lift.Models {
    'use strict';

    export enum LiftStatus {
        Unknown = 0,
        Open = 1,
        Closed = 2
    }
}
