/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Lift {
        angular.module('app.lift', []);
    }
}
