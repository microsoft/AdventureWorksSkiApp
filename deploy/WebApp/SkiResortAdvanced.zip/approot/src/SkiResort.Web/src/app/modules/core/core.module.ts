/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Core {
        angular.module('app.core', []);
    }
}
