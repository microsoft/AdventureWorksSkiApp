/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Home {
        angular.module('app.home', []);
    }
}
