module SkiResort.App.Rental.Models {
    'use strict';

    export enum RentalActivity {
        Ski = 0,
        Snowboard = 1
    }
}
