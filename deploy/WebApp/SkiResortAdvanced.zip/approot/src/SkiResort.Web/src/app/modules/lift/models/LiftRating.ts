module SkiResort.App.Lift.Models {
    'use strict';

    export enum LiftRating {
        Unknown = 0,
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3
    }
}
