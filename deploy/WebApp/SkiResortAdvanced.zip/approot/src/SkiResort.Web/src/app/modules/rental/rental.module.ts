/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Rental {
        angular.module('app.rental', []);
    }
}
