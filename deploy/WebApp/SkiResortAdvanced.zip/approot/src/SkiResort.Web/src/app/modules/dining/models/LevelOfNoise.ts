module SkiResort.App.Dining.Models {
    'use strict';

    export enum LevelOfNoise {
        Unknown = 0,
        Low = 1,
        Medium = 2,
        Loud = 3
    }
}
