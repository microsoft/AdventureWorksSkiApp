/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Auth {
        angular.module('app.auth', []);
    }
}
