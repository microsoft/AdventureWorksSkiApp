module SkiResort.App.Rental.Models {
    'use strict';

    export enum RentalCategory {
        Unknown = 0,
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3
    }
}
