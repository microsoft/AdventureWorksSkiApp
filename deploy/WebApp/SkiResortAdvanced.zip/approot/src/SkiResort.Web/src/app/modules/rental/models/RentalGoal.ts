module SkiResort.App.Rental.Models {
    'use strict';

    export enum RentalGoal {
        Unknown = 0,
        Demo = 1,
        Performance = 2,
        Sport = 3,
    }
}
