/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    'use strict';
    var App;
    (function (App) {
        angular.module('app', [
            'ionic',
            'app.core',
            'app.auth',
            'app.home',
            'app.lift',
            'app.dining',
            'app.rental'
        ]);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        run.$inject = ["$ionicPlatform", "$log"];
        function run($ionicPlatform, $log) {
            $ionicPlatform.ready(deviceReady.call(this, $log));
        }
        function deviceReady($log) {
            $log.info('Device Ready');
        }
        angular.module('app')
            .run(run);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Auth;
        (function (Auth) {
            angular.module('app.auth', []);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Core;
        (function (Core) {
            angular.module('app.core', []);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Dining;
        (function (Dining) {
            angular.module('app.dining', []);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Home;
        (function (Home) {
            angular.module('app.home', []);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Rental;
        (function (Rental) {
            angular.module('app.rental', []);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Lift;
        (function (Lift) {
            angular.module('app.lift', []);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.login', {
                    url: '/login',
                    views: {
                        'content': {
                            controller: 'LoginController',
                            controllerAs: '$ctrl',
                            templateUrl: 'auth/templates/login.template.html',
                        }
                    }
                });
            }
            angular.module('app.auth')
                .config(routingConfiguration);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            ionicConfiguration.$inject = ["$ionicConfigProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app', {
                    url: '',
                    abstract: true,
                    controller: 'MenuController',
                    controllerAs: '$ctrl',
                    templateUrl: 'core/templates/menu.template.html'
                });
            }
            function ionicConfiguration($ionicConfigProvider) {
                $ionicConfigProvider.scrolling.jsScrolling(false);
            }
            angular.module('app.core')
                .config(routingConfiguration)
                .config(ionicConfiguration);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.dining-list', {
                    url: '/dining/list',
                    views: {
                        'content': {
                            controller: 'DiningController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-list.template.html'
                        }
                    }
                })
                    .state('app.dining-detail', {
                    url: '/dining/detail/:id',
                    params: {
                        restaurant: null
                    },
                    views: {
                        'content': {
                            controller: 'DiningDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.dining')
                .config(routingConfiguration);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.home', {
                    url: '/home',
                    data: {
                        barColor: 'dark'
                    },
                    views: {
                        'content': {
                            controller: 'HomeController',
                            controllerAs: '$ctrl',
                            templateUrl: 'home/templates/home.template.html',
                        }
                    }
                });
                $urlRouterProvider.otherwise('/home');
            }
            angular.module('app.home')
                .config(routingConfiguration);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.rentals', {
                    cache: false,
                    url: '/rentals',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/rentals.template.html',
                            controller: 'RentalsController',
                            controllerAs: '$ctrl'
                        }
                    }
                })
                    .state('app.rental-detail', {
                    cache: false,
                    url: '/rental/:rentalId',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/new-reservation-wrapper.template.html',
                            controller: 'NewReservationController',
                            controllerAs: 'tabCtrl'
                        }
                    }
                });
            }
            angular.module('app.rental')
                .config(routingConfiguration);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.lift-status-list', {
                    url: '/lift/status/list',
                    views: {
                        'content': {
                            controller: 'LiftStatusListController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-list.template.html',
                        }
                    }
                })
                    .state('app.lift-status-detail', {
                    url: '/lift/status/detail/:liftId',
                    views: {
                        'content': {
                            controller: 'LiftStatusDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.lift')
                .config(routingConfiguration);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Auth.Models || (Auth.Models = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                var SummaryInfo = (function () {
                    function SummaryInfo() {
                    }
                    return SummaryInfo;
                }());
                Models.SummaryInfo = SummaryInfo;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                (function (Weather) {
                    Weather[Weather["Unknown"] = 0] = "Unknown";
                    Weather[Weather["Snowing"] = 1] = "Snowing";
                    Weather[Weather["Rainy"] = 2] = "Rainy";
                    Weather[Weather["Cloudy"] = 3] = "Cloudy";
                    Weather[Weather["Sunny"] = 4] = "Sunny";
                })(Models.Weather || (Models.Weather = {}));
                var Weather = Models.Weather;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LevelOfNoise) {
                    LevelOfNoise[LevelOfNoise["Unknown"] = 0] = "Unknown";
                    LevelOfNoise[LevelOfNoise["Low"] = 1] = "Low";
                    LevelOfNoise[LevelOfNoise["Medium"] = 2] = "Medium";
                    LevelOfNoise[LevelOfNoise["Loud"] = 3] = "Loud";
                })(Models.LevelOfNoise || (Models.LevelOfNoise = {}));
                var LevelOfNoise = Models.LevelOfNoise;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                var Restaurant = (function () {
                    function Restaurant() {
                    }
                    return Restaurant;
                }());
                Models.Restaurant = Restaurant;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Lift = (function () {
                    function Lift() {
                    }
                    Lift.prototype.serialize = function (data) {
                        this.liftId = data.liftId;
                        this.name = data.name;
                        this.rating = data.rating;
                        this.status = data.status;
                        this.latitude = data.latitude;
                        this.longitude = data.longitude;
                        this.stayAway = data.stayAway;
                        this.waitingTime = data.waitingTime;
                        this.closedReason = data.closedReason;
                        return this;
                    };
                    Lift.prototype.deserialize = function () {
                        return {
                            liftId: this.liftId,
                            name: this.name,
                            rating: this.rating,
                            status: this.status,
                            latitude: this.latitude,
                            longitude: this.longitude,
                            stayAway: this.stayAway,
                            waitingTime: this.waitingTime,
                            closedReason: this.closedReason
                        };
                    };
                    return Lift;
                }());
                Models.Lift = Lift;
            })(Models = Lift_1.Models || (Lift_1.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftRating) {
                    LiftRating[LiftRating["Unknown"] = 0] = "Unknown";
                    LiftRating[LiftRating["Beginner"] = 1] = "Beginner";
                    LiftRating[LiftRating["Intermediate"] = 2] = "Intermediate";
                    LiftRating[LiftRating["Advanced"] = 3] = "Advanced";
                })(Models.LiftRating || (Models.LiftRating = {}));
                var LiftRating = Models.LiftRating;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftStatus) {
                    LiftStatus[LiftStatus["Unknown"] = 0] = "Unknown";
                    LiftStatus[LiftStatus["Open"] = 1] = "Open";
                    LiftStatus[LiftStatus["Closed"] = 2] = "Closed";
                })(Models.LiftStatus || (Models.LiftStatus = {}));
                var LiftStatus = Models.LiftStatus;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Rental = (function () {
                    function Rental() {
                    }
                    Rental.prototype.serialize = function (data) {
                        this.rentalId = data.rentalId;
                        this.userEmail = data.userEmail;
                        this.startDate = new Date(data.startDate);
                        this.endDate = new Date(data.endDate);
                        this.pickupHour = data.pickupHour;
                        this.activity = data.activity;
                        this.category = data.category;
                        this.goal = data.goal;
                        this.shoeSize = data.shoeSize;
                        this.skiSize = data.skiSize;
                        this.poleSize = data.poleSize;
                        this.totalCost = data.totalCost;
                        return this;
                    };
                    Rental.prototype.deserialize = function () {
                        return {
                            rentalId: this.rentalId,
                            userEmail: this.userEmail,
                            startDate: this.startDate.toJSON(),
                            endDate: this.endDate.toJSON(),
                            pickupHour: this.pickupHour,
                            activity: this.activity,
                            category: this.category,
                            goal: this.goal,
                            shoeSize: this.shoeSize,
                            skiSize: this.skiSize,
                            poleSize: this.poleSize,
                            totalCost: this.totalCost
                        };
                    };
                    return Rental;
                }());
                Models.Rental = Rental;
            })(Models = Rental_1.Models || (Rental_1.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalActivity) {
                    RentalActivity[RentalActivity["Ski"] = 0] = "Ski";
                    RentalActivity[RentalActivity["Snowboard"] = 1] = "Snowboard";
                })(Models.RentalActivity || (Models.RentalActivity = {}));
                var RentalActivity = Models.RentalActivity;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalCategory) {
                    RentalCategory[RentalCategory["Unknown"] = 0] = "Unknown";
                    RentalCategory[RentalCategory["Beginner"] = 1] = "Beginner";
                    RentalCategory[RentalCategory["Intermediate"] = 2] = "Intermediate";
                    RentalCategory[RentalCategory["Advanced"] = 3] = "Advanced";
                })(Models.RentalCategory || (Models.RentalCategory = {}));
                var RentalCategory = Models.RentalCategory;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalGoal) {
                    RentalGoal[RentalGoal["Unknown"] = 0] = "Unknown";
                    RentalGoal[RentalGoal["Demo"] = 1] = "Demo";
                    RentalGoal[RentalGoal["Performance"] = 2] = "Performance";
                    RentalGoal[RentalGoal["Sport"] = 3] = "Sport";
                })(Models.RentalGoal || (Models.RentalGoal = {}));
                var RentalGoal = Models.RentalGoal;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LoginController = (function () {
                    LoginController.$inject = ["authService", "navigationService"];
                    function LoginController(authService, navigationService) {
                        this.authService = authService;
                        this.navigationService = navigationService;
                        this.loginData = {};
                        this.wrongPassword = false;
                        this.loading = false;
                    }
                    LoginController.prototype.login = function () {
                        var _this = this;
                        this.loading = true;
                        this.wrongPassword = false;
                        if (this.loginForm.$valid) {
                            this.authService.login(this.loginData.username, this.loginData.password)
                                .then(function () {
                                _this.navigationService.closeLogin();
                            })
                                .catch(function () {
                                _this.wrongPassword = true;
                            })
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    return LoginController;
                }());
                angular.module('app.auth')
                    .controller('LoginController', LoginController);
            })(Controllers = Auth.Controllers || (Auth.Controllers = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthImageService = (function () {
                    AuthImageService.$inject = ["$q", "authAPI", "currentUserService", "configService"];
                    function AuthImageService($q, authAPI, currentUserService, configService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                        this.configService = configService;
                    }
                    AuthImageService.prototype.get = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "users/photo/" + id;
                    };
                    return AuthImageService;
                }());
                Services.AuthImageService = AuthImageService;
                angular.module('app.auth')
                    .service('authImageService', AuthImageService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthAPI = (function () {
                    AuthAPI.$inject = ["$http", "configService", "$httpParamSerializerJQLike"];
                    function AuthAPI($http, configService, $httpParamSerializerJQLike) {
                        this.$http = $http;
                        this.configService = configService;
                        this.$httpParamSerializerJQLike = $httpParamSerializerJQLike;
                    }
                    AuthAPI.prototype.login = function (username, password) {
                        var request = {
                            url: this.configService.API.URL + "connect/token",
                            method: 'POST',
                            data: this.$httpParamSerializerJQLike({
                                grant_type: this.configService.Authentication.GrantType,
                                client_id: this.configService.Authentication.ClientID,
                                client_secret: this.configService.Authentication.ClientSecret,
                                scope: this.configService.Authentication.Scope,
                                username: username,
                                password: password
                            }),
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            }
                        };
                        return this.$http(request);
                    };
                    return AuthAPI;
                }());
                Services.AuthAPI = AuthAPI;
                angular.module('app.auth')
                    .service('authAPI', AuthAPI);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthService = (function () {
                    AuthService.$inject = ["$q", "authAPI", "currentUserService"];
                    function AuthService($q, authAPI, currentUserService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                    }
                    AuthService.prototype.login = function (username, password) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.authAPI.login(username, password)
                                .then(function (response) {
                                _this.currentUserService.accessToken = response.data.access_token;
                                return _this.currentUserService.getInfo();
                            })
                                .then(function () {
                                resolve();
                            })
                                .catch(function (error) {
                                reject(error.data);
                            });
                        });
                    };
                    return AuthService;
                }());
                Services.AuthService = AuthService;
                angular.module('app.auth')
                    .service('authService', AuthService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var CURRENT_USER_STORAGE_KEY = '_currentUserData';
                var CurrentUserService = (function () {
                    CurrentUserService.$inject = ["$q", "$rootScope", "$http", "configService", "$log"];
                    function CurrentUserService($q, $rootScope, $http, configService, $log) {
                        this.$q = $q;
                        this.$rootScope = $rootScope;
                        this.$http = $http;
                        this.configService = configService;
                        this.$log = $log;
                        this.accessToken = null;
                        this.currentUser = null;
                        this.load();
                        if (this.accessToken) {
                            this.getInfo();
                        }
                    }
                    CurrentUserService.prototype.save = function () {
                        this.$log.info('CurrentUserService saving to LocalStorage');
                        var currentUserCopy = angular.copy(this.currentUser);
                        currentUserCopy.photo = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({
                            accessToken: this.accessToken,
                            currentUser: currentUserCopy
                        }));
                        this.$log.info('- Successfully saved');
                    };
                    CurrentUserService.prototype.load = function () {
                        this.$log.info('CurrentUserService loading from LocalStorage');
                        var storedRawData = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
                        if (storedRawData) {
                            var storedData = JSON.parse(storedRawData);
                            this.accessToken = storedData.accessToken;
                            this.currentUser = storedData.currentUser;
                            this.$rootScope.currentUser = this.currentUser;
                            this.$log.info('- Successfully loaded');
                        }
                        else {
                            this.$log.info('- LocalStorage is empty');
                        }
                    };
                    CurrentUserService.prototype.reset = function () {
                        this.$log.info('CurrentUserService resetting LocalStorage');
                        this.accessToken = null;
                        this.currentUser = null;
                        this.$rootScope.currentUser = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({}));
                        this.$log.info('- Done');
                    };
                    CurrentUserService.prototype.getInfo = function () {
                        var _this = this;
                        this.$log.info('CurrentUserService getting information');
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "users/user",
                            method: 'GET',
                            headers: {
                                'Authorization': "Bearer " + this.accessToken
                            }
                        };
                        return this.$http(request)
                            .then(function (response) {
                            _this.$log.info('- Information getted successfully');
                            _this.currentUser = response.data;
                            _this.$rootScope.currentUser = _this.currentUser;
                            _this.save();
                        })
                            .catch(function () {
                            _this.reset();
                            _this.$log.warn('- Something went wrong while getting information');
                        });
                    };
                    return CurrentUserService;
                }());
                Services.CurrentUserService = CurrentUserService;
                angular.module('app.auth')
                    .service('currentUserService', CurrentUserService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var MenuController = (function () {
                    MenuController.$inject = ["$ionicSideMenuDelegate", "$state", "currentUserService"];
                    function MenuController($ionicSideMenuDelegate, $state, currentUserService) {
                        this.$ionicSideMenuDelegate = $ionicSideMenuDelegate;
                        this.$state = $state;
                        this.currentUserService = currentUserService;
                    }
                    MenuController.prototype.navigateTo = function (toStateName) {
                        this.$state.go(toStateName);
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    MenuController.prototype.logout = function () {
                        this.currentUserService.reset();
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    return MenuController;
                }());
                angular.module('app.core')
                    .controller('MenuController', MenuController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var Weather = Core.Models.Weather;
                var SummaryInfoController = (function () {
                    SummaryInfoController.$inject = ["summaryInfoAPI", "$state"];
                    function SummaryInfoController(summaryInfoAPI, $state) {
                        var _this = this;
                        this.summaryInfoAPI = summaryInfoAPI;
                        this.$state = $state;
                        summaryInfoAPI.get().then(function (summaryInfo) {
                            _this.summaryInfo = summaryInfo;
                        });
                    }
                    SummaryInfoController.prototype.getWeather = function (id) {
                        return Weather[id];
                    };
                    return SummaryInfoController;
                }());
                angular.module('app.core')
                    .controller('SummaryInfoController', SummaryInfoController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function AvatarDirective() {
                    function setBackgroundImage(element, url) {
                        element.attr('style', 'background-image: url(\'' + url + '\');');
                    }
                    function link(scope, element, attr) {
                        element.addClass('ski-avatar');
                        attr.$observe('skiAvatar', function () {
                            setBackgroundImage(element, attr.skiAvatar);
                        });
                    }
                    return {
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiAvatar', AvatarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var NavBarController = (function () {
                    NavBarController.$inject = ["navigationService"];
                    function NavBarController(navigationService) {
                        this.navigationService = navigationService;
                    }
                    NavBarController.prototype.goHome = function () {
                        this.navigationService.goHome();
                    };
                    NavBarController.prototype.goBack = function () {
                        this.navigationService.goBack();
                    };
                    return NavBarController;
                }());
                function NavBarDirective() {
                    return {
                        restrict: 'A',
                        scope: {
                            title: '@',
                            logoBig: '=',
                            hamburguer: '=',
                            back: '='
                        },
                        templateUrl: 'core/templates/nav-bar.template.html',
                        controller: NavBarController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiNavBar', NavBarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function RatingDirective() {
                    var defaultClasses = 'icon ';
                    function link(scope, element) {
                        for (var i = 0; i < scope.value; i++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOn + "\"/>"));
                        }
                        for (var j = scope.value; j < scope.max; j++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOff + "\"/>"));
                        }
                    }
                    return {
                        scope: {
                            value: '@',
                            max: '@',
                            classOn: '@',
                            classOff: '@'
                        },
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiRating', RatingDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var SelectController = (function () {
                    SelectController.$inject = ["$scope", "$element"];
                    function SelectController($scope, $element) {
                        this.$scope = $scope;
                        this.$element = $element;
                        this.classes = {
                            modalOpened: 'ski-select-modal--opened'
                        };
                        this.selectors = {
                            modal: '.ski-select-modal'
                        };
                    }
                    SelectController.prototype.showModal = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$element.find(this.selectors.modal).addClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.closeModal = function () {
                        this.$element.find(this.selectors.modal).removeClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.updateSelection = function (option) {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$scope.model = option;
                        this.closeModal();
                    };
                    SelectController.prototype.resetSelection = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.updateSelection('');
                    };
                    return SelectController;
                }());
                function SelectDirective() {
                    return {
                        restrict: 'E',
                        scope: {
                            model: '=',
                            placeholder: '@',
                            selectOptions: '=',
                            required: '=',
                            name: '@',
                            disabled: '=',
                            hasTabs: '@'
                        },
                        templateUrl: 'core/templates/select.template.html',
                        controller: SelectController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSelect', SelectDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function SummaryInfoDirective() {
                    return {
                        scope: {},
                        restrict: 'E',
                        templateUrl: 'core/templates/summary-info.template.html',
                        controller: 'SummaryInfoController',
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSummaryInfo', SummaryInfoDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function Range() {
                    return function (input, _min, _max) {
                        var min = parseInt(_min, 10);
                        var max = parseInt(_max, 10);
                        for (var i = min; i < max; i++) {
                            input.push(i);
                        }
                        return input;
                    };
                }
                angular.module('app.rental')
                    .filter('skiRange', Range);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var ConfigService = (function () {
                    ConfigService.$inject = ["$log"];
                    function ConfigService($log) {
                        this.General = {
                            FakeGeolocation: true,
                            Geolocation: {
                                latitude: 40.722846,
                                longitude: -74.007325
                            }
                        };
                        this.API = {
                            URL: '/',
                            Path: 'api/'
                        };
                        this.Authentication = {
                            GrantType: 'password',
                            ClientID: 'SkyResort',
                            ClientSecret: 'secret',
                            Scope: 'api'
                        };
                        $log.info('ConfigService initialized');
                        if (ionic.Platform.isWebView()) {
                            $log.info(' - WebView detected');
                            this.API.URL = '';
                        }
                        else {
                            $log.info('- Browser detected');
                        }
                    }
                    return ConfigService;
                }());
                Services.ConfigService = ConfigService;
                angular.module('app.core')
                    .service('configService', ConfigService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var PI180 = 0.017453292519943295; // (Math.PI/180)
                var GeoService = (function () {
                    GeoService.$inject = ["$q", "configService", "$log"];
                    function GeoService($q, configService, $log) {
                        this.$q = $q;
                        this.configService = configService;
                        this.$log = $log;
                    }
                    GeoService.prototype.geolocationApiAvailable = function () {
                        return (navigator.geolocation && navigator.geolocation.getCurrentPosition);
                    };
                    GeoService.prototype.getPosition = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.$log.info('Geolocation requested');
                            if (_this.configService.General.FakeGeolocation) {
                                _this.$log.info('- Returning fake geolocation');
                                resolve(_this.configService.General.Geolocation);
                            }
                            else if (_this.geolocationApiAvailable()) {
                                navigator.geolocation.getCurrentPosition(function (result) {
                                    resolve({
                                        latitude: result.coords.latitude,
                                        longitude: result.coords.longitude
                                    });
                                }, function () {
                                    reject();
                                });
                            }
                            else {
                                _this.$log.warn('- Geolocation API not available');
                                reject();
                            }
                        });
                    };
                    GeoService.prototype.getDistanceBetween = function (a, b) {
                        var p = PI180;
                        var c = Math.cos;
                        var r = 0.5 - c((a.latitude - b.latitude) * p) / 2 + c(b.latitude * p) *
                            c(a.latitude * p) * (1 - c((a.longitude - b.longitude) * p)) / 2;
                        var result = (12742 * Math.asin(Math.sqrt(r)) * 0.621371); // 2 * R; R = 6371 km
                        return Math.round(result * 1e2) / 1e2;
                    };
                    return GeoService;
                }());
                Services.GeoService = GeoService;
                angular.module('app.core')
                    .service('geoService', GeoService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var NavigationService = (function () {
                    NavigationService.$inject = ["$state", "$ionicHistory"];
                    function NavigationService($state, $ionicHistory) {
                        this.$state = $state;
                        this.$ionicHistory = $ionicHistory;
                    }
                    NavigationService.prototype.openLogin = function () {
                        var baseUrl = location.href.replace(location.hash, '');
                        location.replace(baseUrl + '#/login');
                    };
                    NavigationService.prototype.closeLogin = function () {
                        var baseUrl = location.href.replace(location.hash, '');
                        location.replace(baseUrl + '#/home');
                    };
                    NavigationService.prototype.goHome = function () {
                        this.$ionicHistory.nextViewOptions({ disableBack: true, historyRoot: true });
                        this.$state.go('app.home');
                    };
                    NavigationService.prototype.goBack = function () {
                        if (location.hash === "#/login") {
                            this.closeLogin();
                        }
                        else {
                            if (ionic.Platform['is']('browser')) {
                                window.history.back();
                            }
                            else {
                                this.$ionicHistory.goBack();
                            }
                        }
                    };
                    return NavigationService;
                }());
                Services.NavigationService = NavigationService;
                angular.module('app.core')
                    .service('navigationService', NavigationService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var SummaryInfoAPI = (function () {
                    SummaryInfoAPI.$inject = ["$q", "$http", "configService"];
                    function SummaryInfoAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    SummaryInfoAPI.prototype.get = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "summaries",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    return SummaryInfoAPI;
                }());
                Services.SummaryInfoAPI = SummaryInfoAPI;
                angular.module('app.core')
                    .service('summaryInfoAPI', SummaryInfoAPI);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningDetailController = (function () {
                    DiningDetailController.$inject = ["$stateParams", "diningService"];
                    function DiningDetailController($stateParams, diningService) {
                        var _this = this;
                        this.$stateParams = $stateParams;
                        this.diningService = diningService;
                        this.recommendations = [];
                        this.loading = false;
                        this.loading = true;
                        var id = $stateParams['id'];
                        if (!$stateParams['restaurant']) {
                            this.diningService.getSingle(id).then(function (restaurant) {
                                _this.restaurant = restaurant;
                                _this.getExtraInformation();
                            });
                        }
                        else {
                            this.restaurant = $stateParams['restaurant'];
                            this.getExtraInformation();
                        }
                    }
                    DiningDetailController.prototype.getExtraInformation = function () {
                        var _this = this;
                        this.diningService.getRecommendations(this.restaurant.restaurantId.toString())
                            .then(function (restaurants) {
                            _this.recommendations = restaurants;
                            _this.loading = false;
                        });
                    };
                    DiningDetailController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningDetailController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningDetailController;
                }());
                angular.module('app.dining')
                    .controller('DiningDetailController', DiningDetailController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningController = (function () {
                    DiningController.$inject = ["diningService"];
                    function DiningController(diningService) {
                        this.diningService = diningService;
                        this.getRestaurants();
                        this.fillFilters();
                        this.orderBy = '';
                    }
                    DiningController.prototype.getRestaurants = function () {
                        var _this = this;
                        this.loading = true;
                        this.diningService.getNear()
                            .then(function (restaurants) {
                            _this.restaurants = restaurants;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    DiningController.prototype.fillFilters = function () {
                        this.filters = this.diningService.getFilters();
                    };
                    DiningController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningController;
                }());
                angular.module('app.dining')
                    .controller('DiningController', DiningController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningAPI = (function () {
                    DiningAPI.$inject = ["$q", "$http", "configService"];
                    function DiningAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    DiningAPI.prototype.getAll = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getNear = function (latitude, longitude) {
                        var request = {
                            url: ((this.configService.API.URL + this.configService.API.Path) + "restaurants/nearby") +
                                ("?latitude=" + latitude) +
                                ("&longitude=" + longitude),
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getRecommendations = function (searchtext) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/recommendations/" + searchtext,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getSingle = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/" + id,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getImage = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "restaurants/photo/" + id;
                    };
                    return DiningAPI;
                }());
                Services.DiningAPI = DiningAPI;
                angular.module('app.dining')
                    .service('diningAPI', DiningAPI);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningService = (function () {
                    DiningService.$inject = ["$q", "diningAPI", "geoService"];
                    function DiningService($q, diningAPI, geoService) {
                        this.$q = $q;
                        this.diningAPI = diningAPI;
                        this.geoService = geoService;
                        this.latitude = 0;
                        this.longitude = 0;
                    }
                    DiningService.prototype.getDistance = function (latitude, longitude) {
                        return this.geoService.getDistanceBetween({ latitude: latitude, longitude: longitude }, { latitude: this.latitude, longitude: this.longitude });
                    };
                    DiningService.prototype.calculateDistances = function (restaurants) {
                        for (var i = 0, l = restaurants.length; i < l; i++) {
                            restaurants[i].distance = this.getDistance(restaurants[i].latitude, restaurants[i].longitude);
                        }
                        return restaurants;
                    };
                    DiningService.prototype.getAll = function () {
                        return this.diningAPI.getAll();
                    };
                    DiningService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve) {
                            return _this.geoService.getPosition()
                                .then(function (result) {
                                _this.latitude = result.latitude;
                                _this.longitude = result.longitude;
                                return _this.diningAPI.getNear(_this.latitude, _this.longitude).then(function (restaurants) {
                                    return resolve(_this.calculateDistances(restaurants));
                                });
                            });
                        });
                    };
                    DiningService.prototype.getRecommendations = function (_searchtext) {
                        var _this = this;
                        var searchtextSplitted = _searchtext.split(' ');
                        var searchtext = searchtextSplitted[searchtextSplitted.length - 1];
                        return this.$q(function (resolve) {
                            return _this.diningAPI.getRecommendations(searchtext).then(function (ids) {
                                var restaurants = [];
                                var promises = [];
                                for (var i = 0, l = ids.length; i < l; i++) {
                                    promises.push((function () {
                                        return _this.getSingle(ids[i]).then(function (restaurant) {
                                            restaurants.push(restaurant);
                                        });
                                    })());
                                }
                                _this.$q.all(promises).then(function () {
                                    resolve(restaurants);
                                });
                            });
                        });
                    };
                    DiningService.prototype.getSingle = function (id) {
                        return this.diningAPI.getSingle(id);
                    };
                    DiningService.prototype.getFilters = function () {
                        return [
                            { id: '-rating', label: 'Rating' },
                            { id: 'levelOfNoise', label: 'Level Noise' },
                            { id: 'priceLevel', label: 'Price' },
                            { id: 'distance', label: 'Miles Away' },
                            { id: '-familyFriendly', label: 'Family Friendly' }
                        ];
                    };
                    DiningService.prototype.getImage = function (id) {
                        return this.diningAPI.getImage(id);
                    };
                    return DiningService;
                }());
                Services.DiningService = DiningService;
                angular.module('app.dining')
                    .service('diningService', DiningService);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            var HomeController = (function () {
                HomeController.$inject = ["$scope", "authService", "authImageService", "navigationService"];
                function HomeController($scope, authService, authImageService, navigationService) {
                    this.$scope = $scope;
                    this.authService = authService;
                    this.authImageService = authImageService;
                    this.navigationService = navigationService;
                }
                HomeController.prototype.getImage = function (id) {
                    return this.authImageService.get(id);
                };
                HomeController.prototype.goLogin = function () {
                    this.navigationService.openLogin();
                };
                return HomeController;
            }());
            angular.module('app.home')
                .controller('HomeController', HomeController);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            var Directives;
            (function (Directives) {
                function HomeMenuDirective() {
                    return {
                        restrict: 'E',
                        templateUrl: 'home/templates/home-menu.template.html'
                    };
                }
                angular.module('app.home')
                    .directive('skiHomeMenu', HomeMenuDirective);
            })(Directives = Home.Directives || (Home.Directives = {}));
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var NewReservationController = (function () {
                    NewReservationController.$inject = ["$scope", "rentalService", "rentalActivities", "rentalCategories", "rentalGoals", "shoeSizes", "skiSizes", "poleSizes", "$stateParams", "pickupHours", "navigationService"];
                    function NewReservationController($scope, rentalService, rentalActivities, rentalCategories, rentalGoals, shoeSizes, skiSizes, poleSizes, $stateParams, pickupHours, navigationService) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.rentalActivities = rentalActivities;
                        this.rentalCategories = rentalCategories;
                        this.rentalGoals = rentalGoals;
                        this.shoeSizes = shoeSizes;
                        this.skiSizes = skiSizes;
                        this.poleSizes = poleSizes;
                        this.$stateParams = $stateParams;
                        this.pickupHours = pickupHours;
                        this.navigationService = navigationService;
                        this.loading = false;
                        this.highDemandAlert = false;
                        // Initialize rental
                        this.rental = new Rental.Models.Rental();
                        this.pickupHours.generateAll();
                        // If there's a rentalId, we're editing, not creating
                        if ($stateParams.rentalId) {
                            this.getRental();
                        }
                        else {
                            this.resetRental();
                        }
                        // Set the todayDated, used as 'min' value for startDate
                        $scope.todayDate = new Date();
                        $scope.todayDate.setHours(0);
                        $scope.todayDate.setMinutes(0);
                        $scope.todayDate.setSeconds(0);
                        /*
                            startDate is edited in two separated inputs,
                            so, it needs to be in reparated models for
                            each ng-model
                        */
                        $scope.startDate = {
                            day: null,
                            hour: null
                        };
                        /*
                            These values (options in selectors) are mapped to the original
                            rental model using $scope.$watchCollection
                        */
                        $scope.rentalTemp = {
                            activity: null,
                            category: null,
                            poleSize: null,
                            skiSize: null
                        };
                        // Update startDate
                        $scope.$watchCollection('startDate', function () {
                            if (!$scope.startDate.day) {
                                return;
                            }
                            _this.rental.startDate = angular.copy($scope.startDate.day);
                            if ($scope.startDate.hour) {
                                _this.rental.startDate.setHours($scope.startDate.hour.hours);
                                _this.rental.startDate.setMinutes($scope.startDate.hour.minutes);
                            }
                            _this.checkHighDemand();
                        });
                        // Update activity, category, poleSize and skiSize
                        $scope.$watchCollection('rentalTemp', function () {
                            _this.rental.activity = $scope.rentalTemp.activity ? $scope.rentalTemp.activity.id : null;
                            _this.rental.category = $scope.rentalTemp.category ? $scope.rentalTemp.category.id : null;
                            _this.rental.poleSize = $scope.rentalTemp.poleSize ? $scope.rentalTemp.poleSize.id : null;
                            _this.rental.skiSize = $scope.rentalTemp.skiSize ? $scope.rentalTemp.skiSize.id : null;
                        });
                    }
                    NewReservationController.prototype.getRental = function () {
                        var _this = this;
                        this.loading = true;
                        this.rentalService.get(this.$stateParams.rentalId)
                            .then(function (rental) {
                            _this.rental = rental;
                            _this.updateTempData();
                            _this.loading = false;
                        });
                    };
                    // This will update all the temporal data used in the custom selects
                    // based on the actual rental object.
                    //
                    // This method is used at start when we're editing a rental
                    NewReservationController.prototype.updateTempData = function () {
                        var hours = this.rental.startDate.getHours();
                        var minutes = this.rental.startDate.getMinutes();
                        this.$scope.startDate = {
                            day: this.rental.startDate,
                            hour: this.pickupHours.getById((hours * 60) + minutes)
                        };
                        this.$scope.rentalTemp = {
                            activity: this.rentalActivities.getById(this.rental.activity),
                            category: this.rentalCategories.getById(this.rental.category),
                            poleSize: this.poleSizes.getById(this.rental.poleSize),
                            skiSize: this.skiSizes.getById(this.rental.skiSize)
                        };
                    };
                    // This will put the rental and all the temporal values for custom
                    // selects to null
                    //
                    // This method is used at start when we're creating a rental
                    NewReservationController.prototype.resetRental = function () {
                        this.rental = new Rental.Models.Rental();
                        for (var i in this.$scope.startDate) {
                            if (this.$scope.startDate.hasOwnProperty(i)) {
                                this.$scope.startDate[i] = null;
                            }
                        }
                        for (var x in this.$scope.rentalTemp) {
                            if (this.$scope.rentalTemp.hasOwnProperty(x)) {
                                this.$scope.rentalTemp[x] = null;
                            }
                        }
                    };
                    NewReservationController.prototype.emitSave = function () {
                        this.$scope.$emit('rental_saved');
                    };
                    NewReservationController.prototype.submitReservation = function () {
                        var _this = this;
                        if (this.rentalForm.$valid) {
                            this.loading = true;
                            var actionPromise = null;
                            if (this.$stateParams.rentalId) {
                                actionPromise = this.saveReservation();
                            }
                            else {
                                actionPromise = this.addReservation();
                            }
                            actionPromise
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    NewReservationController.prototype.addReservation = function () {
                        var _this = this;
                        return this.rentalService.add(this.rental)
                            .then(function () {
                            _this.resetRental();
                            _this.rentalForm.$setPristine();
                            _this.rentalForm.$setUntouched();
                            _this.emitSave();
                        });
                    };
                    NewReservationController.prototype.saveReservation = function () {
                        var _this = this;
                        return this.rentalService.save(this.rental)
                            .then(function () {
                            _this.navigationService.goBack();
                        });
                    };
                    NewReservationController.prototype.checkHighDemand = function () {
                        var _this = this;
                        this.rentalService.checkHighDemand(this.rental.startDate)
                            .then(function (result) {
                            _this.highDemandAlert = result;
                        })
                            .catch(function () {
                            // Handle error
                        });
                    };
                    NewReservationController.prototype.getCalculatedCost = function () {
                        this.rental.totalCost = 0;
                        if (this.rental.startDate && this.rental.endDate) {
                            this.rental.totalCost = 20;
                            var days = Math.floor((this.rental.endDate.getTime() - this.rental.startDate.getTime()) / 1000 / 60 / 60 / 24);
                            this.rental.totalCost = this.rental.totalCost + (days * 5);
                        }
                        return this.rental.totalCost;
                    };
                    return NewReservationController;
                }());
                angular.module('app.rental')
                    .controller('NewReservationController', NewReservationController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var RentalsController = (function () {
                    RentalsController.$inject = ["$ionicTabsDelegate", "$scope", "$stateParams"];
                    function RentalsController($ionicTabsDelegate, $scope, $stateParams) {
                        this.$ionicTabsDelegate = $ionicTabsDelegate;
                        this.$scope = $scope;
                        this.$stateParams = $stateParams;
                        $scope.$on('rental_saved', function () {
                            $ionicTabsDelegate.$getByHandle('section-tabs').select(0);
                            $scope.$broadcast('update_reservation_list');
                        });
                    }
                    return RentalsController;
                }());
                Controllers.RentalsController = RentalsController;
                angular.module('app.rental')
                    .controller('RentalsController', RentalsController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var ReservationListController = (function () {
                    ReservationListController.$inject = ["$scope", "rentalService", "$state", "$timeout"];
                    function ReservationListController($scope, rentalService, $state, $timeout) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.$state = $state;
                        this.$timeout = $timeout;
                        this.showMessage = false;
                        this.getRentals();
                        $scope.$on('update_reservation_list', function () {
                            _this.getRentals()
                                .finally(function () {
                                _this.showMessage = true;
                            });
                        });
                    }
                    ReservationListController.prototype.getRentals = function () {
                        var _this = this;
                        this.loading = true;
                        return this.rentalService.getAll()
                            .then(function (data) {
                            _this.rentals = data;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    ReservationListController.prototype.navigateToRental = function (rental) {
                        var _this = this;
                        this.navigatingRental = rental;
                        this.$timeout(function () {
                            _this.$state.go('app.rental-detail', { rentalId: rental.rentalId });
                        }, 100);
                    };
                    return ReservationListController;
                }());
                angular.module('app.rental')
                    .controller('ReservationListController', ReservationListController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalActivityFilter() {
                    return function (input) {
                        return Rental.Models.RentalActivity[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalActivity', RentalActivityFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalCategoryFilter() {
                    return function (input) {
                        return Rental.Models.RentalCategory[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalCategory', RentalCategoryFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var PickupHours = (function () {
                    function PickupHours() {
                        this.all = [];
                    }
                    PickupHours.prototype.getById = function (i) {
                        var _hours = Math.floor(i / 60);
                        var _minutes = i - (_hours * 60);
                        var hours = _hours;
                        var minutes = _minutes;
                        var mer = 'am';
                        if (hours > 12) {
                            hours = hours - 12;
                            mer = 'pm';
                        }
                        var hours_str = hours.toString();
                        var minutes_str = minutes.toString();
                        if (hours_str.length === 1) {
                            hours_str = '0' + hours_str;
                        }
                        if (minutes_str.length === 1) {
                            minutes_str = '0' + minutes_str;
                        }
                        return {
                            id: i,
                            label: hours_str + ":" + minutes_str + " " + mer,
                            hours: _hours,
                            minutes: _minutes
                        };
                    };
                    PickupHours.prototype.generateAll = function () {
                        var result = [];
                        var minMinutes = 360;
                        var maxMinutes = 1200;
                        var steps = 15;
                        for (var i = minMinutes; i <= maxMinutes; i = i + steps) {
                            result.push(this.getById(i));
                        }
                        this.all = result;
                    };
                    return PickupHours;
                }());
                Services.PickupHours = PickupHours;
                angular.module('app.rental')
                    .service('pickupHours', PickupHours);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function PoleSizes() {
                    var result = [];
                    for (var i = 32; i <= 57; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.PoleSizes = PoleSizes;
                angular.module('app.rental')
                    .service('poleSizes', PoleSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalActivities() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalActivity[id] }); },
                        all: Object.keys(Rental.Models.RentalActivity)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i); })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalActivity[i] }); })
                    };
                }
                Services.RentalActivities = RentalActivities;
                angular.module('app.rental')
                    .service('rentalActivities', RentalActivities);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalCategories() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalCategory[id] }); },
                        all: Object.keys(Rental.Models.RentalCategory)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i) && i !== 0; })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalCategory[i] }); })
                    };
                }
                Services.RentalCategories = RentalCategories;
                angular.module('app.rental')
                    .service('rentalCategories', RentalCategories);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalGoals() {
                    return Object.keys(Rental.Models.RentalGoal)
                        .map(function (i) { return parseInt(i, 10); })
                        .filter(function (i) { return !isNaN(i); })
                        .map(function (i) { return ({ id: i, label: Rental.Models.RentalGoal[i] }); });
                }
                Services.RentalGoals = RentalGoals;
                angular.module('app.rental')
                    .service('rentalGoals', RentalGoals);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalAPI = (function () {
                    RentalAPI.$inject = ["$q", "$http", "configService"];
                    function RentalAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    RentalAPI.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals/" + rentalId,
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.add = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'POST',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.save = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'PUT',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.checkHighDemand = function (date) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals/check_high_demand?date=" + date,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return RentalAPI;
                }());
                Services.RentalAPI = RentalAPI;
                angular.module('app.rental')
                    .service('rentalAPI', RentalAPI);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalService = (function () {
                    RentalService.$inject = ["$q", "rentalAPI", "geoService"];
                    function RentalService($q, rentalAPI, geoService) {
                        this.$q = $q;
                        this.rentalAPI = rentalAPI;
                        this.geoService = geoService;
                    }
                    RentalService.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.get(rentalId)
                                .then(function (response) {
                                resolve(new Rental.Models.Rental().serialize(response.data));
                            });
                        });
                    };
                    RentalService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Rental.Models.Rental().serialize(item);
                                }));
                            });
                        });
                    };
                    RentalService.prototype.add = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.add(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.save = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.save(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.checkHighDemand = function (date) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.checkHighDemand(date.toISOString())
                                .then(function (response) {
                                resolve(response.data);
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    return RentalService;
                }());
                Services.RentalService = RentalService;
                angular.module('app.rental')
                    .service('rentalService', RentalService);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function ShoeSizes() {
                    return [1, 2, 3, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5,
                        11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15, 15.5, 16, 16.5];
                }
                Services.ShoeSizes = ShoeSizes;
                angular.module('app.rental')
                    .service('shoeSizes', ShoeSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function SkiSizes() {
                    var result = [];
                    for (var i = 115; i <= 200; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.SkiSizes = SkiSizes;
                angular.module('app.rental')
                    .service('skiSizes', SkiSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusDetailController = (function () {
                    LiftStatusDetailController.$inject = ["liftService", "$stateParams", "geoService", "$scope"];
                    function LiftStatusDetailController(liftService, $stateParams, geoService, $scope) {
                        var _this = this;
                        this.liftService = liftService;
                        this.$stateParams = $stateParams;
                        this.geoService = geoService;
                        this.$scope = $scope;
                        this.loading = false;
                        this.userGeolocation = null;
                        this.distance = null;
                        this.getLift();
                        $scope.$watch(function () {
                            _this.getDistance();
                        });
                    }
                    LiftStatusDetailController.prototype.getLift = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.get(this.$stateParams.liftId)
                            .then(function (lift) {
                            _this.lift = lift;
                        })
                            .catch(function () {
                            // Handle error
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusDetailController.prototype.getDistance = function () {
                        var _this = this;
                        if (this.userGeolocation) {
                            this.calcDistance();
                        }
                        else {
                            this.geoService.getPosition()
                                .then(function (data) {
                                _this.userGeolocation = data;
                                _this.calcDistance();
                            });
                        }
                    };
                    LiftStatusDetailController.prototype.calcDistance = function () {
                        if (this.lift) {
                            this.distance = this.geoService.getDistanceBetween(this.userGeolocation, { latitude: this.lift.latitude, longitude: this.lift.longitude });
                        }
                    };
                    return LiftStatusDetailController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusDetailController', LiftStatusDetailController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusListController = (function () {
                    LiftStatusListController.$inject = ["liftService"];
                    function LiftStatusListController(liftService) {
                        this.liftService = liftService;
                        this.getLifts();
                    }
                    LiftStatusListController.prototype.getLifts = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.getNear()
                            .then(function (data) {
                            _this.digestLifts(data);
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusListController.prototype.digestLifts = function (lifts) {
                        var _this = this;
                        this.openLifts = [];
                        this.closedLifts = [];
                        lifts.forEach(function (lift) {
                            if (lift.status === Lift.Models.LiftStatus.Open) {
                                _this.openLifts.push(lift);
                            }
                            else if (lift.status === Lift.Models.LiftStatus.Closed) {
                                _this.closedLifts.push(lift);
                            }
                        });
                    };
                    return LiftStatusListController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusListController', LiftStatusListController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftAPI = (function () {
                    LiftAPI.$inject = ["$q", "$http", "configService"];
                    function LiftAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    LiftAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "lifts",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    LiftAPI.prototype.getNear = function (latitude, longitude) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: ((_this.configService.API.URL + _this.configService.API.Path) + "lifts/nearby") +
                                    ("?latitude=" + latitude) +
                                    ("&longitude=" + longitude),
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(resolve, reject);
                        });
                    };
                    LiftAPI.prototype.get = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "lifts/" + id,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return LiftAPI;
                }());
                Services.LiftAPI = LiftAPI;
                angular.module('app.lift')
                    .service('liftAPI', LiftAPI);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftService = (function () {
                    LiftService.$inject = ["$q", "liftAPI", "geoService"];
                    function LiftService($q, liftAPI, geoService) {
                        this.$q = $q;
                        this.liftAPI = liftAPI;
                        this.geoService = geoService;
                    }
                    LiftService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            });
                        });
                    };
                    LiftService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.geoService.getPosition()
                                .then(function (result) {
                                return _this.liftAPI.getNear(result.latitude, result.longitude);
                            })
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            })
                                .catch(reject);
                        });
                    };
                    LiftService.prototype.get = function (id) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.get(id)
                                .then(function (result) {
                                resolve(new Lift.Models.Lift().serialize(result.data));
                            })
                                .catch(reject);
                        });
                    };
                    return LiftService;
                }());
                Services.LiftService = LiftService;
                angular.module('app.lift')
                    .service('liftService', LiftService);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3d3d3Jvb3QvanMvYXBwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0EsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCO0lBQ0EsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osUUFBUSxPQUFPLE9BQU87WUFDbEI7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7O09BRUwsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSzs7MERBQ1o7UUFDQSxTQUFTLElBQUksZ0JBQWdCLE1BQU07WUFDL0IsZUFBZSxNQUFNLFlBQVksS0FBSyxNQUFNOztRQUVoRCxTQUFTLFlBQVksTUFBTTtZQUN2QixLQUFLLEtBQUs7O1FBRWQsUUFBUSxPQUFPO2FBQ1YsSUFBSTtPQUNWLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixRQUFRLE9BQU8sWUFBWTtXQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsUUFBUSxPQUFPLGNBQWM7V0FDOUIsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixRQUFRLE9BQU8sY0FBYztXQUM5QixTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsUUFBUSxPQUFPLFlBQVk7V0FDNUIsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07OzJFQUNiO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCO2dCQUMxQztxQkFDSyxNQUFNLGFBQWE7b0JBQ3BCLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOzs7K0VBQ2I7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sT0FBTztvQkFDZCxLQUFLO29CQUNMLFVBQVU7b0JBQ1YsWUFBWTtvQkFDWixjQUFjO29CQUNkLGFBQWE7OztZQUdyQixTQUFTLG1CQUFtQixzQkFBc0I7Z0JBQzlDLHFCQUFxQixVQUFVLFlBQVk7O1lBRS9DLFFBQVEsT0FBTztpQkFDVixPQUFPO2lCQUNQLE9BQU87V0FDYixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTs7MkVBQ2Y7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sbUJBQW1CO29CQUMxQixLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztxQkFJcEIsTUFBTSxxQkFBcUI7b0JBQzVCLEtBQUs7b0JBQ0wsUUFBUTt3QkFDSixZQUFZOztvQkFFaEIsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOztpR0FDYjtZQUNBLFNBQVMscUJBQXFCLGdCQUFnQixvQkFBb0I7Z0JBQzlEO3FCQUNLLE1BQU0sWUFBWTtvQkFDbkIsS0FBSztvQkFDTCxNQUFNO3dCQUNGLFVBQVU7O29CQUVkLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztnQkFJekIsbUJBQW1CLFVBQVU7O1lBRWpDLFFBQVEsT0FBTztpQkFDVixPQUFPO1dBQ2IsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7O2lHQUNmO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCLG9CQUFvQjtnQkFDOUQ7cUJBQ0ssTUFBTSxlQUFlO29CQUN0QixPQUFPO29CQUNQLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLGFBQWE7NEJBQ2IsWUFBWTs0QkFDWixjQUFjOzs7O3FCQUlyQixNQUFNLHFCQUFxQjtvQkFDNUIsT0FBTztvQkFDUCxLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxhQUFhOzRCQUNiLFlBQVk7NEJBQ1osY0FBYzs7Ozs7WUFLOUIsUUFBUSxPQUFPO2lCQUNWLE9BQU87V0FDYixTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTs7aUdBQ2I7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0Isb0JBQW9CO2dCQUM5RDtxQkFDSyxNQUFNLHdCQUF3QjtvQkFDL0IsS0FBSztvQkFDTCxPQUFPO3dCQUNILFdBQVc7NEJBQ1AsWUFBWTs0QkFDWixjQUFjOzRCQUNkLGFBQWE7Ozs7cUJBSXBCLE1BQU0sMEJBQTBCO29CQUNqQyxLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7Ozs7WUFLN0IsUUFBUSxPQUFPO2lCQUNWLE9BQU87V0FDYixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxlQUFlLFlBQVk7b0JBQzNCLFNBQVMsY0FBYzs7b0JBRXZCLE9BQU87O2dCQUVYLE9BQU8sY0FBYztlQUN0QixTQUFTLEtBQUssV0FBVyxLQUFLLFNBQVM7V0FDM0MsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsU0FBUztvQkFDaEIsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLFdBQVcsS0FBSztvQkFDaEMsUUFBUSxRQUFRLFlBQVksS0FBSztvQkFDakMsUUFBUSxRQUFRLFdBQVcsS0FBSzttQkFDakMsT0FBTyxZQUFZLE9BQU8sVUFBVTtnQkFDdkMsSUFBSSxVQUFVLE9BQU87ZUFDdEIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLGNBQWM7b0JBQ3JCLGFBQWEsYUFBYSxhQUFhLEtBQUs7b0JBQzVDLGFBQWEsYUFBYSxTQUFTLEtBQUs7b0JBQ3hDLGFBQWEsYUFBYSxZQUFZLEtBQUs7b0JBQzNDLGFBQWEsYUFBYSxVQUFVLEtBQUs7bUJBQzFDLE9BQU8saUJBQWlCLE9BQU8sZUFBZTtnQkFDakQsSUFBSSxlQUFlLE9BQU87ZUFDM0IsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxjQUFjLFlBQVk7b0JBQzFCLFNBQVMsYUFBYTs7b0JBRXRCLE9BQU87O2dCQUVYLE9BQU8sYUFBYTtlQUNyQixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxJQUFJLFFBQVEsWUFBWTtvQkFDcEIsU0FBUyxPQUFPOztvQkFFaEIsS0FBSyxVQUFVLFlBQVksVUFBVSxNQUFNO3dCQUN2QyxLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxPQUFPLEtBQUs7d0JBQ2pCLEtBQUssU0FBUyxLQUFLO3dCQUNuQixLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssWUFBWSxLQUFLO3dCQUN0QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxjQUFjLEtBQUs7d0JBQ3hCLEtBQUssZUFBZSxLQUFLO3dCQUN6QixPQUFPOztvQkFFWCxLQUFLLFVBQVUsY0FBYyxZQUFZO3dCQUNyQyxPQUFPOzRCQUNILFFBQVEsS0FBSzs0QkFDYixNQUFNLEtBQUs7NEJBQ1gsUUFBUSxLQUFLOzRCQUNiLFFBQVEsS0FBSzs0QkFDYixVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixVQUFVLEtBQUs7NEJBQ2YsYUFBYSxLQUFLOzRCQUNsQixjQUFjLEtBQUs7OztvQkFHM0IsT0FBTzs7Z0JBRVgsT0FBTyxPQUFPO2VBQ2YsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxjQUFjLEtBQUs7b0JBQ3pDLFdBQVcsV0FBVyxrQkFBa0IsS0FBSztvQkFDN0MsV0FBVyxXQUFXLGNBQWMsS0FBSzttQkFDMUMsT0FBTyxlQUFlLE9BQU8sYUFBYTtnQkFDN0MsSUFBSSxhQUFhLE9BQU87ZUFDekIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxVQUFVLEtBQUs7b0JBQ3JDLFdBQVcsV0FBVyxZQUFZLEtBQUs7bUJBQ3hDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsS0FBSyxXQUFXLEtBQUssU0FBUztXQUMzQyxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFVBQVU7WUFDakIsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLElBQUksVUFBVSxZQUFZO29CQUN0QixTQUFTLFNBQVM7O29CQUVsQixPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQU07d0JBQ3pDLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLO3dCQUMvQixLQUFLLFVBQVUsSUFBSSxLQUFLLEtBQUs7d0JBQzdCLEtBQUssYUFBYSxLQUFLO3dCQUN2QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssT0FBTyxLQUFLO3dCQUNqQixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxVQUFVLEtBQUs7d0JBQ3BCLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsT0FBTzs7b0JBRVgsT0FBTyxVQUFVLGNBQWMsWUFBWTt3QkFDdkMsT0FBTzs0QkFDSCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixXQUFXLEtBQUssVUFBVTs0QkFDMUIsU0FBUyxLQUFLLFFBQVE7NEJBQ3RCLFlBQVksS0FBSzs0QkFDakIsVUFBVSxLQUFLOzRCQUNmLFVBQVUsS0FBSzs0QkFDZixNQUFNLEtBQUs7NEJBQ1gsVUFBVSxLQUFLOzRCQUNmLFNBQVMsS0FBSzs0QkFDZCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzs7b0JBR3hCLE9BQU87O2dCQUVYLE9BQU8sU0FBUztlQUNqQixTQUFTLFNBQVMsV0FBVyxTQUFTLFNBQVM7V0FDbkQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsU0FBUyxLQUFLO29CQUM1QyxlQUFlLGVBQWUsZUFBZSxLQUFLO21CQUNuRCxPQUFPLG1CQUFtQixPQUFPLGlCQUFpQjtnQkFDckQsSUFBSSxpQkFBaUIsT0FBTztlQUM3QixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsYUFBYSxLQUFLO29CQUNoRCxlQUFlLGVBQWUsY0FBYyxLQUFLO29CQUNqRCxlQUFlLGVBQWUsa0JBQWtCLEtBQUs7b0JBQ3JELGVBQWUsZUFBZSxjQUFjLEtBQUs7bUJBQ2xELE9BQU8sbUJBQW1CLE9BQU8saUJBQWlCO2dCQUNyRCxJQUFJLGlCQUFpQixPQUFPO2VBQzdCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLENBQUMsVUFBVSxZQUFZO29CQUNuQixXQUFXLFdBQVcsYUFBYSxLQUFLO29CQUN4QyxXQUFXLFdBQVcsVUFBVSxLQUFLO29CQUNyQyxXQUFXLFdBQVcsaUJBQWlCLEtBQUs7b0JBQzVDLFdBQVcsV0FBVyxXQUFXLEtBQUs7bUJBQ3ZDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O29HQUNBLElBQUksbUJBQW1CLFlBQVk7b0JBQy9CLFNBQVMsZ0JBQWdCLGFBQWEsbUJBQW1CO3dCQUNyRCxLQUFLLGNBQWM7d0JBQ25CLEtBQUssb0JBQW9CO3dCQUN6QixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLFVBQVU7O29CQUVuQixnQkFBZ0IsVUFBVSxRQUFRLFlBQVk7d0JBQzFDLElBQUksUUFBUTt3QkFDWixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxnQkFBZ0I7d0JBQ3JCLElBQUksS0FBSyxVQUFVLFFBQVE7NEJBQ3ZCLEtBQUssWUFBWSxNQUFNLEtBQUssVUFBVSxVQUFVLEtBQUssVUFBVTtpQ0FDMUQsS0FBSyxZQUFZO2dDQUNsQixNQUFNLGtCQUFrQjs7aUNBRXZCLE1BQU0sWUFBWTtnQ0FDbkIsTUFBTSxnQkFBZ0I7O2lDQUVyQixRQUFRLFlBQVk7Z0NBQ3JCLE1BQU0sVUFBVTs7OztvQkFJNUIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsbUJBQW1CO2VBQ3BDLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7eUhBQ0EsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsSUFBSSxTQUFTLG9CQUFvQixlQUFlO3dCQUN0RSxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxVQUFVO3dCQUNmLEtBQUsscUJBQXFCO3dCQUMxQixLQUFLLGdCQUFnQjs7b0JBRXpCLGlCQUFpQixVQUFVLE1BQU0sVUFBVSxJQUFJO3dCQUMzQyxPQUFPLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLGlCQUFpQjs7b0JBRXpGLE9BQU87O2dCQUVYLFNBQVMsbUJBQW1CO2dCQUM1QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxvQkFBb0I7ZUFDbEMsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7Z0hBQ0EsSUFBSSxXQUFXLFlBQVk7b0JBQ3ZCLFNBQVMsUUFBUSxPQUFPLGVBQWUsNEJBQTRCO3dCQUMvRCxLQUFLLFFBQVE7d0JBQ2IsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssNkJBQTZCOztvQkFFdEMsUUFBUSxVQUFVLFFBQVEsVUFBVSxVQUFVLFVBQVU7d0JBQ3BELElBQUksVUFBVTs0QkFDVixLQUFLLEtBQUssY0FBYyxJQUFJLE1BQU07NEJBQ2xDLFFBQVE7NEJBQ1IsTUFBTSxLQUFLLDJCQUEyQjtnQ0FDbEMsWUFBWSxLQUFLLGNBQWMsZUFBZTtnQ0FDOUMsV0FBVyxLQUFLLGNBQWMsZUFBZTtnQ0FDN0MsZUFBZSxLQUFLLGNBQWMsZUFBZTtnQ0FDakQsT0FBTyxLQUFLLGNBQWMsZUFBZTtnQ0FDekMsVUFBVTtnQ0FDVixVQUFVOzs0QkFFZCxTQUFTO2dDQUNMLGdCQUFnQjs7O3dCQUd4QixPQUFPLEtBQUssTUFBTTs7b0JBRXRCLE9BQU87O2dCQUVYLFNBQVMsVUFBVTtnQkFDbkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsV0FBVztlQUN6QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzttR0FDQSxJQUFJLGVBQWUsWUFBWTtvQkFDM0IsU0FBUyxZQUFZLElBQUksU0FBUyxvQkFBb0I7d0JBQ2xELEtBQUssS0FBSzt3QkFDVixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxxQkFBcUI7O29CQUU5QixZQUFZLFVBQVUsUUFBUSxVQUFVLFVBQVUsVUFBVTt3QkFDeEQsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFFBQVEsTUFBTSxVQUFVO2lDQUN6QixLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsTUFBTSxtQkFBbUIsY0FBYyxTQUFTLEtBQUs7Z0NBQ3JELE9BQU8sTUFBTSxtQkFBbUI7O2lDQUUvQixLQUFLLFlBQVk7Z0NBQ2xCOztpQ0FFQyxNQUFNLFVBQVUsT0FBTztnQ0FDeEIsT0FBTyxNQUFNOzs7O29CQUl6QixPQUFPOztnQkFFWCxTQUFTLGNBQWM7Z0JBQ3ZCLFFBQVEsT0FBTztxQkFDVixRQUFRLGVBQWU7ZUFDN0IsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxJQUFJLDJCQUEyQjs7eUhBQy9CLElBQUksc0JBQXNCLFlBQVk7b0JBQ2xDLFNBQVMsbUJBQW1CLElBQUksWUFBWSxPQUFPLGVBQWUsTUFBTTt3QkFDcEUsS0FBSyxLQUFLO3dCQUNWLEtBQUssYUFBYTt3QkFDbEIsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLE9BQU87d0JBQ1osS0FBSyxjQUFjO3dCQUNuQixLQUFLLGNBQWM7d0JBQ25CLEtBQUs7d0JBQ0wsSUFBSSxLQUFLLGFBQWE7NEJBQ2xCLEtBQUs7OztvQkFHYixtQkFBbUIsVUFBVSxPQUFPLFlBQVk7d0JBQzVDLEtBQUssS0FBSyxLQUFLO3dCQUNmLElBQUksa0JBQWtCLFFBQVEsS0FBSyxLQUFLO3dCQUN4QyxnQkFBZ0IsUUFBUTt3QkFDeEIsYUFBYSxRQUFRLDBCQUEwQixLQUFLLFVBQVU7NEJBQzFELGFBQWEsS0FBSzs0QkFDbEIsYUFBYTs7d0JBRWpCLEtBQUssS0FBSyxLQUFLOztvQkFFbkIsbUJBQW1CLFVBQVUsT0FBTyxZQUFZO3dCQUM1QyxLQUFLLEtBQUssS0FBSzt3QkFDZixJQUFJLGdCQUFnQixhQUFhLFFBQVE7d0JBQ3pDLElBQUksZUFBZTs0QkFDZixJQUFJLGFBQWEsS0FBSyxNQUFNOzRCQUM1QixLQUFLLGNBQWMsV0FBVzs0QkFDOUIsS0FBSyxjQUFjLFdBQVc7NEJBQzlCLEtBQUssV0FBVyxjQUFjLEtBQUs7NEJBQ25DLEtBQUssS0FBSyxLQUFLOzs2QkFFZDs0QkFDRCxLQUFLLEtBQUssS0FBSzs7O29CQUd2QixtQkFBbUIsVUFBVSxRQUFRLFlBQVk7d0JBQzdDLEtBQUssS0FBSyxLQUFLO3dCQUNmLEtBQUssY0FBYzt3QkFDbkIsS0FBSyxjQUFjO3dCQUNuQixLQUFLLFdBQVcsY0FBYzt3QkFDOUIsYUFBYSxRQUFRLDBCQUEwQixLQUFLLFVBQVU7d0JBQzlELEtBQUssS0FBSyxLQUFLOztvQkFFbkIsbUJBQW1CLFVBQVUsVUFBVSxZQUFZO3dCQUMvQyxJQUFJLFFBQVE7d0JBQ1osS0FBSyxLQUFLLEtBQUs7d0JBQ2YsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7NEJBQ1IsU0FBUztnQ0FDTCxpQkFBaUIsWUFBWSxLQUFLOzs7d0JBRzFDLE9BQU8sS0FBSyxNQUFNOzZCQUNiLEtBQUssVUFBVSxVQUFVOzRCQUMxQixNQUFNLEtBQUssS0FBSzs0QkFDaEIsTUFBTSxjQUFjLFNBQVM7NEJBQzdCLE1BQU0sV0FBVyxjQUFjLE1BQU07NEJBQ3JDLE1BQU07OzZCQUVMLE1BQU0sWUFBWTs0QkFDbkIsTUFBTTs0QkFDTixNQUFNLEtBQUssS0FBSzs7O29CQUd4QixPQUFPOztnQkFFWCxTQUFTLHFCQUFxQjtnQkFDOUIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsc0JBQXNCO2VBQ3BDLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O3lIQUNBLElBQUksa0JBQWtCLFlBQVk7b0JBQzlCLFNBQVMsZUFBZSx3QkFBd0IsUUFBUSxvQkFBb0I7d0JBQ3hFLEtBQUsseUJBQXlCO3dCQUM5QixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxxQkFBcUI7O29CQUU5QixlQUFlLFVBQVUsYUFBYSxVQUFVLGFBQWE7d0JBQ3pELEtBQUssT0FBTyxHQUFHO3dCQUNmLEtBQUssdUJBQXVCLFlBQVk7O29CQUU1QyxlQUFlLFVBQVUsU0FBUyxZQUFZO3dCQUMxQyxLQUFLLG1CQUFtQjt3QkFDeEIsS0FBSyx1QkFBdUIsWUFBWTs7b0JBRTVDLE9BQU87O2dCQUVYLFFBQVEsT0FBTztxQkFDVixXQUFXLGtCQUFrQjtlQUNuQyxjQUFjLEtBQUssZ0JBQWdCLEtBQUssY0FBYztXQUMxRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7Z0JBQ0EsSUFBSSxVQUFVLEtBQUssT0FBTzs7a0dBQzFCLElBQUkseUJBQXlCLFlBQVk7b0JBQ3JDLFNBQVMsc0JBQXNCLGdCQUFnQixRQUFRO3dCQUNuRCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxpQkFBaUI7d0JBQ3RCLEtBQUssU0FBUzt3QkFDZCxlQUFlLE1BQU0sS0FBSyxVQUFVLGFBQWE7NEJBQzdDLE1BQU0sY0FBYzs7O29CQUc1QixzQkFBc0IsVUFBVSxhQUFhLFVBQVUsSUFBSTt3QkFDdkQsT0FBTyxRQUFROztvQkFFbkIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcseUJBQXlCO2VBQzFDLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLGtCQUFrQjtvQkFDdkIsU0FBUyxtQkFBbUIsU0FBUyxLQUFLO3dCQUN0QyxRQUFRLEtBQUssU0FBUyw2QkFBNkIsTUFBTTs7b0JBRTdELFNBQVMsS0FBSyxPQUFPLFNBQVMsTUFBTTt3QkFDaEMsUUFBUSxTQUFTO3dCQUNqQixLQUFLLFNBQVMsYUFBYSxZQUFZOzRCQUNuQyxtQkFBbUIsU0FBUyxLQUFLOzs7b0JBR3pDLE9BQU87d0JBQ0gsTUFBTTs7O2dCQUdkLFFBQVEsT0FBTztxQkFDVixVQUFVLGFBQWE7ZUFDN0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZOztzRkFDbkIsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsbUJBQW1CO3dCQUN6QyxLQUFLLG9CQUFvQjs7b0JBRTdCLGlCQUFpQixVQUFVLFNBQVMsWUFBWTt3QkFDNUMsS0FBSyxrQkFBa0I7O29CQUUzQixpQkFBaUIsVUFBVSxTQUFTLFlBQVk7d0JBQzVDLEtBQUssa0JBQWtCOztvQkFFM0IsT0FBTzs7Z0JBRVgsU0FBUyxrQkFBa0I7b0JBQ3ZCLE9BQU87d0JBQ0gsVUFBVTt3QkFDVixPQUFPOzRCQUNILE9BQU87NEJBQ1AsU0FBUzs0QkFDVCxZQUFZOzRCQUNaLE1BQU07O3dCQUVWLGFBQWE7d0JBQ2IsWUFBWTt3QkFDWixjQUFjOzs7Z0JBR3RCLFFBQVEsT0FBTztxQkFDVixVQUFVLGFBQWE7ZUFDN0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLGtCQUFrQjtvQkFDdkIsSUFBSSxpQkFBaUI7b0JBQ3JCLFNBQVMsS0FBSyxPQUFPLFNBQVM7d0JBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSzs0QkFDbEMsUUFBUSxPQUFPLFFBQVEsUUFBUSxtQkFBbUIsaUJBQWlCLE1BQU0sVUFBVTs7d0JBRXZGLEtBQUssSUFBSSxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxLQUFLOzRCQUMxQyxRQUFRLE9BQU8sUUFBUSxRQUFRLG1CQUFtQixpQkFBaUIsTUFBTSxXQUFXOzs7b0JBRzVGLE9BQU87d0JBQ0gsT0FBTzs0QkFDSCxPQUFPOzRCQUNQLEtBQUs7NEJBQ0wsU0FBUzs0QkFDVCxVQUFVOzt3QkFFZCxNQUFNOzs7Z0JBR2QsUUFBUSxPQUFPO3FCQUNWLFVBQVUsYUFBYTtlQUM3QixhQUFhLEtBQUssZUFBZSxLQUFLLGFBQWE7V0FDdkQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsWUFBWTs7dUZBQ25CLElBQUksb0JBQW9CLFlBQVk7b0JBQ2hDLFNBQVMsaUJBQWlCLFFBQVEsVUFBVTt3QkFDeEMsS0FBSyxTQUFTO3dCQUNkLEtBQUssV0FBVzt3QkFDaEIsS0FBSyxVQUFVOzRCQUNYLGFBQWE7O3dCQUVqQixLQUFLLFlBQVk7NEJBQ2IsT0FBTzs7O29CQUdmLGlCQUFpQixVQUFVLFlBQVksWUFBWTt3QkFDL0MsSUFBSSxLQUFLLE9BQU8sVUFBVTs0QkFDdEI7O3dCQUVKLEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxPQUFPLFNBQVMsS0FBSyxRQUFROztvQkFFbkUsaUJBQWlCLFVBQVUsYUFBYSxZQUFZO3dCQUNoRCxLQUFLLFNBQVMsS0FBSyxLQUFLLFVBQVUsT0FBTyxZQUFZLEtBQUssUUFBUTs7b0JBRXRFLGlCQUFpQixVQUFVLGtCQUFrQixVQUFVLFFBQVE7d0JBQzNELElBQUksS0FBSyxPQUFPLFVBQVU7NEJBQ3RCOzt3QkFFSixLQUFLLE9BQU8sUUFBUTt3QkFDcEIsS0FBSzs7b0JBRVQsaUJBQWlCLFVBQVUsaUJBQWlCLFlBQVk7d0JBQ3BELElBQUksS0FBSyxPQUFPLFVBQVU7NEJBQ3RCOzt3QkFFSixLQUFLLGdCQUFnQjs7b0JBRXpCLE9BQU87O2dCQUVYLFNBQVMsa0JBQWtCO29CQUN2QixPQUFPO3dCQUNILFVBQVU7d0JBQ1YsT0FBTzs0QkFDSCxPQUFPOzRCQUNQLGFBQWE7NEJBQ2IsZUFBZTs0QkFDZixVQUFVOzRCQUNWLE1BQU07NEJBQ04sVUFBVTs0QkFDVixTQUFTOzt3QkFFYixhQUFhO3dCQUNiLFlBQVk7d0JBQ1osY0FBYzs7O2dCQUd0QixRQUFRLE9BQU87cUJBQ1YsVUFBVSxhQUFhO2VBQzdCLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLHVCQUF1QjtvQkFDNUIsT0FBTzt3QkFDSCxPQUFPO3dCQUNQLFVBQVU7d0JBQ1YsYUFBYTt3QkFDYixZQUFZO3dCQUNaLGNBQWM7OztnQkFHdEIsUUFBUSxPQUFPO3FCQUNWLFVBQVUsa0JBQWtCO2VBQ2xDLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsU0FBUztnQkFDaEI7Z0JBQ0EsU0FBUyxRQUFRO29CQUNiLE9BQU8sVUFBVSxPQUFPLE1BQU0sTUFBTTt3QkFDaEMsSUFBSSxNQUFNLFNBQVMsTUFBTTt3QkFDekIsSUFBSSxNQUFNLFNBQVMsTUFBTTt3QkFDekIsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUssS0FBSzs0QkFDNUIsTUFBTSxLQUFLOzt3QkFFZixPQUFPOzs7Z0JBR2YsUUFBUSxPQUFPO3FCQUNWLE9BQU8sWUFBWTtlQUN6QixVQUFVLE9BQU8sWUFBWSxPQUFPLFVBQVU7V0FDbEQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOztzRUFDQSxJQUFJLGlCQUFpQixZQUFZO29CQUM3QixTQUFTLGNBQWMsTUFBTTt3QkFDekIsS0FBSyxVQUFVOzRCQUNYLGlCQUFpQjs0QkFDakIsYUFBYTtnQ0FDVCxVQUFVO2dDQUNWLFdBQVcsQ0FBQzs7O3dCQUdwQixLQUFLLE1BQU07NEJBQ1AsS0FBSzs0QkFDTCxNQUFNOzt3QkFFVixLQUFLLGlCQUFpQjs0QkFDbEIsV0FBVzs0QkFDWCxVQUFVOzRCQUNWLGNBQWM7NEJBQ2QsT0FBTzs7d0JBRVgsS0FBSyxLQUFLO3dCQUNWLElBQUksTUFBTSxTQUFTLGFBQWE7NEJBQzVCLEtBQUssS0FBSzs0QkFDVixLQUFLLElBQUksTUFBTTs7NkJBRWQ7NEJBQ0QsS0FBSyxLQUFLOzs7b0JBR2xCLE9BQU87O2dCQUVYLFNBQVMsZ0JBQWdCO2dCQUN6QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxpQkFBaUI7ZUFDL0IsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxJQUFJLFFBQVE7OzBGQUNaLElBQUksY0FBYyxZQUFZO29CQUMxQixTQUFTLFdBQVcsSUFBSSxlQUFlLE1BQU07d0JBQ3pDLEtBQUssS0FBSzt3QkFDVixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxPQUFPOztvQkFFaEIsV0FBVyxVQUFVLDBCQUEwQixZQUFZO3dCQUN2RCxRQUFRLFVBQVUsZUFBZSxVQUFVLFlBQVk7O29CQUUzRCxXQUFXLFVBQVUsY0FBYyxZQUFZO3dCQUMzQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sS0FBSyxLQUFLOzRCQUNoQixJQUFJLE1BQU0sY0FBYyxRQUFRLGlCQUFpQjtnQ0FDN0MsTUFBTSxLQUFLLEtBQUs7Z0NBQ2hCLFFBQVEsTUFBTSxjQUFjLFFBQVE7O2lDQUVuQyxJQUFJLE1BQU0sMkJBQTJCO2dDQUN0QyxVQUFVLFlBQVksbUJBQW1CLFVBQVUsUUFBUTtvQ0FDdkQsUUFBUTt3Q0FDSixVQUFVLE9BQU8sT0FBTzt3Q0FDeEIsV0FBVyxPQUFPLE9BQU87O21DQUU5QixZQUFZO29DQUNYOzs7aUNBR0g7Z0NBQ0QsTUFBTSxLQUFLLEtBQUs7Z0NBQ2hCOzs7O29CQUlaLFdBQVcsVUFBVSxxQkFBcUIsVUFBVSxHQUFHLEdBQUc7d0JBQ3RELElBQUksSUFBSTt3QkFDUixJQUFJLElBQUksS0FBSzt3QkFDYixJQUFJLElBQUksTUFBTSxFQUFFLENBQUMsRUFBRSxXQUFXLEVBQUUsWUFBWSxLQUFLLElBQUksRUFBRSxFQUFFLFdBQVc7NEJBQ2hFLEVBQUUsRUFBRSxXQUFXLE1BQU0sSUFBSSxFQUFFLENBQUMsRUFBRSxZQUFZLEVBQUUsYUFBYSxNQUFNO3dCQUNuRSxJQUFJLFVBQVUsUUFBUSxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU07d0JBQ2hELE9BQU8sS0FBSyxNQUFNLFNBQVMsT0FBTzs7b0JBRXRDLE9BQU87O2dCQUVYLFNBQVMsYUFBYTtnQkFDdEIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsY0FBYztlQUM1QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzs2RkFDQSxJQUFJLHFCQUFxQixZQUFZO29CQUNqQyxTQUFTLGtCQUFrQixRQUFRLGVBQWU7d0JBQzlDLEtBQUssU0FBUzt3QkFDZCxLQUFLLGdCQUFnQjs7b0JBRXpCLGtCQUFrQixVQUFVLFlBQVksWUFBWTt3QkFDaEQsSUFBSSxVQUFVLFNBQVMsS0FBSyxRQUFRLFNBQVMsTUFBTTt3QkFDbkQsU0FBUyxRQUFRLFVBQVU7O29CQUUvQixrQkFBa0IsVUFBVSxhQUFhLFlBQVk7d0JBQ2pELElBQUksVUFBVSxTQUFTLEtBQUssUUFBUSxTQUFTLE1BQU07d0JBQ25ELFNBQVMsUUFBUSxVQUFVOztvQkFFL0Isa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxLQUFLLGNBQWMsZ0JBQWdCLEVBQUUsYUFBYSxNQUFNLGFBQWE7d0JBQ3JFLEtBQUssT0FBTyxHQUFHOztvQkFFbkIsa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxJQUFJLFNBQVMsU0FBUyxXQUFXOzRCQUM3QixLQUFLOzs2QkFFSjs0QkFDRCxJQUFJLE1BQU0sU0FBUyxNQUFNLFlBQVk7Z0NBQ2pDLE9BQU8sUUFBUTs7aUNBRWQ7Z0NBQ0QsS0FBSyxjQUFjOzs7O29CQUkvQixPQUFPOztnQkFFWCxTQUFTLG9CQUFvQjtnQkFDN0IsUUFBUSxPQUFPO3FCQUNWLFFBQVEscUJBQXFCO2VBQ25DLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OytGQUNBLElBQUksa0JBQWtCLFlBQVk7b0JBQzlCLFNBQVMsZUFBZSxJQUFJLE9BQU8sZUFBZTt3QkFDOUMsS0FBSyxLQUFLO3dCQUNWLEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjs7b0JBRXpCLGVBQWUsVUFBVSxNQUFNLFlBQVk7d0JBQ3ZDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFROzRCQUNsRSxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsT0FBTzs7Z0JBRVgsU0FBUyxpQkFBaUI7Z0JBQzFCLFFBQVEsT0FBTztxQkFDVixRQUFRLGtCQUFrQjtlQUNoQyxXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCO2dCQUNBLElBQUksZUFBZSxPQUFPLE9BQU87O3dHQUNqQyxJQUFJLDBCQUEwQixZQUFZO29CQUN0QyxTQUFTLHVCQUF1QixjQUFjLGVBQWU7d0JBQ3pELElBQUksUUFBUTt3QkFDWixLQUFLLGVBQWU7d0JBQ3BCLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLGtCQUFrQjt3QkFDdkIsS0FBSyxVQUFVO3dCQUNmLEtBQUssVUFBVTt3QkFDZixJQUFJLEtBQUssYUFBYTt3QkFDdEIsSUFBSSxDQUFDLGFBQWEsZUFBZTs0QkFDN0IsS0FBSyxjQUFjLFVBQVUsSUFBSSxLQUFLLFVBQVUsWUFBWTtnQ0FDeEQsTUFBTSxhQUFhO2dDQUNuQixNQUFNOzs7NkJBR1Q7NEJBQ0QsS0FBSyxhQUFhLGFBQWE7NEJBQy9CLEtBQUs7OztvQkFHYix1QkFBdUIsVUFBVSxzQkFBc0IsWUFBWTt3QkFDL0QsSUFBSSxRQUFRO3dCQUNaLEtBQUssY0FBYyxtQkFBbUIsS0FBSyxXQUFXLGFBQWE7NkJBQzlELEtBQUssVUFBVSxhQUFhOzRCQUM3QixNQUFNLGtCQUFrQjs0QkFDeEIsTUFBTSxVQUFVOzs7b0JBR3hCLHVCQUF1QixVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUN0RCxPQUFPLEtBQUssY0FBYyxTQUFTOztvQkFFdkMsdUJBQXVCLFVBQVUsa0JBQWtCLFVBQVUsSUFBSTt3QkFDN0QsT0FBTyxhQUFhOztvQkFFeEIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsMEJBQTBCO2VBQzNDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjtnQkFDQSxJQUFJLGVBQWUsT0FBTyxPQUFPOztrRkFDakMsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsZUFBZTt3QkFDckMsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUs7d0JBQ0wsS0FBSzt3QkFDTCxLQUFLLFVBQVU7O29CQUVuQixpQkFBaUIsVUFBVSxpQkFBaUIsWUFBWTt3QkFDcEQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixLQUFLLGNBQWM7NkJBQ2QsS0FBSyxVQUFVLGFBQWE7NEJBQzdCLE1BQU0sY0FBYzs7NkJBRW5CLFFBQVEsWUFBWTs0QkFDckIsTUFBTSxVQUFVOzs7b0JBR3hCLGlCQUFpQixVQUFVLGNBQWMsWUFBWTt3QkFDakQsS0FBSyxVQUFVLEtBQUssY0FBYzs7b0JBRXRDLGlCQUFpQixVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUNoRCxPQUFPLEtBQUssY0FBYyxTQUFTOztvQkFFdkMsaUJBQWlCLFVBQVUsa0JBQWtCLFVBQVUsSUFBSTt3QkFDdkQsT0FBTyxhQUFhOztvQkFFeEIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsb0JBQW9CO2VBQ3JDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7MEZBQ0EsSUFBSSxhQUFhLFlBQVk7b0JBQ3pCLFNBQVMsVUFBVSxJQUFJLE9BQU8sZUFBZTt3QkFDekMsS0FBSyxLQUFLO3dCQUNWLEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjs7b0JBRXpCLFVBQVUsVUFBVSxTQUFTLFlBQVk7d0JBQ3JDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFROzRCQUNsRSxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVc7d0JBQ3pELElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7aUNBQzlELGVBQWU7aUNBQ2YsZ0JBQWdCOzRCQUNyQixRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLHFCQUFxQixVQUFVLFlBQVk7d0JBQzNELElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLGlDQUFpQzs0QkFDbkcsUUFBUTs7d0JBRVosT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLFVBQVUsU0FBUzs0QkFDL0MsT0FBTyxRQUFROzs7b0JBR3ZCLFVBQVUsVUFBVSxZQUFZLFVBQVUsSUFBSTt3QkFDMUMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsaUJBQWlCOzRCQUNuRixRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUN6QyxPQUFPLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLHVCQUF1Qjs7b0JBRS9GLE9BQU87O2dCQUVYLFNBQVMsWUFBWTtnQkFDckIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsYUFBYTtlQUMzQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzsrRkFDQSxJQUFJLGlCQUFpQixZQUFZO29CQUM3QixTQUFTLGNBQWMsSUFBSSxXQUFXLFlBQVk7d0JBQzlDLEtBQUssS0FBSzt3QkFDVixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssYUFBYTt3QkFDbEIsS0FBSyxXQUFXO3dCQUNoQixLQUFLLFlBQVk7O29CQUVyQixjQUFjLFVBQVUsY0FBYyxVQUFVLFVBQVUsV0FBVzt3QkFDakUsT0FBTyxLQUFLLFdBQVcsbUJBQW1CLEVBQUUsVUFBVSxVQUFVLFdBQVcsYUFBYSxFQUFFLFVBQVUsS0FBSyxVQUFVLFdBQVcsS0FBSzs7b0JBRXZJLGNBQWMsVUFBVSxxQkFBcUIsVUFBVSxhQUFhO3dCQUNoRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLElBQUksR0FBRyxLQUFLOzRCQUNoRCxZQUFZLEdBQUcsV0FBVyxLQUFLLFlBQVksWUFBWSxHQUFHLFVBQVUsWUFBWSxHQUFHOzt3QkFFdkYsT0FBTzs7b0JBRVgsY0FBYyxVQUFVLFNBQVMsWUFBWTt3QkFDekMsT0FBTyxLQUFLLFVBQVU7O29CQUUxQixjQUFjLFVBQVUsVUFBVSxZQUFZO3dCQUMxQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTOzRCQUM5QixPQUFPLE1BQU0sV0FBVztpQ0FDbkIsS0FBSyxVQUFVLFFBQVE7Z0NBQ3hCLE1BQU0sV0FBVyxPQUFPO2dDQUN4QixNQUFNLFlBQVksT0FBTztnQ0FDekIsT0FBTyxNQUFNLFVBQVUsUUFBUSxNQUFNLFVBQVUsTUFBTSxXQUFXLEtBQUssVUFBVSxhQUFhO29DQUN4RixPQUFPLFFBQVEsTUFBTSxtQkFBbUI7Ozs7O29CQUt4RCxjQUFjLFVBQVUscUJBQXFCLFVBQVUsYUFBYTt3QkFDaEUsSUFBSSxRQUFRO3dCQUNaLElBQUkscUJBQXFCLFlBQVksTUFBTTt3QkFDM0MsSUFBSSxhQUFhLG1CQUFtQixtQkFBbUIsU0FBUzt3QkFDaEUsT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTOzRCQUM5QixPQUFPLE1BQU0sVUFBVSxtQkFBbUIsWUFBWSxLQUFLLFVBQVUsS0FBSztnQ0FDdEUsSUFBSSxjQUFjO2dDQUNsQixJQUFJLFdBQVc7Z0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFJLEdBQUcsS0FBSztvQ0FDeEMsU0FBUyxLQUFLLENBQUMsWUFBWTt3Q0FDdkIsT0FBTyxNQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssVUFBVSxZQUFZOzRDQUN0RCxZQUFZLEtBQUs7Ozs7Z0NBSTdCLE1BQU0sR0FBRyxJQUFJLFVBQVUsS0FBSyxZQUFZO29DQUNwQyxRQUFROzs7OztvQkFLeEIsY0FBYyxVQUFVLFlBQVksVUFBVSxJQUFJO3dCQUM5QyxPQUFPLEtBQUssVUFBVSxVQUFVOztvQkFFcEMsY0FBYyxVQUFVLGFBQWEsWUFBWTt3QkFDN0MsT0FBTzs0QkFDSCxFQUFFLElBQUksV0FBVyxPQUFPOzRCQUN4QixFQUFFLElBQUksZ0JBQWdCLE9BQU87NEJBQzdCLEVBQUUsSUFBSSxjQUFjLE9BQU87NEJBQzNCLEVBQUUsSUFBSSxZQUFZLE9BQU87NEJBQ3pCLEVBQUUsSUFBSSxtQkFBbUIsT0FBTzs7O29CQUd4QyxjQUFjLFVBQVUsV0FBVyxVQUFVLElBQUk7d0JBQzdDLE9BQU8sS0FBSyxVQUFVLFNBQVM7O29CQUVuQyxPQUFPOztnQkFFWCxTQUFTLGdCQUFnQjtnQkFDekIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsaUJBQWlCO2VBQy9CLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiOzt5SEFDQSxJQUFJLGtCQUFrQixZQUFZO2dCQUM5QixTQUFTLGVBQWUsUUFBUSxhQUFhLGtCQUFrQixtQkFBbUI7b0JBQzlFLEtBQUssU0FBUztvQkFDZCxLQUFLLGNBQWM7b0JBQ25CLEtBQUssbUJBQW1CO29CQUN4QixLQUFLLG9CQUFvQjs7Z0JBRTdCLGVBQWUsVUFBVSxXQUFXLFVBQVUsSUFBSTtvQkFDOUMsT0FBTyxLQUFLLGlCQUFpQixJQUFJOztnQkFFckMsZUFBZSxVQUFVLFVBQVUsWUFBWTtvQkFDM0MsS0FBSyxrQkFBa0I7O2dCQUUzQixPQUFPOztZQUVYLFFBQVEsT0FBTztpQkFDVixXQUFXLGtCQUFrQjtXQUNuQyxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLG9CQUFvQjtvQkFDekIsT0FBTzt3QkFDSCxVQUFVO3dCQUNWLGFBQWE7OztnQkFHckIsUUFBUSxPQUFPO3FCQUNWLFVBQVUsZUFBZTtlQUMvQixhQUFhLEtBQUssZUFBZSxLQUFLLGFBQWE7V0FDdkQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCOztxUEFDQSxJQUFJLDRCQUE0QixZQUFZO29CQUN4QyxTQUFTLHlCQUF5QixRQUFRLGVBQWUsa0JBQWtCLGtCQUFrQixhQUFhLFdBQVcsVUFBVSxXQUFXLGNBQWMsYUFBYSxtQkFBbUI7d0JBQ3BMLElBQUksUUFBUTt3QkFDWixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssbUJBQW1CO3dCQUN4QixLQUFLLG1CQUFtQjt3QkFDeEIsS0FBSyxjQUFjO3dCQUNuQixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssV0FBVzt3QkFDaEIsS0FBSyxZQUFZO3dCQUNqQixLQUFLLGVBQWU7d0JBQ3BCLEtBQUssY0FBYzt3QkFDbkIsS0FBSyxvQkFBb0I7d0JBQ3pCLEtBQUssVUFBVTt3QkFDZixLQUFLLGtCQUFrQjs7d0JBRXZCLEtBQUssU0FBUyxJQUFJLE9BQU8sT0FBTzt3QkFDaEMsS0FBSyxZQUFZOzt3QkFFakIsSUFBSSxhQUFhLFVBQVU7NEJBQ3ZCLEtBQUs7OzZCQUVKOzRCQUNELEtBQUs7Ozt3QkFHVCxPQUFPLFlBQVksSUFBSTt3QkFDdkIsT0FBTyxVQUFVLFNBQVM7d0JBQzFCLE9BQU8sVUFBVSxXQUFXO3dCQUM1QixPQUFPLFVBQVUsV0FBVzs7Ozs7O3dCQU01QixPQUFPLFlBQVk7NEJBQ2YsS0FBSzs0QkFDTCxNQUFNOzs7Ozs7d0JBTVYsT0FBTyxhQUFhOzRCQUNoQixVQUFVOzRCQUNWLFVBQVU7NEJBQ1YsVUFBVTs0QkFDVixTQUFTOzs7d0JBR2IsT0FBTyxpQkFBaUIsYUFBYSxZQUFZOzRCQUM3QyxJQUFJLENBQUMsT0FBTyxVQUFVLEtBQUs7Z0NBQ3ZCOzs0QkFFSixNQUFNLE9BQU8sWUFBWSxRQUFRLEtBQUssT0FBTyxVQUFVOzRCQUN2RCxJQUFJLE9BQU8sVUFBVSxNQUFNO2dDQUN2QixNQUFNLE9BQU8sVUFBVSxTQUFTLE9BQU8sVUFBVSxLQUFLO2dDQUN0RCxNQUFNLE9BQU8sVUFBVSxXQUFXLE9BQU8sVUFBVSxLQUFLOzs0QkFFNUQsTUFBTTs7O3dCQUdWLE9BQU8saUJBQWlCLGNBQWMsWUFBWTs0QkFDOUMsTUFBTSxPQUFPLFdBQVcsT0FBTyxXQUFXLFdBQVcsT0FBTyxXQUFXLFNBQVMsS0FBSzs0QkFDckYsTUFBTSxPQUFPLFdBQVcsT0FBTyxXQUFXLFdBQVcsT0FBTyxXQUFXLFNBQVMsS0FBSzs0QkFDckYsTUFBTSxPQUFPLFdBQVcsT0FBTyxXQUFXLFdBQVcsT0FBTyxXQUFXLFNBQVMsS0FBSzs0QkFDckYsTUFBTSxPQUFPLFVBQVUsT0FBTyxXQUFXLFVBQVUsT0FBTyxXQUFXLFFBQVEsS0FBSzs7O29CQUcxRix5QkFBeUIsVUFBVSxZQUFZLFlBQVk7d0JBQ3ZELElBQUksUUFBUTt3QkFDWixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxjQUFjLElBQUksS0FBSyxhQUFhOzZCQUNwQyxLQUFLLFVBQVUsUUFBUTs0QkFDeEIsTUFBTSxTQUFTOzRCQUNmLE1BQU07NEJBQ04sTUFBTSxVQUFVOzs7Ozs7O29CQU94Qix5QkFBeUIsVUFBVSxpQkFBaUIsWUFBWTt3QkFDNUQsSUFBSSxRQUFRLEtBQUssT0FBTyxVQUFVO3dCQUNsQyxJQUFJLFVBQVUsS0FBSyxPQUFPLFVBQVU7d0JBQ3BDLEtBQUssT0FBTyxZQUFZOzRCQUNwQixLQUFLLEtBQUssT0FBTzs0QkFDakIsTUFBTSxLQUFLLFlBQVksUUFBUSxDQUFDLFFBQVEsTUFBTTs7d0JBRWxELEtBQUssT0FBTyxhQUFhOzRCQUNyQixVQUFVLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxPQUFPOzRCQUNwRCxVQUFVLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxPQUFPOzRCQUNwRCxVQUFVLEtBQUssVUFBVSxRQUFRLEtBQUssT0FBTzs0QkFDN0MsU0FBUyxLQUFLLFNBQVMsUUFBUSxLQUFLLE9BQU87Ozs7Ozs7b0JBT25ELHlCQUF5QixVQUFVLGNBQWMsWUFBWTt3QkFDekQsS0FBSyxTQUFTLElBQUksT0FBTyxPQUFPO3dCQUNoQyxLQUFLLElBQUksS0FBSyxLQUFLLE9BQU8sV0FBVzs0QkFDakMsSUFBSSxLQUFLLE9BQU8sVUFBVSxlQUFlLElBQUk7Z0NBQ3pDLEtBQUssT0FBTyxVQUFVLEtBQUs7Ozt3QkFHbkMsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFlBQVk7NEJBQ2xDLElBQUksS0FBSyxPQUFPLFdBQVcsZUFBZSxJQUFJO2dDQUMxQyxLQUFLLE9BQU8sV0FBVyxLQUFLOzs7O29CQUl4Qyx5QkFBeUIsVUFBVSxXQUFXLFlBQVk7d0JBQ3RELEtBQUssT0FBTyxNQUFNOztvQkFFdEIseUJBQXlCLFVBQVUsb0JBQW9CLFlBQVk7d0JBQy9ELElBQUksUUFBUTt3QkFDWixJQUFJLEtBQUssV0FBVyxRQUFROzRCQUN4QixLQUFLLFVBQVU7NEJBQ2YsSUFBSSxnQkFBZ0I7NEJBQ3BCLElBQUksS0FBSyxhQUFhLFVBQVU7Z0NBQzVCLGdCQUFnQixLQUFLOztpQ0FFcEI7Z0NBQ0QsZ0JBQWdCLEtBQUs7OzRCQUV6QjtpQ0FDSyxRQUFRLFlBQVk7Z0NBQ3JCLE1BQU0sVUFBVTs7OztvQkFJNUIseUJBQXlCLFVBQVUsaUJBQWlCLFlBQVk7d0JBQzVELElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssY0FBYyxJQUFJLEtBQUs7NkJBQzlCLEtBQUssWUFBWTs0QkFDbEIsTUFBTTs0QkFDTixNQUFNLFdBQVc7NEJBQ2pCLE1BQU0sV0FBVzs0QkFDakIsTUFBTTs7O29CQUdkLHlCQUF5QixVQUFVLGtCQUFrQixZQUFZO3dCQUM3RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLGNBQWMsS0FBSyxLQUFLOzZCQUMvQixLQUFLLFlBQVk7NEJBQ2xCLE1BQU0sa0JBQWtCOzs7b0JBR2hDLHlCQUF5QixVQUFVLGtCQUFrQixZQUFZO3dCQUM3RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxjQUFjLGdCQUFnQixLQUFLLE9BQU87NkJBQzFDLEtBQUssVUFBVSxRQUFROzRCQUN4QixNQUFNLGtCQUFrQjs7NkJBRXZCLE1BQU0sWUFBWTs7OztvQkFJM0IseUJBQXlCLFVBQVUsb0JBQW9CLFlBQVk7d0JBQy9ELEtBQUssT0FBTyxZQUFZO3dCQUN4QixJQUFJLEtBQUssT0FBTyxhQUFhLEtBQUssT0FBTyxTQUFTOzRCQUM5QyxLQUFLLE9BQU8sWUFBWTs0QkFDeEIsSUFBSSxPQUFPLEtBQUssTUFBTSxDQUFDLEtBQUssT0FBTyxRQUFRLFlBQVksS0FBSyxPQUFPLFVBQVUsYUFBYSxPQUFPLEtBQUssS0FBSzs0QkFDM0csS0FBSyxPQUFPLFlBQVksS0FBSyxPQUFPLGFBQWEsT0FBTzs7d0JBRTVELE9BQU8sS0FBSyxPQUFPOztvQkFFdkIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsNEJBQTRCO2VBQzdDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7a0hBQ0EsSUFBSSxxQkFBcUIsWUFBWTtvQkFDakMsU0FBUyxrQkFBa0Isb0JBQW9CLFFBQVEsY0FBYzt3QkFDakUsS0FBSyxxQkFBcUI7d0JBQzFCLEtBQUssU0FBUzt3QkFDZCxLQUFLLGVBQWU7d0JBQ3BCLE9BQU8sSUFBSSxnQkFBZ0IsWUFBWTs0QkFDbkMsbUJBQW1CLGFBQWEsZ0JBQWdCLE9BQU87NEJBQ3ZELE9BQU8sV0FBVzs7O29CQUcxQixPQUFPOztnQkFFWCxZQUFZLG9CQUFvQjtnQkFDaEMsUUFBUSxPQUFPO3FCQUNWLFdBQVcscUJBQXFCO2VBQ3RDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7MkhBQ0EsSUFBSSw2QkFBNkIsWUFBWTtvQkFDekMsU0FBUywwQkFBMEIsUUFBUSxlQUFlLFFBQVEsVUFBVTt3QkFDeEUsSUFBSSxRQUFRO3dCQUNaLEtBQUssU0FBUzt3QkFDZCxLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxTQUFTO3dCQUNkLEtBQUssV0FBVzt3QkFDaEIsS0FBSyxjQUFjO3dCQUNuQixLQUFLO3dCQUNMLE9BQU8sSUFBSSwyQkFBMkIsWUFBWTs0QkFDOUMsTUFBTTtpQ0FDRCxRQUFRLFlBQVk7Z0NBQ3JCLE1BQU0sY0FBYzs7OztvQkFJaEMsMEJBQTBCLFVBQVUsYUFBYSxZQUFZO3dCQUN6RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLE9BQU8sS0FBSyxjQUFjOzZCQUNyQixLQUFLLFVBQVUsTUFBTTs0QkFDdEIsTUFBTSxVQUFVOzs2QkFFZixRQUFRLFlBQVk7NEJBQ3JCLE1BQU0sVUFBVTs7O29CQUd4QiwwQkFBMEIsVUFBVSxtQkFBbUIsVUFBVSxRQUFRO3dCQUNyRSxJQUFJLFFBQVE7d0JBQ1osS0FBSyxtQkFBbUI7d0JBQ3hCLEtBQUssU0FBUyxZQUFZOzRCQUN0QixNQUFNLE9BQU8sR0FBRyxxQkFBcUIsRUFBRSxVQUFVLE9BQU87MkJBQ3pEOztvQkFFUCxPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyw2QkFBNkI7ZUFDOUMsY0FBYyxPQUFPLGdCQUFnQixPQUFPLGNBQWM7V0FDOUQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFNBQVM7Z0JBQ2hCO2dCQUNBLFNBQVMsdUJBQXVCO29CQUM1QixPQUFPLFVBQVUsT0FBTzt3QkFDcEIsT0FBTyxPQUFPLE9BQU8sZUFBZTs7O2dCQUc1QyxRQUFRLE9BQU87cUJBQ1YsT0FBTyxxQkFBcUI7ZUFDbEMsVUFBVSxPQUFPLFlBQVksT0FBTyxVQUFVO1dBQ2xELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxTQUFTO2dCQUNoQjtnQkFDQSxTQUFTLHVCQUF1QjtvQkFDNUIsT0FBTyxVQUFVLE9BQU87d0JBQ3BCLE9BQU8sT0FBTyxPQUFPLGVBQWU7OztnQkFHNUMsUUFBUSxPQUFPO3FCQUNWLE9BQU8scUJBQXFCO2VBQ2xDLFVBQVUsT0FBTyxZQUFZLE9BQU8sVUFBVTtXQUNsRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsSUFBSSxlQUFlLFlBQVk7b0JBQzNCLFNBQVMsY0FBYzt3QkFDbkIsS0FBSyxNQUFNOztvQkFFZixZQUFZLFVBQVUsVUFBVSxVQUFVLEdBQUc7d0JBQ3pDLElBQUksU0FBUyxLQUFLLE1BQU0sSUFBSTt3QkFDNUIsSUFBSSxXQUFXLEtBQUssU0FBUzt3QkFDN0IsSUFBSSxRQUFRO3dCQUNaLElBQUksVUFBVTt3QkFDZCxJQUFJLE1BQU07d0JBQ1YsSUFBSSxRQUFRLElBQUk7NEJBQ1osUUFBUSxRQUFROzRCQUNoQixNQUFNOzt3QkFFVixJQUFJLFlBQVksTUFBTTt3QkFDdEIsSUFBSSxjQUFjLFFBQVE7d0JBQzFCLElBQUksVUFBVSxXQUFXLEdBQUc7NEJBQ3hCLFlBQVksTUFBTTs7d0JBRXRCLElBQUksWUFBWSxXQUFXLEdBQUc7NEJBQzFCLGNBQWMsTUFBTTs7d0JBRXhCLE9BQU87NEJBQ0gsSUFBSTs0QkFDSixPQUFPLFlBQVksTUFBTSxjQUFjLE1BQU07NEJBQzdDLE9BQU87NEJBQ1AsU0FBUzs7O29CQUdqQixZQUFZLFVBQVUsY0FBYyxZQUFZO3dCQUM1QyxJQUFJLFNBQVM7d0JBQ2IsSUFBSSxhQUFhO3dCQUNqQixJQUFJLGFBQWE7d0JBQ2pCLElBQUksUUFBUTt3QkFDWixLQUFLLElBQUksSUFBSSxZQUFZLEtBQUssWUFBWSxJQUFJLElBQUksT0FBTzs0QkFDckQsT0FBTyxLQUFLLEtBQUssUUFBUTs7d0JBRTdCLEtBQUssTUFBTTs7b0JBRWYsT0FBTzs7Z0JBRVgsU0FBUyxjQUFjO2dCQUN2QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxlQUFlO2VBQzdCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxZQUFZO29CQUNqQixJQUFJLFNBQVM7b0JBQ2IsS0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLElBQUksS0FBSzt3QkFDM0IsT0FBTyxLQUFLOzRCQUNSLElBQUk7NEJBQ0osT0FBTyxJQUFJOzs7b0JBR25CO29CQUNBLE9BQU87d0JBQ0gsU0FBUyxVQUFVLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUFJLE9BQU8sS0FBSzt3QkFDdkQsS0FBSzs7O2dCQUdiLFNBQVMsWUFBWTtnQkFDckIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsYUFBYTtlQUMzQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsbUJBQW1CO29CQUN4QixPQUFPO3dCQUNILFNBQVMsVUFBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksSUFBSSxPQUFPLE9BQU8sT0FBTyxlQUFlO3dCQUMvRSxLQUFLLE9BQU8sS0FBSyxPQUFPLE9BQU87NkJBQzFCLElBQUksVUFBVSxHQUFHLEVBQUUsT0FBTyxTQUFTLEdBQUc7NkJBQ3RDLE9BQU8sVUFBVSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU07NkJBQ3BDLElBQUksVUFBVSxHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxPQUFPLE9BQU8sT0FBTyxlQUFlOzs7Z0JBR3JGLFNBQVMsbUJBQW1CO2dCQUM1QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxvQkFBb0I7ZUFDbEMsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLG1CQUFtQjtvQkFDeEIsT0FBTzt3QkFDSCxTQUFTLFVBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksT0FBTyxPQUFPLE9BQU8sZUFBZTt3QkFDL0UsS0FBSyxPQUFPLEtBQUssT0FBTyxPQUFPOzZCQUMxQixJQUFJLFVBQVUsR0FBRyxFQUFFLE9BQU8sU0FBUyxHQUFHOzZCQUN0QyxPQUFPLFVBQVUsR0FBRyxFQUFFLE9BQU8sQ0FBQyxNQUFNLE1BQU0sTUFBTTs2QkFDaEQsSUFBSSxVQUFVLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLE9BQU8sT0FBTyxPQUFPLGVBQWU7OztnQkFHckYsU0FBUyxtQkFBbUI7Z0JBQzVCLFFBQVEsT0FBTztxQkFDVixRQUFRLG9CQUFvQjtlQUNsQyxXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsY0FBYztvQkFDbkIsT0FBTyxPQUFPLEtBQUssT0FBTyxPQUFPO3lCQUM1QixJQUFJLFVBQVUsR0FBRyxFQUFFLE9BQU8sU0FBUyxHQUFHO3lCQUN0QyxPQUFPLFVBQVUsR0FBRyxFQUFFLE9BQU8sQ0FBQyxNQUFNO3lCQUNwQyxJQUFJLFVBQVUsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsT0FBTyxPQUFPLE9BQU8sV0FBVzs7Z0JBRTdFLFNBQVMsY0FBYztnQkFDdkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsZUFBZTtlQUM3QixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzswRkFDQSxJQUFJLGFBQWEsWUFBWTtvQkFDekIsU0FBUyxVQUFVLElBQUksT0FBTyxlQUFlO3dCQUN6QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCOztvQkFFekIsVUFBVSxVQUFVLE1BQU0sVUFBVSxVQUFVO3dCQUMxQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLElBQUksVUFBVTtnQ0FDVixLQUFLLENBQUMsTUFBTSxjQUFjLElBQUksTUFBTSxNQUFNLGNBQWMsSUFBSSxRQUFRLGFBQWE7Z0NBQ2pGLFFBQVE7OzRCQUVaLE1BQU0sTUFBTTtpQ0FDUCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUTs7OztvQkFJcEIsVUFBVSxVQUFVLFNBQVMsWUFBWTt3QkFDckMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxJQUFJLFVBQVU7Z0NBQ1YsS0FBSyxDQUFDLE1BQU0sY0FBYyxJQUFJLE1BQU0sTUFBTSxjQUFjLElBQUksUUFBUTtnQ0FDcEUsUUFBUTs7NEJBRVosTUFBTSxNQUFNO2lDQUNQLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFROzs7O29CQUlwQixVQUFVLFVBQVUsTUFBTSxVQUFVLFFBQVE7d0JBQ3hDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFROzRCQUNsRSxRQUFROzRCQUNSLE1BQU07O3dCQUVWLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsVUFBVSxVQUFVLE9BQU8sVUFBVSxRQUFRO3dCQUN6QyxJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUTs0QkFDbEUsUUFBUTs0QkFDUixNQUFNOzt3QkFFVixPQUFPLEtBQUssTUFBTTs7b0JBRXRCLFVBQVUsVUFBVSxrQkFBa0IsVUFBVSxNQUFNO3dCQUNsRCxJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUSxvQ0FBb0M7NEJBQ3RHLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsT0FBTzs7Z0JBRVgsU0FBUyxZQUFZO2dCQUNyQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxhQUFhO2VBQzNCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OytGQUNBLElBQUksaUJBQWlCLFlBQVk7b0JBQzdCLFNBQVMsY0FBYyxJQUFJLFdBQVcsWUFBWTt3QkFDOUMsS0FBSyxLQUFLO3dCQUNWLEtBQUssWUFBWTt3QkFDakIsS0FBSyxhQUFhOztvQkFFdEIsY0FBYyxVQUFVLE1BQU0sVUFBVSxVQUFVO3dCQUM5QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sVUFBVSxJQUFJO2lDQUNmLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFRLElBQUksT0FBTyxPQUFPLFNBQVMsVUFBVSxTQUFTOzs7O29CQUlsRSxjQUFjLFVBQVUsU0FBUyxZQUFZO3dCQUN6QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sVUFBVTtpQ0FDWCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUSxTQUFTLEtBQUssSUFBSSxVQUFVLE1BQU07b0NBQ3RDLE9BQU8sSUFBSSxPQUFPLE9BQU8sU0FBUyxVQUFVOzs7OztvQkFLNUQsY0FBYyxVQUFVLE1BQU0sVUFBVSxRQUFRO3dCQUM1QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sVUFBVSxJQUFJLE9BQU87aUNBQ3RCLEtBQUssWUFBWTtnQ0FDbEI7O2lDQUVDLE1BQU0sWUFBWTtnQ0FDbkI7Ozs7b0JBSVosY0FBYyxVQUFVLE9BQU8sVUFBVSxRQUFRO3dCQUM3QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sVUFBVSxLQUFLLE9BQU87aUNBQ3ZCLEtBQUssWUFBWTtnQ0FDbEI7O2lDQUVDLE1BQU0sWUFBWTtnQ0FDbkI7Ozs7b0JBSVosY0FBYyxVQUFVLGtCQUFrQixVQUFVLE1BQU07d0JBQ3RELElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxVQUFVLGdCQUFnQixLQUFLO2lDQUNoQyxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUSxTQUFTOztpQ0FFaEIsTUFBTSxZQUFZO2dDQUNuQjs7OztvQkFJWixPQUFPOztnQkFFWCxTQUFTLGdCQUFnQjtnQkFDekIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsaUJBQWlCO2VBQy9CLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxZQUFZO29CQUNqQixPQUFPLENBQUMsR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSTt3QkFDakUsSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJOztnQkFFOUQsU0FBUyxZQUFZO2dCQUNyQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxhQUFhO2VBQzNCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxXQUFXO29CQUNoQixJQUFJLFNBQVM7b0JBQ2IsS0FBSyxJQUFJLElBQUksS0FBSyxLQUFLLEtBQUssS0FBSzt3QkFDN0IsT0FBTyxLQUFLOzRCQUNSLElBQUk7NEJBQ0osT0FBTyxJQUFJOzs7b0JBR25CO29CQUNBLE9BQU87d0JBQ0gsU0FBUyxVQUFVLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUFJLE9BQU8sS0FBSzt3QkFDdkQsS0FBSzs7O2dCQUdiLFNBQVMsV0FBVztnQkFDcEIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsWUFBWTtlQUMxQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCOztrSUFDQSxJQUFJLDhCQUE4QixZQUFZO29CQUMxQyxTQUFTLDJCQUEyQixhQUFhLGNBQWMsWUFBWSxRQUFRO3dCQUMvRSxJQUFJLFFBQVE7d0JBQ1osS0FBSyxjQUFjO3dCQUNuQixLQUFLLGVBQWU7d0JBQ3BCLEtBQUssYUFBYTt3QkFDbEIsS0FBSyxTQUFTO3dCQUNkLEtBQUssVUFBVTt3QkFDZixLQUFLLGtCQUFrQjt3QkFDdkIsS0FBSyxXQUFXO3dCQUNoQixLQUFLO3dCQUNMLE9BQU8sT0FBTyxZQUFZOzRCQUN0QixNQUFNOzs7b0JBR2QsMkJBQTJCLFVBQVUsVUFBVSxZQUFZO3dCQUN2RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssWUFBWSxJQUFJLEtBQUssYUFBYTs2QkFDbEMsS0FBSyxVQUFVLE1BQU07NEJBQ3RCLE1BQU0sT0FBTzs7NkJBRVosTUFBTSxZQUFZOzs7NkJBR2xCLFFBQVEsWUFBWTs0QkFDckIsTUFBTSxVQUFVOzs7b0JBR3hCLDJCQUEyQixVQUFVLGNBQWMsWUFBWTt3QkFDM0QsSUFBSSxRQUFRO3dCQUNaLElBQUksS0FBSyxpQkFBaUI7NEJBQ3RCLEtBQUs7OzZCQUVKOzRCQUNELEtBQUssV0FBVztpQ0FDWCxLQUFLLFVBQVUsTUFBTTtnQ0FDdEIsTUFBTSxrQkFBa0I7Z0NBQ3hCLE1BQU07Ozs7b0JBSWxCLDJCQUEyQixVQUFVLGVBQWUsWUFBWTt3QkFDNUQsSUFBSSxLQUFLLE1BQU07NEJBQ1gsS0FBSyxXQUFXLEtBQUssV0FBVyxtQkFBbUIsS0FBSyxpQkFBaUIsRUFBRSxVQUFVLEtBQUssS0FBSyxVQUFVLFdBQVcsS0FBSyxLQUFLOzs7b0JBR3RJLE9BQU87O2dCQUVYLFFBQVEsT0FBTztxQkFDVixXQUFXLDhCQUE4QjtlQUMvQyxjQUFjLEtBQUssZ0JBQWdCLEtBQUssY0FBYztXQUMxRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O3dGQUNBLElBQUksNEJBQTRCLFlBQVk7b0JBQ3hDLFNBQVMseUJBQXlCLGFBQWE7d0JBQzNDLEtBQUssY0FBYzt3QkFDbkIsS0FBSzs7b0JBRVQseUJBQXlCLFVBQVUsV0FBVyxZQUFZO3dCQUN0RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssWUFBWTs2QkFDWixLQUFLLFVBQVUsTUFBTTs0QkFDdEIsTUFBTSxZQUFZOzs2QkFFakIsUUFBUSxZQUFZOzRCQUNyQixNQUFNLFVBQVU7OztvQkFHeEIseUJBQXlCLFVBQVUsY0FBYyxVQUFVLE9BQU87d0JBQzlELElBQUksUUFBUTt3QkFDWixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssY0FBYzt3QkFDbkIsTUFBTSxRQUFRLFVBQVUsTUFBTTs0QkFDMUIsSUFBSSxLQUFLLFdBQVcsS0FBSyxPQUFPLFdBQVcsTUFBTTtnQ0FDN0MsTUFBTSxVQUFVLEtBQUs7O2lDQUVwQixJQUFJLEtBQUssV0FBVyxLQUFLLE9BQU8sV0FBVyxRQUFRO2dDQUNwRCxNQUFNLFlBQVksS0FBSzs7OztvQkFJbkMsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsNEJBQTRCO2VBQzdDLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7d0ZBQ0EsSUFBSSxXQUFXLFlBQVk7b0JBQ3ZCLFNBQVMsUUFBUSxJQUFJLE9BQU8sZUFBZTt3QkFDdkMsS0FBSyxLQUFLO3dCQUNWLEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjs7b0JBRXpCLFFBQVEsVUFBVSxTQUFTLFlBQVk7d0JBQ25DLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsSUFBSSxVQUFVO2dDQUNWLEtBQUssQ0FBQyxNQUFNLGNBQWMsSUFBSSxNQUFNLE1BQU0sY0FBYyxJQUFJLFFBQVE7Z0NBQ3BFLFFBQVE7OzRCQUVaLE1BQU0sTUFBTTtpQ0FDUCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUTs7OztvQkFJcEIsUUFBUSxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVc7d0JBQ3ZELElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsSUFBSSxVQUFVO2dDQUNWLEtBQUssQ0FBQyxDQUFDLE1BQU0sY0FBYyxJQUFJLE1BQU0sTUFBTSxjQUFjLElBQUksUUFBUTtxQ0FDaEUsZUFBZTtxQ0FDZixnQkFBZ0I7Z0NBQ3JCLFFBQVE7OzRCQUVaLE1BQU0sTUFBTTtpQ0FDUCxLQUFLLFNBQVM7OztvQkFHM0IsUUFBUSxVQUFVLE1BQU0sVUFBVSxJQUFJO3dCQUNsQyxJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUSxXQUFXOzRCQUM3RSxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTTs7b0JBRXRCLE9BQU87O2dCQUVYLFNBQVMsVUFBVTtnQkFDbkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsV0FBVztlQUN6QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzsyRkFDQSxJQUFJLGVBQWUsWUFBWTtvQkFDM0IsU0FBUyxZQUFZLElBQUksU0FBUyxZQUFZO3dCQUMxQyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxVQUFVO3dCQUNmLEtBQUssYUFBYTs7b0JBRXRCLFlBQVksVUFBVSxTQUFTLFlBQVk7d0JBQ3ZDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxRQUFRO2lDQUNULEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFRLFNBQVMsS0FBSyxJQUFJLFVBQVUsTUFBTTtvQ0FDdEMsT0FBTyxJQUFJLEtBQUssT0FBTyxPQUFPLFVBQVU7Ozs7O29CQUt4RCxZQUFZLFVBQVUsVUFBVSxZQUFZO3dCQUN4QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sV0FBVztpQ0FDWixLQUFLLFVBQVUsUUFBUTtnQ0FDeEIsT0FBTyxNQUFNLFFBQVEsUUFBUSxPQUFPLFVBQVUsT0FBTzs7aUNBRXBELEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFRLFNBQVMsS0FBSyxJQUFJLFVBQVUsTUFBTTtvQ0FDdEMsT0FBTyxJQUFJLEtBQUssT0FBTyxPQUFPLFVBQVU7OztpQ0FHM0MsTUFBTTs7O29CQUduQixZQUFZLFVBQVUsTUFBTSxVQUFVLElBQUk7d0JBQ3RDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxRQUFRLElBQUk7aUNBQ2IsS0FBSyxVQUFVLFFBQVE7Z0NBQ3hCLFFBQVEsSUFBSSxLQUFLLE9BQU8sT0FBTyxVQUFVLE9BQU87O2lDQUUvQyxNQUFNOzs7b0JBR25CLE9BQU87O2dCQUVYLFNBQVMsY0FBYztnQkFDdkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsZUFBZTtlQUM3QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IiLCJmaWxlIjoiLi4vLi4vd3d3cm9vdC9qcy9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgJ3VzZSBzdHJpY3QnO1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcCcsIFtcbiAgICAgICAgICAgICdpb25pYycsXG4gICAgICAgICAgICAnYXBwLmNvcmUnLFxuICAgICAgICAgICAgJ2FwcC5hdXRoJyxcbiAgICAgICAgICAgICdhcHAuaG9tZScsXG4gICAgICAgICAgICAnYXBwLmxpZnQnLFxuICAgICAgICAgICAgJ2FwcC5kaW5pbmcnLFxuICAgICAgICAgICAgJ2FwcC5yZW50YWwnXG4gICAgICAgIF0pO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICBmdW5jdGlvbiBydW4oJGlvbmljUGxhdGZvcm0sICRsb2cpIHtcbiAgICAgICAgICAgICRpb25pY1BsYXRmb3JtLnJlYWR5KGRldmljZVJlYWR5LmNhbGwodGhpcywgJGxvZykpO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGRldmljZVJlYWR5KCRsb2cpIHtcbiAgICAgICAgICAgICRsb2cuaW5mbygnRGV2aWNlIFJlYWR5Jyk7XG4gICAgICAgIH1cbiAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcCcpXG4gICAgICAgICAgICAucnVuKHJ1bik7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcsIFtdKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScsIFtdKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycsIFtdKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBIb21lO1xuICAgICAgICAoZnVuY3Rpb24gKEhvbWUpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuaG9tZScsIFtdKTtcbiAgICAgICAgfSkoSG9tZSA9IEFwcC5Ib21lIHx8IChBcHAuSG9tZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcsIFtdKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcsIFtdKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRzdGF0ZVByb3ZpZGVyXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmxvZ2luJywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvbG9naW4nLFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0xvZ2luQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnYXV0aC90ZW1wbGF0ZXMvbG9naW4udGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgZnVuY3Rpb24gcm91dGluZ0NvbmZpZ3VyYXRpb24oJHN0YXRlUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcCcsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgYWJzdHJhY3Q6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdNZW51Q29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9tZW51LnRlbXBsYXRlLmh0bWwnXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBpb25pY0NvbmZpZ3VyYXRpb24oJGlvbmljQ29uZmlnUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkaW9uaWNDb25maWdQcm92aWRlci5zY3JvbGxpbmcuanNTY3JvbGxpbmcoZmFsc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAuY29uZmlnKHJvdXRpbmdDb25maWd1cmF0aW9uKVxuICAgICAgICAgICAgICAgIC5jb25maWcoaW9uaWNDb25maWd1cmF0aW9uKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgZnVuY3Rpb24gcm91dGluZ0NvbmZpZ3VyYXRpb24oJHN0YXRlUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5kaW5pbmctbGlzdCcsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2RpbmluZy9saXN0JyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdEaW5pbmdDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdkaW5pbmcvdGVtcGxhdGVzL2RpbmluZy1saXN0LnRlbXBsYXRlLmh0bWwnXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5kaW5pbmctZGV0YWlsJywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvZGluaW5nL2RldGFpbC86aWQnLFxuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RhdXJhbnQ6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdEaW5pbmdEZXRhaWxDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdkaW5pbmcvdGVtcGxhdGVzL2RpbmluZy1kZXRhaWwudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBIb21lO1xuICAgICAgICAoZnVuY3Rpb24gKEhvbWUpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyLCAkdXJsUm91dGVyUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5ob21lJywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvaG9tZScsXG4gICAgICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJhckNvbG9yOiAnZGFyaydcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdIb21lQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnaG9tZS90ZW1wbGF0ZXMvaG9tZS50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICR1cmxSb3V0ZXJQcm92aWRlci5vdGhlcndpc2UoJy9ob21lJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmhvbWUnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShIb21lID0gQXBwLkhvbWUgfHwgKEFwcC5Ib21lID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlciwgJHVybFJvdXRlclByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAucmVudGFscycsIHtcbiAgICAgICAgICAgICAgICAgICAgY2FjaGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcmVudGFscycsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3JlbnRhbC90ZW1wbGF0ZXMvcmVudGFscy50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnUmVudGFsc0NvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAucmVudGFsLWRldGFpbCcsIHtcbiAgICAgICAgICAgICAgICAgICAgY2FjaGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcmVudGFsLzpyZW50YWxJZCcsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3JlbnRhbC90ZW1wbGF0ZXMvbmV3LXJlc2VydmF0aW9uLXdyYXBwZXIudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ05ld1Jlc2VydmF0aW9uQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAndGFiQ3RybCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyLCAkdXJsUm91dGVyUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5saWZ0LXN0YXR1cy1saXN0Jywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvbGlmdC9zdGF0dXMvbGlzdCcsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdsaWZ0L3RlbXBsYXRlcy9saWZ0LXN0YXR1cy1saXN0LnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAubGlmdC1zdGF0dXMtZGV0YWlsJywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvbGlmdC9zdGF0dXMvZGV0YWlsLzpsaWZ0SWQnLFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0xpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdsaWZ0L3RlbXBsYXRlcy9saWZ0LXN0YXR1cy1kZXRhaWwudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5saWZ0JylcbiAgICAgICAgICAgICAgICAuY29uZmlnKHJvdXRpbmdDb25maWd1cmF0aW9uKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IEF1dGguTW9kZWxzIHx8IChBdXRoLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFN1bW1hcnlJbmZvID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm8oKSB7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN1bW1hcnlJbmZvO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgTW9kZWxzLlN1bW1hcnlJbmZvID0gU3VtbWFyeUluZm87XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBDb3JlLk1vZGVscyB8fCAoQ29yZS5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoV2VhdGhlcikge1xuICAgICAgICAgICAgICAgICAgICBXZWF0aGVyW1dlYXRoZXJbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgV2VhdGhlcltXZWF0aGVyW1wiU25vd2luZ1wiXSA9IDFdID0gXCJTbm93aW5nXCI7XG4gICAgICAgICAgICAgICAgICAgIFdlYXRoZXJbV2VhdGhlcltcIlJhaW55XCJdID0gMl0gPSBcIlJhaW55XCI7XG4gICAgICAgICAgICAgICAgICAgIFdlYXRoZXJbV2VhdGhlcltcIkNsb3VkeVwiXSA9IDNdID0gXCJDbG91ZHlcIjtcbiAgICAgICAgICAgICAgICAgICAgV2VhdGhlcltXZWF0aGVyW1wiU3VubnlcIl0gPSA0XSA9IFwiU3VubnlcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuV2VhdGhlciB8fCAoTW9kZWxzLldlYXRoZXIgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBXZWF0aGVyID0gTW9kZWxzLldlYXRoZXI7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBDb3JlLk1vZGVscyB8fCAoQ29yZS5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKExldmVsT2ZOb2lzZSkge1xuICAgICAgICAgICAgICAgICAgICBMZXZlbE9mTm9pc2VbTGV2ZWxPZk5vaXNlW1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIExldmVsT2ZOb2lzZVtMZXZlbE9mTm9pc2VbXCJMb3dcIl0gPSAxXSA9IFwiTG93XCI7XG4gICAgICAgICAgICAgICAgICAgIExldmVsT2ZOb2lzZVtMZXZlbE9mTm9pc2VbXCJNZWRpdW1cIl0gPSAyXSA9IFwiTWVkaXVtXCI7XG4gICAgICAgICAgICAgICAgICAgIExldmVsT2ZOb2lzZVtMZXZlbE9mTm9pc2VbXCJMb3VkXCJdID0gM10gPSBcIkxvdWRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuTGV2ZWxPZk5vaXNlIHx8IChNb2RlbHMuTGV2ZWxPZk5vaXNlID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgTGV2ZWxPZk5vaXNlID0gTW9kZWxzLkxldmVsT2ZOb2lzZTtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IERpbmluZy5Nb2RlbHMgfHwgKERpbmluZy5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVzdGF1cmFudCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlc3RhdXJhbnQoKSB7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlc3RhdXJhbnQ7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBNb2RlbHMuUmVzdGF1cmFudCA9IFJlc3RhdXJhbnQ7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBEaW5pbmcuTW9kZWxzIHx8IChEaW5pbmcuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnRfMSkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMaWZ0ID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdCgpIHtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBMaWZ0LnByb3RvdHlwZS5zZXJpYWxpemUgPSBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0SWQgPSBkYXRhLmxpZnRJZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmFtZSA9IGRhdGEubmFtZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmF0aW5nID0gZGF0YS5yYXRpbmc7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXR1cyA9IGRhdGEuc3RhdHVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXRpdHVkZSA9IGRhdGEubGF0aXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvbmdpdHVkZSA9IGRhdGEubG9uZ2l0dWRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF5QXdheSA9IGRhdGEuc3RheUF3YXk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndhaXRpbmdUaW1lID0gZGF0YS53YWl0aW5nVGltZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VkUmVhc29uID0gZGF0YS5jbG9zZWRSZWFzb247XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdC5wcm90b3R5cGUuZGVzZXJpYWxpemUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpZnRJZDogdGhpcy5saWZ0SWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogdGhpcy5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJhdGluZzogdGhpcy5yYXRpbmcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiB0aGlzLnN0YXR1cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXRpdHVkZTogdGhpcy5sYXRpdHVkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb25naXR1ZGU6IHRoaXMubG9uZ2l0dWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXlBd2F5OiB0aGlzLnN0YXlBd2F5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdhaXRpbmdUaW1lOiB0aGlzLndhaXRpbmdUaW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsb3NlZFJlYXNvbjogdGhpcy5jbG9zZWRSZWFzb25cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0O1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgTW9kZWxzLkxpZnQgPSBMaWZ0O1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gTGlmdF8xLk1vZGVscyB8fCAoTGlmdF8xLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChMaWZ0UmF0aW5nKSB7XG4gICAgICAgICAgICAgICAgICAgIExpZnRSYXRpbmdbTGlmdFJhdGluZ1tcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBMaWZ0UmF0aW5nW0xpZnRSYXRpbmdbXCJCZWdpbm5lclwiXSA9IDFdID0gXCJCZWdpbm5lclwiO1xuICAgICAgICAgICAgICAgICAgICBMaWZ0UmF0aW5nW0xpZnRSYXRpbmdbXCJJbnRlcm1lZGlhdGVcIl0gPSAyXSA9IFwiSW50ZXJtZWRpYXRlXCI7XG4gICAgICAgICAgICAgICAgICAgIExpZnRSYXRpbmdbTGlmdFJhdGluZ1tcIkFkdmFuY2VkXCJdID0gM10gPSBcIkFkdmFuY2VkXCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLkxpZnRSYXRpbmcgfHwgKE1vZGVscy5MaWZ0UmF0aW5nID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFJhdGluZyA9IE1vZGVscy5MaWZ0UmF0aW5nO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gTGlmdC5Nb2RlbHMgfHwgKExpZnQuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKExpZnRTdGF0dXMpIHtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c1tMaWZ0U3RhdHVzW1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNbTGlmdFN0YXR1c1tcIk9wZW5cIl0gPSAxXSA9IFwiT3BlblwiO1xuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzW0xpZnRTdGF0dXNbXCJDbG9zZWRcIl0gPSAyXSA9IFwiQ2xvc2VkXCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLkxpZnRTdGF0dXMgfHwgKE1vZGVscy5MaWZ0U3RhdHVzID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFN0YXR1cyA9IE1vZGVscy5MaWZ0U3RhdHVzO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gTGlmdC5Nb2RlbHMgfHwgKExpZnQuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBSZW50YWwuTW9kZWxzIHx8IChSZW50YWwuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsXzEpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsKCkge1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbC5wcm90b3R5cGUuc2VyaWFsaXplID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsSWQgPSBkYXRhLnJlbnRhbElkO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51c2VyRW1haWwgPSBkYXRhLnVzZXJFbWFpbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhcnREYXRlID0gbmV3IERhdGUoZGF0YS5zdGFydERhdGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5lbmREYXRlID0gbmV3IERhdGUoZGF0YS5lbmREYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGlja3VwSG91ciA9IGRhdGEucGlja3VwSG91cjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWN0aXZpdHkgPSBkYXRhLmFjdGl2aXR5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jYXRlZ29yeSA9IGRhdGEuY2F0ZWdvcnk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdvYWwgPSBkYXRhLmdvYWw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNob2VTaXplID0gZGF0YS5zaG9lU2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2tpU2l6ZSA9IGRhdGEuc2tpU2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucG9sZVNpemUgPSBkYXRhLnBvbGVTaXplO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy50b3RhbENvc3QgPSBkYXRhLnRvdGFsQ29zdDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBSZW50YWwucHJvdG90eXBlLmRlc2VyaWFsaXplID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW50YWxJZDogdGhpcy5yZW50YWxJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyRW1haWw6IHRoaXMudXNlckVtYWlsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXJ0RGF0ZTogdGhpcy5zdGFydERhdGUudG9KU09OKCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kRGF0ZTogdGhpcy5lbmREYXRlLnRvSlNPTigpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBpY2t1cEhvdXI6IHRoaXMucGlja3VwSG91cixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eTogdGhpcy5hY3Rpdml0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeTogdGhpcy5jYXRlZ29yeSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBnb2FsOiB0aGlzLmdvYWwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvZVNpemU6IHRoaXMuc2hvZVNpemUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2tpU2l6ZTogdGhpcy5za2lTaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvbGVTaXplOiB0aGlzLnBvbGVTaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvdGFsQ29zdDogdGhpcy50b3RhbENvc3RcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWw7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBNb2RlbHMuUmVudGFsID0gUmVudGFsO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gUmVudGFsXzEuTW9kZWxzIHx8IChSZW50YWxfMS5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbEFjdGl2aXR5KSB7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFjdGl2aXR5W1JlbnRhbEFjdGl2aXR5W1wiU2tpXCJdID0gMF0gPSBcIlNraVwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxBY3Rpdml0eVtSZW50YWxBY3Rpdml0eVtcIlNub3dib2FyZFwiXSA9IDFdID0gXCJTbm93Ym9hcmRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuUmVudGFsQWN0aXZpdHkgfHwgKE1vZGVscy5SZW50YWxBY3Rpdml0eSA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbEFjdGl2aXR5ID0gTW9kZWxzLlJlbnRhbEFjdGl2aXR5O1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gUmVudGFsLk1vZGVscyB8fCAoUmVudGFsLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoUmVudGFsQ2F0ZWdvcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQ2F0ZWdvcnlbUmVudGFsQ2F0ZWdvcnlbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQ2F0ZWdvcnlbUmVudGFsQ2F0ZWdvcnlbXCJCZWdpbm5lclwiXSA9IDFdID0gXCJCZWdpbm5lclwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxDYXRlZ29yeVtSZW50YWxDYXRlZ29yeVtcIkludGVybWVkaWF0ZVwiXSA9IDJdID0gXCJJbnRlcm1lZGlhdGVcIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQ2F0ZWdvcnlbUmVudGFsQ2F0ZWdvcnlbXCJBZHZhbmNlZFwiXSA9IDNdID0gXCJBZHZhbmNlZFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5SZW50YWxDYXRlZ29yeSB8fCAoTW9kZWxzLlJlbnRhbENhdGVnb3J5ID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsQ2F0ZWdvcnkgPSBNb2RlbHMuUmVudGFsQ2F0ZWdvcnk7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBSZW50YWwuTW9kZWxzIHx8IChSZW50YWwuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChSZW50YWxHb2FsKSB7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEdvYWxbUmVudGFsR29hbFtcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxHb2FsW1JlbnRhbEdvYWxbXCJEZW1vXCJdID0gMV0gPSBcIkRlbW9cIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsR29hbFtSZW50YWxHb2FsW1wiUGVyZm9ybWFuY2VcIl0gPSAyXSA9IFwiUGVyZm9ybWFuY2VcIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsR29hbFtSZW50YWxHb2FsW1wiU3BvcnRcIl0gPSAzXSA9IFwiU3BvcnRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuUmVudGFsR29hbCB8fCAoTW9kZWxzLlJlbnRhbEdvYWwgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxHb2FsID0gTW9kZWxzLlJlbnRhbEdvYWw7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBSZW50YWwuTW9kZWxzIHx8IChSZW50YWwuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMb2dpbkNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMb2dpbkNvbnRyb2xsZXIoYXV0aFNlcnZpY2UsIG5hdmlnYXRpb25TZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlID0gYXV0aFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlID0gbmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvZ2luRGF0YSA9IHt9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cm9uZ1Bhc3N3b3JkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBMb2dpbkNvbnRyb2xsZXIucHJvdG90eXBlLmxvZ2luID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndyb25nUGFzc3dvcmQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmxvZ2luRm9ybS4kdmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlLmxvZ2luKHRoaXMubG9naW5EYXRhLnVzZXJuYW1lLCB0aGlzLmxvZ2luRGF0YS5wYXNzd29yZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5jbG9zZUxvZ2luKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMud3JvbmdQYXNzd29yZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMb2dpbkNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignTG9naW5Db250cm9sbGVyJywgTG9naW5Db250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gQXV0aC5Db250cm9sbGVycyB8fCAoQXV0aC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQXV0aEltYWdlU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEF1dGhJbWFnZVNlcnZpY2UoJHEsIGF1dGhBUEksIGN1cnJlbnRVc2VyU2VydmljZSwgY29uZmlnU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoQVBJID0gYXV0aEFQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXJTZXJ2aWNlID0gY3VycmVudFVzZXJTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBBdXRoSW1hZ2VTZXJ2aWNlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJ1c2Vycy9waG90by9cIiArIGlkO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQXV0aEltYWdlU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkF1dGhJbWFnZVNlcnZpY2UgPSBBdXRoSW1hZ2VTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdhdXRoSW1hZ2VTZXJ2aWNlJywgQXV0aEltYWdlU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IEF1dGguU2VydmljZXMgfHwgKEF1dGguU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShBdXRoID0gQXBwLkF1dGggfHwgKEFwcC5BdXRoID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIEF1dGhBUEkgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdXRoQVBJKCRodHRwLCBjb25maWdTZXJ2aWNlLCAkaHR0cFBhcmFtU2VyaWFsaXplckpRTGlrZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGh0dHBQYXJhbVNlcmlhbGl6ZXJKUUxpa2UgPSAkaHR0cFBhcmFtU2VyaWFsaXplckpRTGlrZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBBdXRoQVBJLnByb3RvdHlwZS5sb2dpbiA9IGZ1bmN0aW9uICh1c2VybmFtZSwgcGFzc3dvcmQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBcImNvbm5lY3QvdG9rZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB0aGlzLiRodHRwUGFyYW1TZXJpYWxpemVySlFMaWtlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JhbnRfdHlwZTogdGhpcy5jb25maWdTZXJ2aWNlLkF1dGhlbnRpY2F0aW9uLkdyYW50VHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50X2lkOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQXV0aGVudGljYXRpb24uQ2xpZW50SUQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudF9zZWNyZXQ6IHRoaXMuY29uZmlnU2VydmljZS5BdXRoZW50aWNhdGlvbi5DbGllbnRTZWNyZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQXV0aGVudGljYXRpb24uU2NvcGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBdXRoQVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQXV0aEFQSSA9IEF1dGhBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2F1dGhBUEknLCBBdXRoQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQXV0aFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdXRoU2VydmljZSgkcSwgYXV0aEFQSSwgY3VycmVudFVzZXJTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhBUEkgPSBhdXRoQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlclNlcnZpY2UgPSBjdXJyZW50VXNlclNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQXV0aFNlcnZpY2UucHJvdG90eXBlLmxvZ2luID0gZnVuY3Rpb24gKHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5hdXRoQVBJLmxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmN1cnJlbnRVc2VyU2VydmljZS5hY2Nlc3NUb2tlbiA9IHJlc3BvbnNlLmRhdGEuYWNjZXNzX3Rva2VuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY3VycmVudFVzZXJTZXJ2aWNlLmdldEluZm8oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvci5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQXV0aFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5BdXRoU2VydmljZSA9IEF1dGhTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdhdXRoU2VydmljZScsIEF1dGhTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQ1VSUkVOVF9VU0VSX1NUT1JBR0VfS0VZID0gJ19jdXJyZW50VXNlckRhdGEnO1xuICAgICAgICAgICAgICAgIHZhciBDdXJyZW50VXNlclNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBDdXJyZW50VXNlclNlcnZpY2UoJHEsICRyb290U2NvcGUsICRodHRwLCBjb25maWdTZXJ2aWNlLCAkbG9nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRyb290U2NvcGUgPSAkcm9vdFNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZyA9ICRsb2c7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5hY2Nlc3NUb2tlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0SW5mbygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEN1cnJlbnRVc2VyU2VydmljZS5wcm90b3R5cGUuc2F2ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCdDdXJyZW50VXNlclNlcnZpY2Ugc2F2aW5nIHRvIExvY2FsU3RvcmFnZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN1cnJlbnRVc2VyQ29weSA9IGFuZ3VsYXIuY29weSh0aGlzLmN1cnJlbnRVc2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyQ29weS5waG90byA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShDVVJSRU5UX1VTRVJfU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NUb2tlbjogdGhpcy5hY2Nlc3NUb2tlbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXNlcjogY3VycmVudFVzZXJDb3B5XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRsb2cuaW5mbygnLSBTdWNjZXNzZnVsbHkgc2F2ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudFVzZXJTZXJ2aWNlLnByb3RvdHlwZS5sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSBsb2FkaW5nIGZyb20gTG9jYWxTdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmVkUmF3RGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKENVUlJFTlRfVVNFUl9TVE9SQUdFX0tFWSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RvcmVkUmF3RGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZWREYXRhID0gSlNPTi5wYXJzZShzdG9yZWRSYXdEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gc3RvcmVkRGF0YS5hY2Nlc3NUb2tlbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyID0gc3RvcmVkRGF0YS5jdXJyZW50VXNlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRyb290U2NvcGUuY3VycmVudFVzZXIgPSB0aGlzLmN1cnJlbnRVc2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIFN1Y2Nlc3NmdWxseSBsb2FkZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIExvY2FsU3RvcmFnZSBpcyBlbXB0eScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBDdXJyZW50VXNlclNlcnZpY2UucHJvdG90eXBlLnJlc2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSByZXNldHRpbmcgTG9jYWxTdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcm9vdFNjb3BlLmN1cnJlbnRVc2VyID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKENVUlJFTlRfVVNFUl9TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoe30pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIERvbmUnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudFVzZXJTZXJ2aWNlLnByb3RvdHlwZS5nZXRJbmZvID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCdDdXJyZW50VXNlclNlcnZpY2UgZ2V0dGluZyBpbmZvcm1hdGlvbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJ1c2Vycy91c2VyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIgKyB0aGlzLmFjY2Vzc1Rva2VuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy5pbmZvKCctIEluZm9ybWF0aW9uIGdldHRlZCBzdWNjZXNzZnVsbHknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5jdXJyZW50VXNlciA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJHJvb3RTY29wZS5jdXJyZW50VXNlciA9IF90aGlzLmN1cnJlbnRVc2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnNhdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRsb2cud2FybignLSBTb21ldGhpbmcgd2VudCB3cm9uZyB3aGlsZSBnZXR0aW5nIGluZm9ybWF0aW9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkN1cnJlbnRVc2VyU2VydmljZSA9IEN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnY3VycmVudFVzZXJTZXJ2aWNlJywgQ3VycmVudFVzZXJTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTWVudUNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBNZW51Q29udHJvbGxlcigkaW9uaWNTaWRlTWVudURlbGVnYXRlLCAkc3RhdGUsIGN1cnJlbnRVc2VyU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNTaWRlTWVudURlbGVnYXRlID0gJGlvbmljU2lkZU1lbnVEZWxlZ2F0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlID0gJHN0YXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlclNlcnZpY2UgPSBjdXJyZW50VXNlclNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTWVudUNvbnRyb2xsZXIucHJvdG90eXBlLm5hdmlnYXRlVG8gPSBmdW5jdGlvbiAodG9TdGF0ZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlLmdvKHRvU3RhdGVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGlvbmljU2lkZU1lbnVEZWxlZ2F0ZS50b2dnbGVSaWdodChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE1lbnVDb250cm9sbGVyLnByb3RvdHlwZS5sb2dvdXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyU2VydmljZS5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNTaWRlTWVudURlbGVnYXRlLnRvZ2dsZVJpZ2h0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE1lbnVDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ01lbnVDb250cm9sbGVyJywgTWVudUNvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBDb3JlLkNvbnRyb2xsZXJzIHx8IChDb3JlLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBXZWF0aGVyID0gQ29yZS5Nb2RlbHMuV2VhdGhlcjtcbiAgICAgICAgICAgICAgICB2YXIgU3VtbWFyeUluZm9Db250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm9Db250cm9sbGVyKHN1bW1hcnlJbmZvQVBJLCAkc3RhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN1bW1hcnlJbmZvQVBJID0gc3VtbWFyeUluZm9BUEk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZSA9ICRzdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bW1hcnlJbmZvQVBJLmdldCgpLnRoZW4oZnVuY3Rpb24gKHN1bW1hcnlJbmZvKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc3VtbWFyeUluZm8gPSBzdW1tYXJ5SW5mbztcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFN1bW1hcnlJbmZvQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0V2VhdGhlciA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFdlYXRoZXJbaWRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3VtbWFyeUluZm9Db250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ1N1bW1hcnlJbmZvQ29udHJvbGxlcicsIFN1bW1hcnlJbmZvQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IENvcmUuQ29udHJvbGxlcnMgfHwgKENvcmUuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gQXZhdGFyRGlyZWN0aXZlKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBzZXRCYWNrZ3JvdW5kSW1hZ2UoZWxlbWVudCwgdXJsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ3N0eWxlJywgJ2JhY2tncm91bmQtaW1hZ2U6IHVybChcXCcnICsgdXJsICsgJ1xcJyk7Jyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gbGluayhzY29wZSwgZWxlbWVudCwgYXR0cikge1xuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hZGRDbGFzcygnc2tpLWF2YXRhcicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0ci4kb2JzZXJ2ZSgnc2tpQXZhdGFyJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEJhY2tncm91bmRJbWFnZShlbGVtZW50LCBhdHRyLnNraUF2YXRhcik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgbGluazogbGlua1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lBdmF0YXInLCBBdmF0YXJEaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgRGlyZWN0aXZlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRGlyZWN0aXZlcykge1xuICAgICAgICAgICAgICAgIHZhciBOYXZCYXJDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTmF2QmFyQ29udHJvbGxlcihuYXZpZ2F0aW9uU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZSA9IG5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIE5hdkJhckNvbnRyb2xsZXIucHJvdG90eXBlLmdvSG9tZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UuZ29Ib21lKCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5hdkJhckNvbnRyb2xsZXIucHJvdG90eXBlLmdvQmFjayA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UuZ29CYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBOYXZCYXJDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gTmF2QmFyRGlyZWN0aXZlKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdAJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2dvQmlnOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFtYnVyZ3VlcjogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJhY2s6ICc9J1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnY29yZS90ZW1wbGF0ZXMvbmF2LWJhci50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6IE5hdkJhckNvbnRyb2xsZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCdcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLmRpcmVjdGl2ZSgnc2tpTmF2QmFyJywgTmF2QmFyRGlyZWN0aXZlKTtcbiAgICAgICAgICAgIH0pKERpcmVjdGl2ZXMgPSBDb3JlLkRpcmVjdGl2ZXMgfHwgKENvcmUuRGlyZWN0aXZlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSYXRpbmdEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBkZWZhdWx0Q2xhc3NlcyA9ICdpY29uICc7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGxpbmsoc2NvcGUsIGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2NvcGUudmFsdWU7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXBwZW5kKGFuZ3VsYXIuZWxlbWVudChcIjxzcGFuIGNsYXNzPVxcXCJcIiArIGRlZmF1bHRDbGFzc2VzICsgc2NvcGUuY2xhc3NPbiArIFwiXFxcIi8+XCIpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGogPSBzY29wZS52YWx1ZTsgaiA8IHNjb3BlLm1heDsgaisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hcHBlbmQoYW5ndWxhci5lbGVtZW50KFwiPHNwYW4gY2xhc3M9XFxcIlwiICsgZGVmYXVsdENsYXNzZXMgKyBzY29wZS5jbGFzc09mZiArIFwiXFxcIi8+XCIpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heDogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzT246ICdAJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc09mZjogJ0AnXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgbGluazogbGlua1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lSYXRpbmcnLCBSYXRpbmdEaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgdmFyIFNlbGVjdENvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBTZWxlY3RDb250cm9sbGVyKCRzY29wZSwgJGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlID0gJHNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kZWxlbWVudCA9ICRlbGVtZW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jbGFzc2VzID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGFsT3BlbmVkOiAnc2tpLXNlbGVjdC1tb2RhbC0tb3BlbmVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2VsZWN0b3JzID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZGFsOiAnLnNraS1zZWxlY3QtbW9kYWwnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFNlbGVjdENvbnRyb2xsZXIucHJvdG90eXBlLnNob3dNb2RhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLiRzY29wZS5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGVsZW1lbnQuZmluZCh0aGlzLnNlbGVjdG9ycy5tb2RhbCkuYWRkQ2xhc3ModGhpcy5jbGFzc2VzLm1vZGFsT3BlbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0Q29udHJvbGxlci5wcm90b3R5cGUuY2xvc2VNb2RhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGVsZW1lbnQuZmluZCh0aGlzLnNlbGVjdG9ycy5tb2RhbCkucmVtb3ZlQ2xhc3ModGhpcy5jbGFzc2VzLm1vZGFsT3BlbmVkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0Q29udHJvbGxlci5wcm90b3R5cGUudXBkYXRlU2VsZWN0aW9uID0gZnVuY3Rpb24gKG9wdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuJHNjb3BlLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUubW9kZWwgPSBvcHRpb247XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNsb3NlTW9kYWwoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0Q29udHJvbGxlci5wcm90b3R5cGUucmVzZXRTZWxlY3Rpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnVwZGF0ZVNlbGVjdGlvbignJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTZWxlY3RDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gU2VsZWN0RGlyZWN0aXZlKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kZWw6ICc9JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcjogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdE9wdGlvbnM6ICc9JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZDogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdAJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZDogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhhc1RhYnM6ICdAJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnY29yZS90ZW1wbGF0ZXMvc2VsZWN0LnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogU2VsZWN0Q29udHJvbGxlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lTZWxlY3QnLCBTZWxlY3REaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm9EaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZToge30sXG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9zdW1tYXJ5LWluZm8udGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnU3VtbWFyeUluZm9Db250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lTdW1tYXJ5SW5mbycsIFN1bW1hcnlJbmZvRGlyZWN0aXZlKTtcbiAgICAgICAgICAgIH0pKERpcmVjdGl2ZXMgPSBDb3JlLkRpcmVjdGl2ZXMgfHwgKENvcmUuRGlyZWN0aXZlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBGaWx0ZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChGaWx0ZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJhbmdlKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGlucHV0LCBfbWluLCBfbWF4KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWluID0gcGFyc2VJbnQoX21pbiwgMTApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1heCA9IHBhcnNlSW50KF9tYXgsIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSBtaW47IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlucHV0LnB1c2goaSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gaW5wdXQ7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcignc2tpUmFuZ2UnLCBSYW5nZSk7XG4gICAgICAgICAgICB9KShGaWx0ZXJzID0gUmVudGFsLkZpbHRlcnMgfHwgKFJlbnRhbC5GaWx0ZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBDb25maWdTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gQ29uZmlnU2VydmljZSgkbG9nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkdlbmVyYWwgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRmFrZUdlb2xvY2F0aW9uOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdlb2xvY2F0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiA0MC43MjI4NDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvbmdpdHVkZTogLTc0LjAwNzMyNVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkFQSSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBVUkw6ICcvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXRoOiAnYXBpLydcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkF1dGhlbnRpY2F0aW9uID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYW50VHlwZTogJ3Bhc3N3b3JkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGllbnRJRDogJ1NreVJlc29ydCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpZW50U2VjcmV0OiAnc2VjcmV0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTY29wZTogJ2FwaSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAkbG9nLmluZm8oJ0NvbmZpZ1NlcnZpY2UgaW5pdGlhbGl6ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpb25pYy5QbGF0Zm9ybS5pc1dlYlZpZXcoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRsb2cuaW5mbygnIC0gV2ViVmlldyBkZXRlY3RlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQVBJLlVSTCA9ICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJGxvZy5pbmZvKCctIEJyb3dzZXIgZGV0ZWN0ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQ29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkNvbmZpZ1NlcnZpY2UgPSBDb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdjb25maWdTZXJ2aWNlJywgQ29uZmlnU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IENvcmUuU2VydmljZXMgfHwgKENvcmUuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFBJMTgwID0gMC4wMTc0NTMyOTI1MTk5NDMyOTU7IC8vIChNYXRoLlBJLzE4MClcbiAgICAgICAgICAgICAgICB2YXIgR2VvU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEdlb1NlcnZpY2UoJHEsIGNvbmZpZ1NlcnZpY2UsICRsb2cpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU2VydmljZSA9IGNvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRsb2cgPSAkbG9nO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEdlb1NlcnZpY2UucHJvdG90eXBlLmdlb2xvY2F0aW9uQXBpQXZhaWxhYmxlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIChuYXZpZ2F0b3IuZ2VvbG9jYXRpb24gJiYgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIEdlb1NlcnZpY2UucHJvdG90eXBlLmdldFBvc2l0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kbG9nLmluZm8oJ0dlb2xvY2F0aW9uIHJlcXVlc3RlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChfdGhpcy5jb25maWdTZXJ2aWNlLkdlbmVyYWwuRmFrZUdlb2xvY2F0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRsb2cuaW5mbygnLSBSZXR1cm5pbmcgZmFrZSBnZW9sb2NhdGlvbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKF90aGlzLmNvbmZpZ1NlcnZpY2UuR2VuZXJhbC5HZW9sb2NhdGlvbik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKF90aGlzLmdlb2xvY2F0aW9uQXBpQXZhaWxhYmxlKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmF2aWdhdG9yLmdlb2xvY2F0aW9uLmdldEN1cnJlbnRQb3NpdGlvbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYXRpdHVkZTogcmVzdWx0LmNvb3Jkcy5sYXRpdHVkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb25naXR1ZGU6IHJlc3VsdC5jb29yZHMubG9uZ2l0dWRlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy53YXJuKCctIEdlb2xvY2F0aW9uIEFQSSBub3QgYXZhaWxhYmxlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBHZW9TZXJ2aWNlLnByb3RvdHlwZS5nZXREaXN0YW5jZUJldHdlZW4gPSBmdW5jdGlvbiAoYSwgYikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHAgPSBQSTE4MDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjID0gTWF0aC5jb3M7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgciA9IDAuNSAtIGMoKGEubGF0aXR1ZGUgLSBiLmxhdGl0dWRlKSAqIHApIC8gMiArIGMoYi5sYXRpdHVkZSAqIHApICpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjKGEubGF0aXR1ZGUgKiBwKSAqICgxIC0gYygoYS5sb25naXR1ZGUgLSBiLmxvbmdpdHVkZSkgKiBwKSkgLyAyO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9ICgxMjc0MiAqIE1hdGguYXNpbihNYXRoLnNxcnQocikpICogMC42MjEzNzEpOyAvLyAyICogUjsgUiA9IDYzNzEga21cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBNYXRoLnJvdW5kKHJlc3VsdCAqIDFlMikgLyAxZTI7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBHZW9TZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuR2VvU2VydmljZSA9IEdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2dlb1NlcnZpY2UnLCBHZW9TZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQ29yZS5TZXJ2aWNlcyB8fCAoQ29yZS5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTmF2aWdhdGlvblNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBOYXZpZ2F0aW9uU2VydmljZSgkc3RhdGUsICRpb25pY0hpc3RvcnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlID0gJHN0YXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNIaXN0b3J5ID0gJGlvbmljSGlzdG9yeTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBOYXZpZ2F0aW9uU2VydmljZS5wcm90b3R5cGUub3BlbkxvZ2luID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGJhc2VVcmwgPSBsb2NhdGlvbi5ocmVmLnJlcGxhY2UobG9jYXRpb24uaGFzaCwgJycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYXRpb24ucmVwbGFjZShiYXNlVXJsICsgJyMvbG9naW4nKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmF2aWdhdGlvblNlcnZpY2UucHJvdG90eXBlLmNsb3NlTG9naW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgYmFzZVVybCA9IGxvY2F0aW9uLmhyZWYucmVwbGFjZShsb2NhdGlvbi5oYXNoLCAnJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhdGlvbi5yZXBsYWNlKGJhc2VVcmwgKyAnIy9ob21lJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0hvbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkubmV4dFZpZXdPcHRpb25zKHsgZGlzYWJsZUJhY2s6IHRydWUsIGhpc3RvcnlSb290OiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUuZ28oJ2FwcC5ob21lJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0JhY2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobG9jYXRpb24uaGFzaCA9PT0gXCIjL2xvZ2luXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNsb3NlTG9naW4oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpb25pYy5QbGF0Zm9ybVsnaXMnXSgnYnJvd3NlcicpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGlvbmljSGlzdG9yeS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBOYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLk5hdmlnYXRpb25TZXJ2aWNlID0gTmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ25hdmlnYXRpb25TZXJ2aWNlJywgTmF2aWdhdGlvblNlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBDb3JlLlNlcnZpY2VzIHx8IChDb3JlLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBTdW1tYXJ5SW5mb0FQSSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFN1bW1hcnlJbmZvQVBJKCRxLCAkaHR0cCwgY29uZmlnU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBTdW1tYXJ5SW5mb0FQSS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJzdW1tYXJpZXNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCkudGhlbihmdW5jdGlvbiAocmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN1bW1hcnlJbmZvQVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuU3VtbWFyeUluZm9BUEkgPSBTdW1tYXJ5SW5mb0FQSTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnc3VtbWFyeUluZm9BUEknLCBTdW1tYXJ5SW5mb0FQSSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IENvcmUuU2VydmljZXMgfHwgKENvcmUuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMZXZlbE9mTm9pc2UgPSBEaW5pbmcuTW9kZWxzLkxldmVsT2ZOb2lzZTtcbiAgICAgICAgICAgICAgICB2YXIgRGluaW5nRGV0YWlsQ29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIERpbmluZ0RldGFpbENvbnRyb2xsZXIoJHN0YXRlUGFyYW1zLCBkaW5pbmdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGVQYXJhbXMgPSAkc3RhdGVQYXJhbXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpbmluZ1NlcnZpY2UgPSBkaW5pbmdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZWNvbW1lbmRhdGlvbnMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpZCA9ICRzdGF0ZVBhcmFtc1snaWQnXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghJHN0YXRlUGFyYW1zWydyZXN0YXVyYW50J10pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpbmluZ1NlcnZpY2UuZ2V0U2luZ2xlKGlkKS50aGVuKGZ1bmN0aW9uIChyZXN0YXVyYW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlc3RhdXJhbnQgPSByZXN0YXVyYW50O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5nZXRFeHRyYUluZm9ybWF0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc3RhdXJhbnQgPSAkc3RhdGVQYXJhbXNbJ3Jlc3RhdXJhbnQnXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldEV4dHJhSW5mb3JtYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBEaW5pbmdEZXRhaWxDb250cm9sbGVyLnByb3RvdHlwZS5nZXRFeHRyYUluZm9ybWF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZS5nZXRSZWNvbW1lbmRhdGlvbnModGhpcy5yZXN0YXVyYW50LnJlc3RhdXJhbnRJZC50b1N0cmluZygpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN0YXVyYW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlY29tbWVuZGF0aW9ucyA9IHJlc3RhdXJhbnRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdEZXRhaWxDb250cm9sbGVyLnByb3RvdHlwZS5nZXRJbWFnZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGluaW5nU2VydmljZS5nZXRJbWFnZShpZCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldExldmVsT2ZOb2lzZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExldmVsT2ZOb2lzZVtpZF07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBEaW5pbmdEZXRhaWxDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignRGluaW5nRGV0YWlsQ29udHJvbGxlcicsIERpbmluZ0RldGFpbENvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBEaW5pbmcuQ29udHJvbGxlcnMgfHwgKERpbmluZy5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExldmVsT2ZOb2lzZSA9IERpbmluZy5Nb2RlbHMuTGV2ZWxPZk5vaXNlO1xuICAgICAgICAgICAgICAgIHZhciBEaW5pbmdDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gRGluaW5nQ29udHJvbGxlcihkaW5pbmdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpbmluZ1NlcnZpY2UgPSBkaW5pbmdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZXRSZXN0YXVyYW50cygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5maWxsRmlsdGVycygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcmRlckJ5ID0gJyc7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0UmVzdGF1cmFudHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZS5nZXROZWFyKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdGF1cmFudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZXN0YXVyYW50cyA9IHJlc3RhdXJhbnRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0NvbnRyb2xsZXIucHJvdG90eXBlLmZpbGxGaWx0ZXJzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5maWx0ZXJzID0gdGhpcy5kaW5pbmdTZXJ2aWNlLmdldEZpbHRlcnMoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0SW1hZ2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRpbmluZ1NlcnZpY2UuZ2V0SW1hZ2UoaWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdDb250cm9sbGVyLnByb3RvdHlwZS5nZXRMZXZlbE9mTm9pc2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBMZXZlbE9mTm9pc2VbaWRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gRGluaW5nQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ0RpbmluZ0NvbnRyb2xsZXInLCBEaW5pbmdDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gRGluaW5nLkNvbnRyb2xsZXJzIHx8IChEaW5pbmcuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBEaW5pbmdBUEkgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBEaW5pbmdBUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0FQSS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZXN0YXVyYW50c1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdBUEkucHJvdG90eXBlLmdldE5lYXIgPSBmdW5jdGlvbiAobGF0aXR1ZGUsIGxvbmdpdHVkZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAoKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVzdGF1cmFudHMvbmVhcmJ5XCIpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKFwiP2xhdGl0dWRlPVwiICsgbGF0aXR1ZGUpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKFwiJmxvbmdpdHVkZT1cIiArIGxvbmdpdHVkZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpLnRoZW4oZnVuY3Rpb24gKHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cy5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0FQSS5wcm90b3R5cGUuZ2V0UmVjb21tZW5kYXRpb25zID0gZnVuY3Rpb24gKHNlYXJjaHRleHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVzdGF1cmFudHMvcmVjb21tZW5kYXRpb25zL1wiICsgc2VhcmNodGV4dCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCkudGhlbihmdW5jdGlvbiAocmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQVBJLnByb3RvdHlwZS5nZXRTaW5nbGUgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVzdGF1cmFudHMvXCIgKyBpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCkudGhlbihmdW5jdGlvbiAocmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQVBJLnByb3RvdHlwZS5nZXRJbWFnZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlc3RhdXJhbnRzL3Bob3RvL1wiICsgaWQ7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBEaW5pbmdBUEk7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5EaW5pbmdBUEkgPSBEaW5pbmdBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnZGluaW5nQVBJJywgRGluaW5nQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gRGluaW5nLlNlcnZpY2VzIHx8IChEaW5pbmcuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBEaW5pbmdTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gRGluaW5nU2VydmljZSgkcSwgZGluaW5nQVBJLCBnZW9TZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpbmluZ0FQSSA9IGRpbmluZ0FQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxhdGl0dWRlID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9uZ2l0dWRlID0gMDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXREaXN0YW5jZSA9IGZ1bmN0aW9uIChsYXRpdHVkZSwgbG9uZ2l0dWRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5nZW9TZXJ2aWNlLmdldERpc3RhbmNlQmV0d2Vlbih7IGxhdGl0dWRlOiBsYXRpdHVkZSwgbG9uZ2l0dWRlOiBsb25naXR1ZGUgfSwgeyBsYXRpdHVkZTogdGhpcy5sYXRpdHVkZSwgbG9uZ2l0dWRlOiB0aGlzLmxvbmdpdHVkZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuY2FsY3VsYXRlRGlzdGFuY2VzID0gZnVuY3Rpb24gKHJlc3RhdXJhbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IHJlc3RhdXJhbnRzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RhdXJhbnRzW2ldLmRpc3RhbmNlID0gdGhpcy5nZXREaXN0YW5jZShyZXN0YXVyYW50c1tpXS5sYXRpdHVkZSwgcmVzdGF1cmFudHNbaV0ubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN0YXVyYW50cztcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGluaW5nQVBJLmdldEFsbCgpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXROZWFyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmdlb1NlcnZpY2UuZ2V0UG9zaXRpb24oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxhdGl0dWRlID0gcmVzdWx0LmxhdGl0dWRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb25naXR1ZGUgPSByZXN1bHQubG9uZ2l0dWRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuZGluaW5nQVBJLmdldE5lYXIoX3RoaXMubGF0aXR1ZGUsIF90aGlzLmxvbmdpdHVkZSkudGhlbihmdW5jdGlvbiAocmVzdGF1cmFudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNvbHZlKF90aGlzLmNhbGN1bGF0ZURpc3RhbmNlcyhyZXN0YXVyYW50cykpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXRSZWNvbW1lbmRhdGlvbnMgPSBmdW5jdGlvbiAoX3NlYXJjaHRleHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc2VhcmNodGV4dFNwbGl0dGVkID0gX3NlYXJjaHRleHQuc3BsaXQoJyAnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzZWFyY2h0ZXh0ID0gc2VhcmNodGV4dFNwbGl0dGVkW3NlYXJjaHRleHRTcGxpdHRlZC5sZW5ndGggLSAxXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmRpbmluZ0FQSS5nZXRSZWNvbW1lbmRhdGlvbnMoc2VhcmNodGV4dCkudGhlbihmdW5jdGlvbiAoaWRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN0YXVyYW50cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcHJvbWlzZXMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGwgPSBpZHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcm9taXNlcy5wdXNoKChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmdldFNpbmdsZShpZHNbaV0pLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdGF1cmFudHMucHVzaChyZXN0YXVyYW50KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRxLmFsbChwcm9taXNlcykudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3RhdXJhbnRzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0U2luZ2xlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kaW5pbmdBUEkuZ2V0U2luZ2xlKGlkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0RmlsdGVycyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJy1yYXRpbmcnLCBsYWJlbDogJ1JhdGluZycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnbGV2ZWxPZk5vaXNlJywgbGFiZWw6ICdMZXZlbCBOb2lzZScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAncHJpY2VMZXZlbCcsIGxhYmVsOiAnUHJpY2UnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2Rpc3RhbmNlJywgbGFiZWw6ICdNaWxlcyBBd2F5JyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICctZmFtaWx5RnJpZW5kbHknLCBsYWJlbDogJ0ZhbWlseSBGcmllbmRseScgfVxuICAgICAgICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0SW1hZ2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRpbmluZ0FQSS5nZXRJbWFnZShpZCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBEaW5pbmdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuRGluaW5nU2VydmljZSA9IERpbmluZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnZGluaW5nU2VydmljZScsIERpbmluZ1NlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBEaW5pbmcuU2VydmljZXMgfHwgKERpbmluZy5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEhvbWU7XG4gICAgICAgIChmdW5jdGlvbiAoSG9tZSkge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgdmFyIEhvbWVDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBIb21lQ29udHJvbGxlcigkc2NvcGUsIGF1dGhTZXJ2aWNlLCBhdXRoSW1hZ2VTZXJ2aWNlLCBuYXZpZ2F0aW9uU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoU2VydmljZSA9IGF1dGhTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhJbWFnZVNlcnZpY2UgPSBhdXRoSW1hZ2VTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlID0gbmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIEhvbWVDb250cm9sbGVyLnByb3RvdHlwZS5nZXRJbWFnZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5hdXRoSW1hZ2VTZXJ2aWNlLmdldChpZCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBIb21lQ29udHJvbGxlci5wcm90b3R5cGUuZ29Mb2dpbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5vcGVuTG9naW4oKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHJldHVybiBIb21lQ29udHJvbGxlcjtcbiAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmhvbWUnKVxuICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdIb21lQ29udHJvbGxlcicsIEhvbWVDb250cm9sbGVyKTtcbiAgICAgICAgfSkoSG9tZSA9IEFwcC5Ib21lIHx8IChBcHAuSG9tZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBIb21lO1xuICAgICAgICAoZnVuY3Rpb24gKEhvbWUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gSG9tZU1lbnVEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdob21lL3RlbXBsYXRlcy9ob21lLW1lbnUudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5ob21lJylcbiAgICAgICAgICAgICAgICAgICAgLmRpcmVjdGl2ZSgnc2tpSG9tZU1lbnUnLCBIb21lTWVudURpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gSG9tZS5EaXJlY3RpdmVzIHx8IChIb21lLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShIb21lID0gQXBwLkhvbWUgfHwgKEFwcC5Ib21lID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIoJHNjb3BlLCByZW50YWxTZXJ2aWNlLCByZW50YWxBY3Rpdml0aWVzLCByZW50YWxDYXRlZ29yaWVzLCByZW50YWxHb2Fscywgc2hvZVNpemVzLCBza2lTaXplcywgcG9sZVNpemVzLCAkc3RhdGVQYXJhbXMsIHBpY2t1cEhvdXJzLCBuYXZpZ2F0aW9uU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlID0gJHNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxTZXJ2aWNlID0gcmVudGFsU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsQWN0aXZpdGllcyA9IHJlbnRhbEFjdGl2aXRpZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbENhdGVnb3JpZXMgPSByZW50YWxDYXRlZ29yaWVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxHb2FscyA9IHJlbnRhbEdvYWxzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG9lU2l6ZXMgPSBzaG9lU2l6ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNraVNpemVzID0gc2tpU2l6ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBvbGVTaXplcyA9IHBvbGVTaXplcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlUGFyYW1zID0gJHN0YXRlUGFyYW1zO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waWNrdXBIb3VycyA9IHBpY2t1cEhvdXJzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZSA9IG5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmhpZ2hEZW1hbmRBbGVydCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsID0gbmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBpY2t1cEhvdXJzLmdlbmVyYXRlQWxsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGVyZSdzIGEgcmVudGFsSWQsIHdlJ3JlIGVkaXRpbmcsIG5vdCBjcmVhdGluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCRzdGF0ZVBhcmFtcy5yZW50YWxJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0UmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc2V0UmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIHRvZGF5RGF0ZWQsIHVzZWQgYXMgJ21pbicgdmFsdWUgZm9yIHN0YXJ0RGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUudG9kYXlEYXRlLnNldEhvdXJzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZS5zZXRNaW51dGVzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZS5zZXRTZWNvbmRzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFydERhdGUgaXMgZWRpdGVkIGluIHR3byBzZXBhcmF0ZWQgaW5wdXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvLCBpdCBuZWVkcyB0byBiZSBpbiByZXBhcmF0ZWQgbW9kZWxzIGZvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVhY2ggbmctbW9kZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuc3RhcnREYXRlID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaGVzZSB2YWx1ZXMgKG9wdGlvbnMgaW4gc2VsZWN0b3JzKSBhcmUgbWFwcGVkIHRvIHRoZSBvcmlnaW5hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbnRhbCBtb2RlbCB1c2luZyAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS5yZW50YWxUZW1wID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2aXR5OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvbGVTaXplOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraVNpemU6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgc3RhcnREYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbignc3RhcnREYXRlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghJHNjb3BlLnN0YXJ0RGF0ZS5kYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuc3RhcnREYXRlID0gYW5ndWxhci5jb3B5KCRzY29wZS5zdGFydERhdGUuZGF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHNjb3BlLnN0YXJ0RGF0ZS5ob3VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbC5zdGFydERhdGUuc2V0SG91cnMoJHNjb3BlLnN0YXJ0RGF0ZS5ob3VyLmhvdXJzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLnN0YXJ0RGF0ZS5zZXRNaW51dGVzKCRzY29wZS5zdGFydERhdGUuaG91ci5taW51dGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY2hlY2tIaWdoRGVtYW5kKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhY3Rpdml0eSwgY2F0ZWdvcnksIHBvbGVTaXplIGFuZCBza2lTaXplXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbigncmVudGFsVGVtcCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuYWN0aXZpdHkgPSAkc2NvcGUucmVudGFsVGVtcC5hY3Rpdml0eSA/ICRzY29wZS5yZW50YWxUZW1wLmFjdGl2aXR5LmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuY2F0ZWdvcnkgPSAkc2NvcGUucmVudGFsVGVtcC5jYXRlZ29yeSA/ICRzY29wZS5yZW50YWxUZW1wLmNhdGVnb3J5LmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwucG9sZVNpemUgPSAkc2NvcGUucmVudGFsVGVtcC5wb2xlU2l6ZSA/ICRzY29wZS5yZW50YWxUZW1wLnBvbGVTaXplLmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuc2tpU2l6ZSA9ICRzY29wZS5yZW50YWxUZW1wLnNraVNpemUgPyAkc2NvcGUucmVudGFsVGVtcC5za2lTaXplLmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0UmVudGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbFNlcnZpY2UuZ2V0KHRoaXMuJHN0YXRlUGFyYW1zLnJlbnRhbElkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwgPSByZW50YWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMudXBkYXRlVGVtcERhdGEoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHVwZGF0ZSBhbGwgdGhlIHRlbXBvcmFsIGRhdGEgdXNlZCBpbiB0aGUgY3VzdG9tIHNlbGVjdHNcbiAgICAgICAgICAgICAgICAgICAgLy8gYmFzZWQgb24gdGhlIGFjdHVhbCByZW50YWwgb2JqZWN0LlxuICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGlzIG1ldGhvZCBpcyB1c2VkIGF0IHN0YXJ0IHdoZW4gd2UncmUgZWRpdGluZyBhIHJlbnRhbFxuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLnVwZGF0ZVRlbXBEYXRhID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGhvdXJzID0gdGhpcy5yZW50YWwuc3RhcnREYXRlLmdldEhvdXJzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWludXRlcyA9IHRoaXMucmVudGFsLnN0YXJ0RGF0ZS5nZXRNaW51dGVzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5zdGFydERhdGUgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiB0aGlzLnJlbnRhbC5zdGFydERhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cjogdGhpcy5waWNrdXBIb3Vycy5nZXRCeUlkKChob3VycyAqIDYwKSArIG1pbnV0ZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUucmVudGFsVGVtcCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eTogdGhpcy5yZW50YWxBY3Rpdml0aWVzLmdldEJ5SWQodGhpcy5yZW50YWwuYWN0aXZpdHkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB0aGlzLnJlbnRhbENhdGVnb3JpZXMuZ2V0QnlJZCh0aGlzLnJlbnRhbC5jYXRlZ29yeSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9sZVNpemU6IHRoaXMucG9sZVNpemVzLmdldEJ5SWQodGhpcy5yZW50YWwucG9sZVNpemUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraVNpemU6IHRoaXMuc2tpU2l6ZXMuZ2V0QnlJZCh0aGlzLnJlbnRhbC5za2lTaXplKVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHB1dCB0aGUgcmVudGFsIGFuZCBhbGwgdGhlIHRlbXBvcmFsIHZhbHVlcyBmb3IgY3VzdG9tXG4gICAgICAgICAgICAgICAgICAgIC8vIHNlbGVjdHMgdG8gbnVsbFxuICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGlzIG1ldGhvZCBpcyB1c2VkIGF0IHN0YXJ0IHdoZW4gd2UncmUgY3JlYXRpbmcgYSByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5yZXNldFJlbnRhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsID0gbmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpIGluIHRoaXMuJHNjb3BlLnN0YXJ0RGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLiRzY29wZS5zdGFydERhdGUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUuc3RhcnREYXRlW2ldID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciB4IGluIHRoaXMuJHNjb3BlLnJlbnRhbFRlbXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUucmVudGFsVGVtcC5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5yZW50YWxUZW1wW3hdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuZW1pdFNhdmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS4kZW1pdCgncmVudGFsX3NhdmVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuc3VibWl0UmVzZXJ2YXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucmVudGFsRm9ybS4kdmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb25Qcm9taXNlID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc3RhdGVQYXJhbXMucmVudGFsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uUHJvbWlzZSA9IHRoaXMuc2F2ZVJlc2VydmF0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25Qcm9taXNlID0gdGhpcy5hZGRSZXNlcnZhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25Qcm9taXNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLmFkZFJlc2VydmF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlbnRhbFNlcnZpY2UuYWRkKHRoaXMucmVudGFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZXNldFJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEZvcm0uJHNldFByaXN0aW5lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsRm9ybS4kc2V0VW50b3VjaGVkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuZW1pdFNhdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLnNhdmVSZXNlcnZhdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZW50YWxTZXJ2aWNlLnNhdmUodGhpcy5yZW50YWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLm5hdmlnYXRpb25TZXJ2aWNlLmdvQmFjaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuY2hlY2tIaWdoRGVtYW5kID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsU2VydmljZS5jaGVja0hpZ2hEZW1hbmQodGhpcy5yZW50YWwuc3RhcnREYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5oaWdoRGVtYW5kQWxlcnQgPSByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSGFuZGxlIGVycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5nZXRDYWxjdWxhdGVkQ29zdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsLnRvdGFsQ29zdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5yZW50YWwuc3RhcnREYXRlICYmIHRoaXMucmVudGFsLmVuZERhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbC50b3RhbENvc3QgPSAyMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGF5cyA9IE1hdGguZmxvb3IoKHRoaXMucmVudGFsLmVuZERhdGUuZ2V0VGltZSgpIC0gdGhpcy5yZW50YWwuc3RhcnREYXRlLmdldFRpbWUoKSkgLyAxMDAwIC8gNjAgLyA2MCAvIDI0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbC50b3RhbENvc3QgPSB0aGlzLnJlbnRhbC50b3RhbENvc3QgKyAoZGF5cyAqIDUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVudGFsLnRvdGFsQ29zdDtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ05ld1Jlc2VydmF0aW9uQ29udHJvbGxlcicsIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IFJlbnRhbC5Db250cm9sbGVycyB8fCAoUmVudGFsLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsc0NvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxzQ29udHJvbGxlcigkaW9uaWNUYWJzRGVsZWdhdGUsICRzY29wZSwgJHN0YXRlUGFyYW1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY1RhYnNEZWxlZ2F0ZSA9ICRpb25pY1RhYnNEZWxlZ2F0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlID0gJHNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGVQYXJhbXMgPSAkc3RhdGVQYXJhbXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJG9uKCdyZW50YWxfc2F2ZWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJGlvbmljVGFic0RlbGVnYXRlLiRnZXRCeUhhbmRsZSgnc2VjdGlvbi10YWJzJykuc2VsZWN0KDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kYnJvYWRjYXN0KCd1cGRhdGVfcmVzZXJ2YXRpb25fbGlzdCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbHNDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgQ29udHJvbGxlcnMuUmVudGFsc0NvbnRyb2xsZXIgPSBSZW50YWxzQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdSZW50YWxzQ29udHJvbGxlcicsIFJlbnRhbHNDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gUmVudGFsLkNvbnRyb2xsZXJzIHx8IChSZW50YWwuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZXNlcnZhdGlvbkxpc3RDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlcigkc2NvcGUsIHJlbnRhbFNlcnZpY2UsICRzdGF0ZSwgJHRpbWVvdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsU2VydmljZSA9IHJlbnRhbFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZSA9ICRzdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHRpbWVvdXQgPSAkdGltZW91dDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd01lc3NhZ2UgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0UmVudGFscygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiRvbigndXBkYXRlX3Jlc2VydmF0aW9uX2xpc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuZ2V0UmVudGFscygpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2hvd01lc3NhZ2UgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlci5wcm90b3R5cGUuZ2V0UmVudGFscyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVudGFsU2VydmljZS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFscyA9IGRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlci5wcm90b3R5cGUubmF2aWdhdGVUb1JlbnRhbCA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpbmdSZW50YWwgPSByZW50YWw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiR0aW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kc3RhdGUuZ28oJ2FwcC5yZW50YWwtZGV0YWlsJywgeyByZW50YWxJZDogcmVudGFsLnJlbnRhbElkIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdSZXNlcnZhdGlvbkxpc3RDb250cm9sbGVyJywgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IFJlbnRhbC5Db250cm9sbGVycyB8fCAoUmVudGFsLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIEZpbHRlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKEZpbHRlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsQWN0aXZpdHlGaWx0ZXIoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaW5wdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5W2lucHV0XTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKCdza2lSZW50YWxBY3Rpdml0eScsIFJlbnRhbEFjdGl2aXR5RmlsdGVyKTtcbiAgICAgICAgICAgIH0pKEZpbHRlcnMgPSBSZW50YWwuRmlsdGVycyB8fCAoUmVudGFsLkZpbHRlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgRmlsdGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRmlsdGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxDYXRlZ29yeUZpbHRlcigpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChpbnB1dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbC5Nb2RlbHMuUmVudGFsQ2F0ZWdvcnlbaW5wdXRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoJ3NraVJlbnRhbENhdGVnb3J5JywgUmVudGFsQ2F0ZWdvcnlGaWx0ZXIpO1xuICAgICAgICAgICAgfSkoRmlsdGVycyA9IFJlbnRhbC5GaWx0ZXJzIHx8IChSZW50YWwuRmlsdGVycyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFBpY2t1cEhvdXJzID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUGlja3VwSG91cnMoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFBpY2t1cEhvdXJzLnByb3RvdHlwZS5nZXRCeUlkID0gZnVuY3Rpb24gKGkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfaG91cnMgPSBNYXRoLmZsb29yKGkgLyA2MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX21pbnV0ZXMgPSBpIC0gKF9ob3VycyAqIDYwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBob3VycyA9IF9ob3VycztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW51dGVzID0gX21pbnV0ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWVyID0gJ2FtJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChob3VycyA+IDEyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnMgPSBob3VycyAtIDEyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lciA9ICdwbSc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaG91cnNfc3RyID0gaG91cnMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW51dGVzX3N0ciA9IG1pbnV0ZXMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChob3Vyc19zdHIubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnNfc3RyID0gJzAnICsgaG91cnNfc3RyO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1pbnV0ZXNfc3RyLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbnV0ZXNfc3RyID0gJzAnICsgbWludXRlc19zdHI7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBob3Vyc19zdHIgKyBcIjpcIiArIG1pbnV0ZXNfc3RyICsgXCIgXCIgKyBtZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnM6IF9ob3VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGVzOiBfbWludXRlc1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUGlja3VwSG91cnMucHJvdG90eXBlLmdlbmVyYXRlQWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1pbk1pbnV0ZXMgPSAzNjA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWF4TWludXRlcyA9IDEyMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RlcHMgPSAxNTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSBtaW5NaW51dGVzOyBpIDw9IG1heE1pbnV0ZXM7IGkgPSBpICsgc3RlcHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh0aGlzLmdldEJ5SWQoaSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGwgPSByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBQaWNrdXBIb3VycztcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlBpY2t1cEhvdXJzID0gUGlja3VwSG91cnM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncGlja3VwSG91cnMnLCBQaWNrdXBIb3Vycyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBQb2xlU2l6ZXMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDMyOyBpIDw9IDU3OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaSArICcgaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IGlkICsgJyBpbicgfSk7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGw6IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5Qb2xlU2l6ZXMgPSBQb2xlU2l6ZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncG9sZVNpemVzJywgUG9sZVNpemVzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlbnRhbEFjdGl2aXRpZXMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IFJlbnRhbC5Nb2RlbHMuUmVudGFsQWN0aXZpdHlbaWRdIH0pOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsOiBPYmplY3Qua2V5cyhSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuIHBhcnNlSW50KGksIDEwKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChpKSB7IHJldHVybiAhaXNOYU4oaSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoaSkgeyByZXR1cm4gKHsgaWQ6IGksIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5W2ldIH0pOyB9KVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxBY3Rpdml0aWVzID0gUmVudGFsQWN0aXZpdGllcztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxBY3Rpdml0aWVzJywgUmVudGFsQWN0aXZpdGllcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxDYXRlZ29yaWVzKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QnlJZDogZnVuY3Rpb24gKGlkKSB7IHJldHVybiAoeyBpZDogaWQsIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbENhdGVnb3J5W2lkXSB9KTsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbDogT2JqZWN0LmtleXMoUmVudGFsLk1vZGVscy5SZW50YWxDYXRlZ29yeSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpKSB7IHJldHVybiBwYXJzZUludChpLCAxMCk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoaSkgeyByZXR1cm4gIWlzTmFOKGkpICYmIGkgIT09IDA7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoaSkgeyByZXR1cm4gKHsgaWQ6IGksIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbENhdGVnb3J5W2ldIH0pOyB9KVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxDYXRlZ29yaWVzID0gUmVudGFsQ2F0ZWdvcmllcztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxDYXRlZ29yaWVzJywgUmVudGFsQ2F0ZWdvcmllcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxHb2FscygpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKFJlbnRhbC5Nb2RlbHMuUmVudGFsR29hbClcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuIHBhcnNlSW50KGksIDEwKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICFpc05hTihpKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICh7IGlkOiBpLCBsYWJlbDogUmVudGFsLk1vZGVscy5SZW50YWxHb2FsW2ldIH0pOyB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuUmVudGFsR29hbHMgPSBSZW50YWxHb2FscztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxHb2FscycsIFJlbnRhbEdvYWxzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxBUEkgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxBUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKHJlbnRhbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFscy9cIiArIHJlbnRhbElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kaHR0cChyZXF1ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFsc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kaHR0cChyZXF1ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlbnRhbHNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5zYXZlID0gZnVuY3Rpb24gKHJlbnRhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZW50YWxzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5jaGVja0hpZ2hEZW1hbmQgPSBmdW5jdGlvbiAoZGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZW50YWxzL2NoZWNrX2hpZ2hfZGVtYW5kP2RhdGU9XCIgKyBkYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbEFQSTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlJlbnRhbEFQSSA9IFJlbnRhbEFQSTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxBUEknLCBSZW50YWxBUEkpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxTZXJ2aWNlKCRxLCByZW50YWxBUEksIGdlb1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsQVBJID0gcmVudGFsQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZW9TZXJ2aWNlID0gZ2VvU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAocmVudGFsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLmdldChyZW50YWxJZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUobmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCkuc2VyaWFsaXplKHJlc3BvbnNlLmRhdGEpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBSZW50YWwuTW9kZWxzLlJlbnRhbCgpLnNlcmlhbGl6ZShpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbFNlcnZpY2UucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLmFkZChyZW50YWwuZGVzZXJpYWxpemUoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsU2VydmljZS5wcm90b3R5cGUuc2F2ZSA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLnNhdmUocmVudGFsLmRlc2VyaWFsaXplKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbFNlcnZpY2UucHJvdG90eXBlLmNoZWNrSGlnaERlbWFuZCA9IGZ1bmN0aW9uIChkYXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5jaGVja0hpZ2hEZW1hbmQoZGF0ZS50b0lTT1N0cmluZygpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVudGFsU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlJlbnRhbFNlcnZpY2UgPSBSZW50YWxTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3JlbnRhbFNlcnZpY2UnLCBSZW50YWxTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNob2VTaXplcygpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsxLCAyLCAzLCA0LCA0LjUsIDUsIDUuNSwgNiwgNi41LCA3LCA3LjUsIDgsIDguNSwgOSwgOS41LCAxMCwgMTAuNSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDExLCAxMS41LCAxMiwgMTIuNSwgMTMsIDEzLjUsIDE0LCAxNC41LCAxNSwgMTUuNSwgMTYsIDE2LjVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5TaG9lU2l6ZXMgPSBTaG9lU2l6ZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnc2hvZVNpemVzJywgU2hvZVNpemVzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNraVNpemVzKCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAxMTU7IGkgPD0gMjAwOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaSArICcgaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IGlkICsgJyBpbicgfSk7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGw6IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5Ta2lTaXplcyA9IFNraVNpemVzO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3NraVNpemVzJywgU2tpU2l6ZXMpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcihsaWZ0U2VydmljZSwgJHN0YXRlUGFyYW1zLCBnZW9TZXJ2aWNlLCAkc2NvcGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxpZnRTZXJ2aWNlID0gbGlmdFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZVBhcmFtcyA9ICRzdGF0ZVBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51c2VyR2VvbG9jYXRpb24gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXN0YW5jZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldExpZnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kd2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdldERpc3RhbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0TGlmdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZS5nZXQodGhpcy4kc3RhdGVQYXJhbXMubGlmdElkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChsaWZ0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGlmdCA9IGxpZnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSGFuZGxlIGVycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldERpc3RhbmNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnVzZXJHZW9sb2NhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsY0Rpc3RhbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb1NlcnZpY2UuZ2V0UG9zaXRpb24oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy51c2VyR2VvbG9jYXRpb24gPSBkYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5jYWxjRGlzdGFuY2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmNhbGNEaXN0YW5jZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmxpZnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpc3RhbmNlID0gdGhpcy5nZW9TZXJ2aWNlLmdldERpc3RhbmNlQmV0d2Vlbih0aGlzLnVzZXJHZW9sb2NhdGlvbiwgeyBsYXRpdHVkZTogdGhpcy5saWZ0LmxhdGl0dWRlLCBsb25naXR1ZGU6IHRoaXMubGlmdC5sb25naXR1ZGUgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcicsIExpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gTGlmdC5Db250cm9sbGVycyB8fCAoTGlmdC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyKGxpZnRTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxpZnRTZXJ2aWNlID0gbGlmdFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldExpZnRzKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyLnByb3RvdHlwZS5nZXRMaWZ0cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZS5nZXROZWFyKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmRpZ2VzdExpZnRzKGRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlci5wcm90b3R5cGUuZGlnZXN0TGlmdHMgPSBmdW5jdGlvbiAobGlmdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9wZW5MaWZ0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZWRMaWZ0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGlmdHMuZm9yRWFjaChmdW5jdGlvbiAobGlmdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsaWZ0LnN0YXR1cyA9PT0gTGlmdC5Nb2RlbHMuTGlmdFN0YXR1cy5PcGVuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLm9wZW5MaWZ0cy5wdXNoKGxpZnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChsaWZ0LnN0YXR1cyA9PT0gTGlmdC5Nb2RlbHMuTGlmdFN0YXR1cy5DbG9zZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY2xvc2VkTGlmdHMucHVzaChsaWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXInLCBMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBMaWZ0LkNvbnRyb2xsZXJzIHx8IChMaWZ0LkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMaWZ0QVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdEFQSSgkcSwgJGh0dHAsIGNvbmZpZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGh0dHAgPSAkaHR0cDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU2VydmljZSA9IGNvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdEFQSS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAoX3RoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgX3RoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcImxpZnRzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRodHRwKHJlcXVlc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0QVBJLnByb3RvdHlwZS5nZXROZWFyID0gZnVuY3Rpb24gKGxhdGl0dWRlLCBsb25naXR1ZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwibGlmdHMvbmVhcmJ5XCIpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcIj9sYXRpdHVkZT1cIiArIGxhdGl0dWRlKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoXCImbG9uZ2l0dWRlPVwiICsgbG9uZ2l0dWRlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGh0dHAocmVxdWVzdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0QVBJLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwibGlmdHMvXCIgKyBpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0QVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTGlmdEFQSSA9IExpZnRBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5saWZ0JylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2xpZnRBUEknLCBMaWZ0QVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gTGlmdC5TZXJ2aWNlcyB8fCAoTGlmdC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMaWZ0U2VydmljZSgkcSwgbGlmdEFQSSwgZ2VvU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0QVBJID0gbGlmdEFQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGlmdEFQSS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldE5lYXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdlb1NlcnZpY2UuZ2V0UG9zaXRpb24oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5saWZ0QVBJLmdldE5lYXIocmVzdWx0LmxhdGl0dWRlLCByZXN1bHQubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5saWZ0QVBJLmdldChpZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKHJlc3VsdC5kYXRhKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExpZnRTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTGlmdFNlcnZpY2UgPSBMaWZ0U2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnbGlmdFNlcnZpY2UnLCBMaWZ0U2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IExpZnQuU2VydmljZXMgfHwgKExpZnQuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbiJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
