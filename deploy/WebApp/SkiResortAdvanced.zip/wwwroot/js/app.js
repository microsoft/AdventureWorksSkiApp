/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    'use strict';
    var App;
    (function (App) {
        angular.module('app', [
            'ionic',
            'app.core',
            'app.auth',
            'app.home',
            'app.lift',
            'app.dining',
            'app.rental'
        ]);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        run.$inject = ["$ionicPlatform", "$log"];
        function run($ionicPlatform, $log) {
            $ionicPlatform.ready(deviceReady.call(this, $log));
        }
        function deviceReady($log) {
            $log.info('Device Ready');
        }
        angular.module('app')
            .run(run);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Auth;
        (function (Auth) {
            angular.module('app.auth', []);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Core;
        (function (Core) {
            angular.module('app.core', []);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Dining;
        (function (Dining) {
            angular.module('app.dining', []);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Home;
        (function (Home) {
            angular.module('app.home', []);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Lift;
        (function (Lift) {
            angular.module('app.lift', []);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Rental;
        (function (Rental) {
            angular.module('app.rental', []);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.login', {
                    url: '/login',
                    views: {
                        'content': {
                            controller: 'LoginController',
                            controllerAs: '$ctrl',
                            templateUrl: 'auth/templates/login.template.html',
                        }
                    }
                });
            }
            angular.module('app.auth')
                .config(routingConfiguration);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            ionicConfiguration.$inject = ["$ionicConfigProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app', {
                    url: '',
                    abstract: true,
                    controller: 'MenuController',
                    controllerAs: '$ctrl',
                    templateUrl: 'core/templates/menu.template.html'
                });
            }
            function ionicConfiguration($ionicConfigProvider) {
                $ionicConfigProvider.scrolling.jsScrolling(false);
            }
            angular.module('app.core')
                .config(routingConfiguration)
                .config(ionicConfiguration);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.dining-list', {
                    url: '/dining/list',
                    views: {
                        'content': {
                            controller: 'DiningController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-list.template.html'
                        }
                    }
                })
                    .state('app.dining-detail', {
                    url: '/dining/detail/:id',
                    params: {
                        restaurant: null
                    },
                    views: {
                        'content': {
                            controller: 'DiningDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.dining')
                .config(routingConfiguration);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.home', {
                    url: '/home',
                    data: {
                        barColor: 'dark'
                    },
                    views: {
                        'content': {
                            controller: 'HomeController',
                            controllerAs: '$ctrl',
                            templateUrl: 'home/templates/home.template.html',
                        }
                    }
                });
                $urlRouterProvider.otherwise('/home');
            }
            angular.module('app.home')
                .config(routingConfiguration);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.lift-status-list', {
                    url: '/lift/status/list',
                    views: {
                        'content': {
                            controller: 'LiftStatusListController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-list.template.html',
                        }
                    }
                })
                    .state('app.lift-status-detail', {
                    url: '/lift/status/detail/:liftId',
                    views: {
                        'content': {
                            controller: 'LiftStatusDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.lift')
                .config(routingConfiguration);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.rentals', {
                    cache: false,
                    url: '/rentals',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/rentals.template.html',
                            controller: 'RentalsController',
                            controllerAs: '$ctrl'
                        }
                    }
                })
                    .state('app.rental-detail', {
                    cache: false,
                    url: '/rental/:rentalId',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/new-reservation-wrapper.template.html',
                            controller: 'NewReservationController',
                            controllerAs: 'tabCtrl'
                        }
                    }
                });
            }
            angular.module('app.rental')
                .config(routingConfiguration);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Auth.Models || (Auth.Models = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                var SummaryInfo = (function () {
                    function SummaryInfo() {
                    }
                    return SummaryInfo;
                }());
                Models.SummaryInfo = SummaryInfo;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                (function (Weather) {
                    Weather[Weather["Unknown"] = 0] = "Unknown";
                    Weather[Weather["Snowing"] = 1] = "Snowing";
                    Weather[Weather["Rainy"] = 2] = "Rainy";
                    Weather[Weather["Cloudy"] = 3] = "Cloudy";
                    Weather[Weather["Sunny"] = 4] = "Sunny";
                })(Models.Weather || (Models.Weather = {}));
                var Weather = Models.Weather;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LevelOfNoise) {
                    LevelOfNoise[LevelOfNoise["Unknown"] = 0] = "Unknown";
                    LevelOfNoise[LevelOfNoise["Low"] = 1] = "Low";
                    LevelOfNoise[LevelOfNoise["Medium"] = 2] = "Medium";
                    LevelOfNoise[LevelOfNoise["Loud"] = 3] = "Loud";
                })(Models.LevelOfNoise || (Models.LevelOfNoise = {}));
                var LevelOfNoise = Models.LevelOfNoise;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                var Restaurant = (function () {
                    function Restaurant() {
                    }
                    return Restaurant;
                }());
                Models.Restaurant = Restaurant;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Lift = (function () {
                    function Lift() {
                    }
                    Lift.prototype.serialize = function (data) {
                        this.liftId = data.liftId;
                        this.name = data.name;
                        this.rating = data.rating;
                        this.status = data.status;
                        this.latitude = data.latitude;
                        this.longitude = data.longitude;
                        this.stayAway = data.stayAway;
                        this.waitingTime = data.waitingTime;
                        this.closedReason = data.closedReason;
                        return this;
                    };
                    Lift.prototype.deserialize = function () {
                        return {
                            liftId: this.liftId,
                            name: this.name,
                            rating: this.rating,
                            status: this.status,
                            latitude: this.latitude,
                            longitude: this.longitude,
                            stayAway: this.stayAway,
                            waitingTime: this.waitingTime,
                            closedReason: this.closedReason
                        };
                    };
                    return Lift;
                }());
                Models.Lift = Lift;
            })(Models = Lift_1.Models || (Lift_1.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftRating) {
                    LiftRating[LiftRating["Unknown"] = 0] = "Unknown";
                    LiftRating[LiftRating["Beginner"] = 1] = "Beginner";
                    LiftRating[LiftRating["Intermediate"] = 2] = "Intermediate";
                    LiftRating[LiftRating["Advanced"] = 3] = "Advanced";
                })(Models.LiftRating || (Models.LiftRating = {}));
                var LiftRating = Models.LiftRating;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftStatus) {
                    LiftStatus[LiftStatus["Unknown"] = 0] = "Unknown";
                    LiftStatus[LiftStatus["Open"] = 1] = "Open";
                    LiftStatus[LiftStatus["Closed"] = 2] = "Closed";
                })(Models.LiftStatus || (Models.LiftStatus = {}));
                var LiftStatus = Models.LiftStatus;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Rental = (function () {
                    function Rental() {
                    }
                    Rental.prototype.serialize = function (data) {
                        this.rentalId = data.rentalId;
                        this.userEmail = data.userEmail;
                        this.startDate = new Date(data.startDate);
                        this.endDate = new Date(data.endDate);
                        this.pickupHour = data.pickupHour;
                        this.activity = data.activity;
                        this.category = data.category;
                        this.goal = data.goal;
                        this.shoeSize = data.shoeSize;
                        this.skiSize = data.skiSize;
                        this.poleSize = data.poleSize;
                        this.totalCost = data.totalCost;
                        return this;
                    };
                    Rental.prototype.deserialize = function () {
                        return {
                            rentalId: this.rentalId,
                            userEmail: this.userEmail,
                            startDate: this.startDate.toJSON(),
                            endDate: this.endDate.toJSON(),
                            pickupHour: this.pickupHour,
                            activity: this.activity,
                            category: this.category,
                            goal: this.goal,
                            shoeSize: this.shoeSize,
                            skiSize: this.skiSize,
                            poleSize: this.poleSize,
                            totalCost: this.totalCost
                        };
                    };
                    return Rental;
                }());
                Models.Rental = Rental;
            })(Models = Rental_1.Models || (Rental_1.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalActivity) {
                    RentalActivity[RentalActivity["Ski"] = 0] = "Ski";
                    RentalActivity[RentalActivity["Snowboard"] = 1] = "Snowboard";
                })(Models.RentalActivity || (Models.RentalActivity = {}));
                var RentalActivity = Models.RentalActivity;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalCategory) {
                    RentalCategory[RentalCategory["Unknown"] = 0] = "Unknown";
                    RentalCategory[RentalCategory["Beginner"] = 1] = "Beginner";
                    RentalCategory[RentalCategory["Intermediate"] = 2] = "Intermediate";
                    RentalCategory[RentalCategory["Advanced"] = 3] = "Advanced";
                })(Models.RentalCategory || (Models.RentalCategory = {}));
                var RentalCategory = Models.RentalCategory;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalGoal) {
                    RentalGoal[RentalGoal["Unknown"] = 0] = "Unknown";
                    RentalGoal[RentalGoal["Demo"] = 1] = "Demo";
                    RentalGoal[RentalGoal["Performance"] = 2] = "Performance";
                    RentalGoal[RentalGoal["Sport"] = 3] = "Sport";
                })(Models.RentalGoal || (Models.RentalGoal = {}));
                var RentalGoal = Models.RentalGoal;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LoginController = (function () {
                    LoginController.$inject = ["authService", "$ionicHistory"];
                    function LoginController(authService, $ionicHistory) {
                        this.authService = authService;
                        this.$ionicHistory = $ionicHistory;
                        this.loginData = {};
                        this.wrongPassword = false;
                        this.loading = false;
                    }
                    LoginController.prototype.login = function () {
                        var _this = this;
                        this.loading = true;
                        this.wrongPassword = false;
                        if (this.loginForm.$valid) {
                            this.authService.login(this.loginData.username, this.loginData.password)
                                .then(function () {
                                _this.$ionicHistory.goBack();
                            })
                                .catch(function () {
                                _this.wrongPassword = true;
                            })
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    return LoginController;
                }());
                angular.module('app.auth')
                    .controller('LoginController', LoginController);
            })(Controllers = Auth.Controllers || (Auth.Controllers = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthImageService = (function () {
                    AuthImageService.$inject = ["$q", "authAPI", "currentUserService", "configService"];
                    function AuthImageService($q, authAPI, currentUserService, configService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                        this.configService = configService;
                    }
                    AuthImageService.prototype.get = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "users/photo/" + id;
                    };
                    return AuthImageService;
                }());
                Services.AuthImageService = AuthImageService;
                angular.module('app.auth')
                    .service('authImageService', AuthImageService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthAPI = (function () {
                    AuthAPI.$inject = ["$http", "configService", "$httpParamSerializerJQLike"];
                    function AuthAPI($http, configService, $httpParamSerializerJQLike) {
                        this.$http = $http;
                        this.configService = configService;
                        this.$httpParamSerializerJQLike = $httpParamSerializerJQLike;
                    }
                    AuthAPI.prototype.login = function (username, password) {
                        var request = {
                            url: this.configService.API.URL + "connect/token",
                            method: 'POST',
                            data: this.$httpParamSerializerJQLike({
                                grant_type: this.configService.Authentication.GrantType,
                                client_id: this.configService.Authentication.ClientID,
                                client_secret: this.configService.Authentication.ClientSecret,
                                scope: this.configService.Authentication.Scope,
                                username: username,
                                password: password
                            }),
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            }
                        };
                        return this.$http(request);
                    };
                    return AuthAPI;
                }());
                Services.AuthAPI = AuthAPI;
                angular.module('app.auth')
                    .service('authAPI', AuthAPI);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthService = (function () {
                    AuthService.$inject = ["$q", "authAPI", "currentUserService"];
                    function AuthService($q, authAPI, currentUserService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                    }
                    AuthService.prototype.login = function (username, password) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.authAPI.login(username, password)
                                .then(function (response) {
                                _this.currentUserService.accessToken = response.data.access_token;
                                return _this.currentUserService.getInfo();
                            })
                                .then(function () {
                                resolve();
                            })
                                .catch(function (error) {
                                reject(error.data);
                            });
                        });
                    };
                    return AuthService;
                }());
                Services.AuthService = AuthService;
                angular.module('app.auth')
                    .service('authService', AuthService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var CURRENT_USER_STORAGE_KEY = '_currentUserData';
                var CurrentUserService = (function () {
                    CurrentUserService.$inject = ["$q", "$rootScope", "$http", "configService", "$log"];
                    function CurrentUserService($q, $rootScope, $http, configService, $log) {
                        this.$q = $q;
                        this.$rootScope = $rootScope;
                        this.$http = $http;
                        this.configService = configService;
                        this.$log = $log;
                        this.accessToken = null;
                        this.currentUser = null;
                        this.load();
                        if (this.accessToken) {
                            this.getInfo();
                        }
                    }
                    CurrentUserService.prototype.save = function () {
                        this.$log.info('CurrentUserService saving to LocalStorage');
                        var currentUserCopy = angular.copy(this.currentUser);
                        currentUserCopy.photo = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({
                            accessToken: this.accessToken,
                            currentUser: currentUserCopy
                        }));
                        this.$log.info('- Successfully saved');
                    };
                    CurrentUserService.prototype.load = function () {
                        this.$log.info('CurrentUserService loading from LocalStorage');
                        var storedRawData = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
                        if (storedRawData) {
                            var storedData = JSON.parse(storedRawData);
                            this.accessToken = storedData.accessToken;
                            this.currentUser = storedData.currentUser;
                            this.$rootScope.currentUser = this.currentUser;
                            this.$log.info('- Successfully loaded');
                        }
                        else {
                            this.$log.info('- LocalStorage is empty');
                        }
                    };
                    CurrentUserService.prototype.reset = function () {
                        this.$log.info('CurrentUserService resetting LocalStorage');
                        this.accessToken = null;
                        this.currentUser = null;
                        this.$rootScope.currentUser = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({}));
                        this.$log.info('- Done');
                    };
                    CurrentUserService.prototype.getInfo = function () {
                        var _this = this;
                        this.$log.info('CurrentUserService getting information');
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "users/user",
                            method: 'GET',
                            headers: {
                                'Authorization': "Bearer " + this.accessToken
                            }
                        };
                        return this.$http(request)
                            .then(function (response) {
                            _this.$log.info('- Information getted successfully');
                            _this.currentUser = response.data;
                            _this.$rootScope.currentUser = _this.currentUser;
                            _this.save();
                        })
                            .catch(function () {
                            _this.reset();
                            _this.$log.warn('- Something went wrong while getting information');
                        });
                    };
                    return CurrentUserService;
                }());
                Services.CurrentUserService = CurrentUserService;
                angular.module('app.auth')
                    .service('currentUserService', CurrentUserService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var MenuController = (function () {
                    MenuController.$inject = ["$ionicSideMenuDelegate", "$state", "currentUserService"];
                    function MenuController($ionicSideMenuDelegate, $state, currentUserService) {
                        this.$ionicSideMenuDelegate = $ionicSideMenuDelegate;
                        this.$state = $state;
                        this.currentUserService = currentUserService;
                    }
                    MenuController.prototype.navigateTo = function (toStateName) {
                        this.$state.go(toStateName);
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    MenuController.prototype.logout = function () {
                        this.currentUserService.reset();
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    return MenuController;
                }());
                angular.module('app.core')
                    .controller('MenuController', MenuController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var Weather = Core.Models.Weather;
                var SummaryInfoController = (function () {
                    SummaryInfoController.$inject = ["summaryInfoAPI", "$state"];
                    function SummaryInfoController(summaryInfoAPI, $state) {
                        var _this = this;
                        this.summaryInfoAPI = summaryInfoAPI;
                        this.$state = $state;
                        summaryInfoAPI.get().then(function (summaryInfo) {
                            _this.summaryInfo = summaryInfo;
                        });
                    }
                    SummaryInfoController.prototype.getWeather = function (id) {
                        return Weather[id];
                    };
                    return SummaryInfoController;
                }());
                angular.module('app.core')
                    .controller('SummaryInfoController', SummaryInfoController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function AvatarDirective() {
                    function setBackgroundImage(element, url) {
                        element.attr('style', 'background-image: url(\'' + url + '\');');
                    }
                    function link(scope, element, attr) {
                        element.addClass('ski-avatar');
                        attr.$observe('skiAvatar', function () {
                            setBackgroundImage(element, attr.skiAvatar);
                        });
                    }
                    return {
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiAvatar', AvatarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var NavBarController = (function () {
                    NavBarController.$inject = ["navigationService"];
                    function NavBarController(navigationService) {
                        this.navigationService = navigationService;
                    }
                    NavBarController.prototype.goHome = function () {
                        this.navigationService.goHome();
                    };
                    NavBarController.prototype.goBack = function () {
                        this.navigationService.goBack();
                    };
                    return NavBarController;
                }());
                function NavBarDirective() {
                    return {
                        restrict: 'A',
                        scope: {
                            title: '@',
                            logoBig: '=',
                            hamburguer: '=',
                            back: '='
                        },
                        templateUrl: 'core/templates/nav-bar.template.html',
                        controller: NavBarController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiNavBar', NavBarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function RatingDirective() {
                    var defaultClasses = 'icon ';
                    function link(scope, element) {
                        for (var i = 0; i < scope.value; i++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOn + "\"/>"));
                        }
                        for (var j = scope.value; j < scope.max; j++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOff + "\"/>"));
                        }
                    }
                    return {
                        scope: {
                            value: '@',
                            max: '@',
                            classOn: '@',
                            classOff: '@'
                        },
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiRating', RatingDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var SelectController = (function () {
                    SelectController.$inject = ["$scope", "$element"];
                    function SelectController($scope, $element) {
                        this.$scope = $scope;
                        this.$element = $element;
                        this.classes = {
                            modalOpened: 'ski-select-modal--opened'
                        };
                        this.selectors = {
                            modal: '.ski-select-modal'
                        };
                    }
                    SelectController.prototype.showModal = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$element.find(this.selectors.modal).addClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.closeModal = function () {
                        this.$element.find(this.selectors.modal).removeClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.updateSelection = function (option) {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$scope.model = option;
                        this.closeModal();
                    };
                    SelectController.prototype.resetSelection = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.updateSelection('');
                    };
                    return SelectController;
                }());
                function SelectDirective() {
                    return {
                        restrict: 'E',
                        scope: {
                            model: '=',
                            placeholder: '@',
                            selectOptions: '=',
                            required: '=',
                            name: '@',
                            disabled: '=',
                            hasTabs: '@'
                        },
                        templateUrl: 'core/templates/select.template.html',
                        controller: SelectController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSelect', SelectDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function SummaryInfoDirective() {
                    return {
                        scope: {},
                        restrict: 'E',
                        templateUrl: 'core/templates/summary-info.template.html',
                        controller: 'SummaryInfoController',
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSummaryInfo', SummaryInfoDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function Range() {
                    return function (input, _min, _max) {
                        var min = parseInt(_min, 10);
                        var max = parseInt(_max, 10);
                        for (var i = min; i < max; i++) {
                            input.push(i);
                        }
                        return input;
                    };
                }
                angular.module('app.rental')
                    .filter('skiRange', Range);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var ConfigService = (function () {
                    ConfigService.$inject = ["$log"];
                    function ConfigService($log) {
                        this.General = {
                            FakeGeolocation: true,
                            Geolocation: {
                                latitude: 40.722846,
                                longitude: -74.007325
                            }
                        };
                        this.API = {
                            URL: '/',
                            Path: 'api/'
                        };
                        this.Authentication = {
                            GrantType: 'password',
                            ClientID: 'SkyResort',
                            ClientSecret: 'secret',
                            Scope: 'api'
                        };
                        $log.info('ConfigService initialized');
                        if (ionic.Platform.isWebView()) {
                            $log.info(' - WebView detected');
                            this.API.URL = 'http://adventureworkskiresort.azurewebsites.net/';
                        }
                        else {
                            $log.info('- Browser detected');
                        }
                    }
                    return ConfigService;
                }());
                Services.ConfigService = ConfigService;
                angular.module('app.core')
                    .service('configService', ConfigService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var PI180 = 0.017453292519943295; // (Math.PI/180)
                var GeoService = (function () {
                    GeoService.$inject = ["$q", "configService", "$log"];
                    function GeoService($q, configService, $log) {
                        this.$q = $q;
                        this.configService = configService;
                        this.$log = $log;
                    }
                    GeoService.prototype.geolocationApiAvailable = function () {
                        return (navigator.geolocation && navigator.geolocation.getCurrentPosition);
                    };
                    GeoService.prototype.getPosition = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.$log.info('Geolocation requested');
                            if (_this.configService.General.FakeGeolocation) {
                                _this.$log.info('- Returning fake geolocation');
                                resolve(_this.configService.General.Geolocation);
                            }
                            else if (_this.geolocationApiAvailable()) {
                                navigator.geolocation.getCurrentPosition(function (result) {
                                    resolve({
                                        latitude: result.coords.latitude,
                                        longitude: result.coords.longitude
                                    });
                                }, function () {
                                    reject();
                                });
                            }
                            else {
                                _this.$log.warn('- Geolocation API not available');
                                reject();
                            }
                        });
                    };
                    GeoService.prototype.getDistanceBetween = function (a, b) {
                        var p = PI180;
                        var c = Math.cos;
                        var r = 0.5 - c((a.latitude - b.latitude) * p) / 2 + c(b.latitude * p) *
                            c(a.latitude * p) * (1 - c((a.longitude - b.longitude) * p)) / 2;
                        var result = (12742 * Math.asin(Math.sqrt(r)) * 0.621371); // 2 * R; R = 6371 km
                        return Math.round(result * 1e2) / 1e2;
                    };
                    return GeoService;
                }());
                Services.GeoService = GeoService;
                angular.module('app.core')
                    .service('geoService', GeoService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var NavigationService = (function () {
                    NavigationService.$inject = ["$state", "$ionicHistory"];
                    function NavigationService($state, $ionicHistory) {
                        this.$state = $state;
                        this.$ionicHistory = $ionicHistory;
                    }
                    NavigationService.prototype.goHome = function () {
                        this.$ionicHistory.nextViewOptions({ disableBack: true, historyRoot: true });
                        this.$state.go('app.home');
                    };
                    NavigationService.prototype.goBack = function () {
                        if (ionic.Platform['is']('browser')) {
                            window.history.back();
                        }
                        else {
                            this.$ionicHistory.goBack();
                        }
                    };
                    return NavigationService;
                }());
                Services.NavigationService = NavigationService;
                angular.module('app.core')
                    .service('navigationService', NavigationService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var SummaryInfoAPI = (function () {
                    SummaryInfoAPI.$inject = ["$q", "$http", "configService"];
                    function SummaryInfoAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    SummaryInfoAPI.prototype.get = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "summaries",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    return SummaryInfoAPI;
                }());
                Services.SummaryInfoAPI = SummaryInfoAPI;
                angular.module('app.core')
                    .service('summaryInfoAPI', SummaryInfoAPI);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningDetailController = (function () {
                    DiningDetailController.$inject = ["$stateParams", "diningService"];
                    function DiningDetailController($stateParams, diningService) {
                        var _this = this;
                        this.$stateParams = $stateParams;
                        this.diningService = diningService;
                        this.recommendations = [];
                        this.loading = false;
                        this.loading = true;
                        var id = $stateParams['id'];
                        if (!$stateParams['restaurant']) {
                            this.diningService.getSingle(id).then(function (restaurant) {
                                _this.restaurant = restaurant;
                                _this.getExtraInformation();
                            });
                        }
                        else {
                            this.restaurant = $stateParams['restaurant'];
                            this.getExtraInformation();
                        }
                    }
                    DiningDetailController.prototype.getExtraInformation = function () {
                        var _this = this;
                        this.diningService.getRecommendations(this.restaurant.restaurantId.toString())
                            .then(function (restaurants) {
                            _this.recommendations = restaurants;
                            _this.loading = false;
                        });
                    };
                    DiningDetailController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningDetailController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningDetailController;
                }());
                angular.module('app.dining')
                    .controller('DiningDetailController', DiningDetailController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningController = (function () {
                    DiningController.$inject = ["diningService"];
                    function DiningController(diningService) {
                        this.diningService = diningService;
                        this.getRestaurants();
                        this.fillFilters();
                        this.orderBy = '';
                    }
                    DiningController.prototype.getRestaurants = function () {
                        var _this = this;
                        this.loading = true;
                        this.diningService.getNear()
                            .then(function (restaurants) {
                            _this.restaurants = restaurants;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    DiningController.prototype.fillFilters = function () {
                        this.filters = this.diningService.getFilters();
                    };
                    DiningController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningController;
                }());
                angular.module('app.dining')
                    .controller('DiningController', DiningController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningAPI = (function () {
                    DiningAPI.$inject = ["$q", "$http", "configService"];
                    function DiningAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    DiningAPI.prototype.getAll = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getNear = function (latitude, longitude) {
                        var request = {
                            url: ((this.configService.API.URL + this.configService.API.Path) + "restaurants/nearby") +
                                ("?latitude=" + latitude) +
                                ("&longitude=" + longitude),
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getRecommendations = function (searchtext) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/recommendations/" + searchtext,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getSingle = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/" + id,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getImage = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "restaurants/photo/" + id;
                    };
                    return DiningAPI;
                }());
                Services.DiningAPI = DiningAPI;
                angular.module('app.dining')
                    .service('diningAPI', DiningAPI);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningService = (function () {
                    DiningService.$inject = ["$q", "diningAPI", "geoService"];
                    function DiningService($q, diningAPI, geoService) {
                        this.$q = $q;
                        this.diningAPI = diningAPI;
                        this.geoService = geoService;
                        this.latitude = 0;
                        this.longitude = 0;
                    }
                    DiningService.prototype.getDistance = function (latitude, longitude) {
                        return this.geoService.getDistanceBetween({ latitude: latitude, longitude: longitude }, { latitude: this.latitude, longitude: this.longitude });
                    };
                    DiningService.prototype.calculateDistances = function (restaurants) {
                        for (var i = 0, l = restaurants.length; i < l; i++) {
                            restaurants[i].distance = this.getDistance(restaurants[i].latitude, restaurants[i].longitude);
                        }
                        return restaurants;
                    };
                    DiningService.prototype.getAll = function () {
                        return this.diningAPI.getAll();
                    };
                    DiningService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve) {
                            return _this.geoService.getPosition()
                                .then(function (result) {
                                _this.latitude = result.latitude;
                                _this.longitude = result.longitude;
                                return _this.diningAPI.getNear(_this.latitude, _this.longitude).then(function (restaurants) {
                                    return resolve(_this.calculateDistances(restaurants));
                                });
                            });
                        });
                    };
                    DiningService.prototype.getRecommendations = function (_searchtext) {
                        var _this = this;
                        var searchtextSplitted = _searchtext.split(' ');
                        var searchtext = searchtextSplitted[searchtextSplitted.length - 1];
                        return this.$q(function (resolve) {
                            return _this.diningAPI.getRecommendations(searchtext).then(function (ids) {
                                var restaurants = [];
                                var promises = [];
                                for (var i = 0, l = ids.length; i < l; i++) {
                                    promises.push((function () {
                                        return _this.getSingle(ids[i]).then(function (restaurant) {
                                            restaurants.push(restaurant);
                                        });
                                    })());
                                }
                                _this.$q.all(promises).then(function () {
                                    resolve(restaurants);
                                });
                            });
                        });
                    };
                    DiningService.prototype.getSingle = function (id) {
                        return this.diningAPI.getSingle(id);
                    };
                    DiningService.prototype.getFilters = function () {
                        return [
                            { id: '-rating', label: 'Rating' },
                            { id: 'levelOfNoise', label: 'Level Noise' },
                            { id: 'priceLevel', label: 'Price' },
                            { id: 'distance', label: 'Miles Away' },
                            { id: '-familyFriendly', label: 'Family Friendly' }
                        ];
                    };
                    DiningService.prototype.getImage = function (id) {
                        return this.diningAPI.getImage(id);
                    };
                    return DiningService;
                }());
                Services.DiningService = DiningService;
                angular.module('app.dining')
                    .service('diningService', DiningService);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            var HomeController = (function () {
                HomeController.$inject = ["$scope", "authService", "authImageService"];
                function HomeController($scope, authService, authImageService) {
                    this.$scope = $scope;
                    this.authService = authService;
                    this.authImageService = authImageService;
                }
                HomeController.prototype.getImage = function (id) {
                    return this.authImageService.get(id);
                };
                return HomeController;
            }());
            angular.module('app.home')
                .controller('HomeController', HomeController);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            var Directives;
            (function (Directives) {
                function HomeMenuDirective() {
                    return {
                        restrict: 'E',
                        templateUrl: 'home/templates/home-menu.template.html'
                    };
                }
                angular.module('app.home')
                    .directive('skiHomeMenu', HomeMenuDirective);
            })(Directives = Home.Directives || (Home.Directives = {}));
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusDetailController = (function () {
                    LiftStatusDetailController.$inject = ["liftService", "$stateParams", "geoService", "$scope"];
                    function LiftStatusDetailController(liftService, $stateParams, geoService, $scope) {
                        var _this = this;
                        this.liftService = liftService;
                        this.$stateParams = $stateParams;
                        this.geoService = geoService;
                        this.$scope = $scope;
                        this.loading = false;
                        this.userGeolocation = null;
                        this.distance = null;
                        this.getLift();
                        $scope.$watch(function () {
                            _this.getDistance();
                        });
                    }
                    LiftStatusDetailController.prototype.getLift = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.get(this.$stateParams.liftId)
                            .then(function (lift) {
                            _this.lift = lift;
                        })
                            .catch(function () {
                            // Handle error
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusDetailController.prototype.getDistance = function () {
                        var _this = this;
                        if (this.userGeolocation) {
                            this.calcDistance();
                        }
                        else {
                            this.geoService.getPosition()
                                .then(function (data) {
                                _this.userGeolocation = data;
                                _this.calcDistance();
                            });
                        }
                    };
                    LiftStatusDetailController.prototype.calcDistance = function () {
                        if (this.lift) {
                            this.distance = this.geoService.getDistanceBetween(this.userGeolocation, { latitude: this.lift.latitude, longitude: this.lift.longitude });
                        }
                    };
                    return LiftStatusDetailController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusDetailController', LiftStatusDetailController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusListController = (function () {
                    LiftStatusListController.$inject = ["liftService"];
                    function LiftStatusListController(liftService) {
                        this.liftService = liftService;
                        this.getLifts();
                    }
                    LiftStatusListController.prototype.getLifts = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.getNear()
                            .then(function (data) {
                            _this.digestLifts(data);
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusListController.prototype.digestLifts = function (lifts) {
                        var _this = this;
                        this.openLifts = [];
                        this.closedLifts = [];
                        lifts.forEach(function (lift) {
                            if (lift.status === Lift.Models.LiftStatus.Open) {
                                _this.openLifts.push(lift);
                            }
                            else if (lift.status === Lift.Models.LiftStatus.Closed) {
                                _this.closedLifts.push(lift);
                            }
                        });
                    };
                    return LiftStatusListController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusListController', LiftStatusListController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftAPI = (function () {
                    LiftAPI.$inject = ["$q", "$http", "configService"];
                    function LiftAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    LiftAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "lifts",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    LiftAPI.prototype.getNear = function (latitude, longitude) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: ((_this.configService.API.URL + _this.configService.API.Path) + "lifts/nearby") +
                                    ("?latitude=" + latitude) +
                                    ("&longitude=" + longitude),
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(resolve, reject);
                        });
                    };
                    LiftAPI.prototype.get = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "lifts/" + id,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return LiftAPI;
                }());
                Services.LiftAPI = LiftAPI;
                angular.module('app.lift')
                    .service('liftAPI', LiftAPI);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftService = (function () {
                    LiftService.$inject = ["$q", "liftAPI", "geoService"];
                    function LiftService($q, liftAPI, geoService) {
                        this.$q = $q;
                        this.liftAPI = liftAPI;
                        this.geoService = geoService;
                    }
                    LiftService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            });
                        });
                    };
                    LiftService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.geoService.getPosition()
                                .then(function (result) {
                                return _this.liftAPI.getNear(result.latitude, result.longitude);
                            })
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            })
                                .catch(reject);
                        });
                    };
                    LiftService.prototype.get = function (id) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.get(id)
                                .then(function (result) {
                                resolve(new Lift.Models.Lift().serialize(result.data));
                            })
                                .catch(reject);
                        });
                    };
                    return LiftService;
                }());
                Services.LiftService = LiftService;
                angular.module('app.lift')
                    .service('liftService', LiftService);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var NewReservationController = (function () {
                    NewReservationController.$inject = ["$scope", "rentalService", "rentalActivities", "rentalCategories", "rentalGoals", "shoeSizes", "skiSizes", "poleSizes", "$stateParams", "pickupHours", "navigationService"];
                    function NewReservationController($scope, rentalService, rentalActivities, rentalCategories, rentalGoals, shoeSizes, skiSizes, poleSizes, $stateParams, pickupHours, navigationService) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.rentalActivities = rentalActivities;
                        this.rentalCategories = rentalCategories;
                        this.rentalGoals = rentalGoals;
                        this.shoeSizes = shoeSizes;
                        this.skiSizes = skiSizes;
                        this.poleSizes = poleSizes;
                        this.$stateParams = $stateParams;
                        this.pickupHours = pickupHours;
                        this.navigationService = navigationService;
                        this.loading = false;
                        this.highDemandAlert = false;
                        // Initialize rental
                        this.rental = new Rental.Models.Rental();
                        this.pickupHours.generateAll();
                        // If there's a rentalId, we're editing, not creating
                        if ($stateParams.rentalId) {
                            this.getRental();
                        }
                        else {
                            this.resetRental();
                        }
                        // Set the todayDated, used as 'min' value for startDate
                        $scope.todayDate = new Date();
                        $scope.todayDate.setHours(0);
                        $scope.todayDate.setMinutes(0);
                        $scope.todayDate.setSeconds(0);
                        /*
                            startDate is edited in two separated inputs,
                            so, it needs to be in reparated models for
                            each ng-model
                        */
                        $scope.startDate = {
                            day: null,
                            hour: null
                        };
                        /*
                            These values (options in selectors) are mapped to the original
                            rental model using $scope.$watchCollection
                        */
                        $scope.rentalTemp = {
                            activity: null,
                            category: null,
                            poleSize: null,
                            skiSize: null
                        };
                        // Update startDate
                        $scope.$watchCollection('startDate', function () {
                            if (!$scope.startDate.day) {
                                return;
                            }
                            _this.rental.startDate = angular.copy($scope.startDate.day);
                            if ($scope.startDate.hour) {
                                _this.rental.startDate.setHours($scope.startDate.hour.hours);
                                _this.rental.startDate.setMinutes($scope.startDate.hour.minutes);
                            }
                            _this.checkHighDemand();
                        });
                        // Update activity, category, poleSize and skiSize
                        $scope.$watchCollection('rentalTemp', function () {
                            _this.rental.activity = $scope.rentalTemp.activity ? $scope.rentalTemp.activity.id : null;
                            _this.rental.category = $scope.rentalTemp.category ? $scope.rentalTemp.category.id : null;
                            _this.rental.poleSize = $scope.rentalTemp.poleSize ? $scope.rentalTemp.poleSize.id : null;
                            _this.rental.skiSize = $scope.rentalTemp.skiSize ? $scope.rentalTemp.skiSize.id : null;
                        });
                    }
                    NewReservationController.prototype.getRental = function () {
                        var _this = this;
                        this.loading = true;
                        this.rentalService.get(this.$stateParams.rentalId)
                            .then(function (rental) {
                            _this.rental = rental;
                            _this.updateTempData();
                            _this.loading = false;
                        });
                    };
                    // This will update all the temporal data used in the custom selects
                    // based on the actual rental object.
                    //
                    // This method is used at start when we're editing a rental
                    NewReservationController.prototype.updateTempData = function () {
                        var hours = this.rental.startDate.getHours();
                        var minutes = this.rental.startDate.getMinutes();
                        this.$scope.startDate = {
                            day: this.rental.startDate,
                            hour: this.pickupHours.getById((hours * 60) + minutes)
                        };
                        this.$scope.rentalTemp = {
                            activity: this.rentalActivities.getById(this.rental.activity),
                            category: this.rentalCategories.getById(this.rental.category),
                            poleSize: this.poleSizes.getById(this.rental.poleSize),
                            skiSize: this.skiSizes.getById(this.rental.skiSize)
                        };
                    };
                    // This will put the rental and all the temporal values for custom
                    // selects to null
                    //
                    // This method is used at start when we're creating a rental
                    NewReservationController.prototype.resetRental = function () {
                        this.rental = new Rental.Models.Rental();
                        for (var i in this.$scope.startDate) {
                            if (this.$scope.startDate.hasOwnProperty(i)) {
                                this.$scope.startDate[i] = null;
                            }
                        }
                        for (var x in this.$scope.rentalTemp) {
                            if (this.$scope.rentalTemp.hasOwnProperty(x)) {
                                this.$scope.rentalTemp[x] = null;
                            }
                        }
                    };
                    NewReservationController.prototype.emitSave = function () {
                        this.$scope.$emit('rental_saved');
                    };
                    NewReservationController.prototype.submitReservation = function () {
                        var _this = this;
                        if (this.rentalForm.$valid) {
                            this.loading = true;
                            var actionPromise = null;
                            if (this.$stateParams.rentalId) {
                                actionPromise = this.saveReservation();
                            }
                            else {
                                actionPromise = this.addReservation();
                            }
                            actionPromise
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    NewReservationController.prototype.addReservation = function () {
                        var _this = this;
                        return this.rentalService.add(this.rental)
                            .then(function () {
                            _this.resetRental();
                            _this.rentalForm.$setPristine();
                            _this.rentalForm.$setUntouched();
                            _this.emitSave();
                        });
                    };
                    NewReservationController.prototype.saveReservation = function () {
                        var _this = this;
                        return this.rentalService.save(this.rental)
                            .then(function () {
                            _this.navigationService.goBack();
                        });
                    };
                    NewReservationController.prototype.checkHighDemand = function () {
                        var _this = this;
                        this.rentalService.checkHighDemand(this.rental.startDate)
                            .then(function (result) {
                            _this.highDemandAlert = result;
                        })
                            .catch(function () {
                            // Handle error
                        });
                    };
                    NewReservationController.prototype.getCalculatedCost = function () {
                        this.rental.totalCost = 0;
                        if (this.rental.startDate && this.rental.endDate) {
                            this.rental.totalCost = 20;
                            var days = Math.floor((this.rental.endDate.getTime() - this.rental.startDate.getTime()) / 1000 / 60 / 60 / 24);
                            this.rental.totalCost = this.rental.totalCost + (days * 5);
                        }
                        return this.rental.totalCost;
                    };
                    return NewReservationController;
                }());
                angular.module('app.rental')
                    .controller('NewReservationController', NewReservationController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var RentalsController = (function () {
                    RentalsController.$inject = ["$ionicTabsDelegate", "$scope", "$stateParams"];
                    function RentalsController($ionicTabsDelegate, $scope, $stateParams) {
                        this.$ionicTabsDelegate = $ionicTabsDelegate;
                        this.$scope = $scope;
                        this.$stateParams = $stateParams;
                        $scope.$on('rental_saved', function () {
                            $ionicTabsDelegate.$getByHandle('section-tabs').select(0);
                            $scope.$broadcast('update_reservation_list');
                        });
                    }
                    return RentalsController;
                }());
                Controllers.RentalsController = RentalsController;
                angular.module('app.rental')
                    .controller('RentalsController', RentalsController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var ReservationListController = (function () {
                    ReservationListController.$inject = ["$scope", "rentalService", "$state", "$timeout"];
                    function ReservationListController($scope, rentalService, $state, $timeout) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.$state = $state;
                        this.$timeout = $timeout;
                        this.showMessage = false;
                        this.getRentals();
                        $scope.$on('update_reservation_list', function () {
                            _this.getRentals()
                                .finally(function () {
                                _this.showMessage = true;
                            });
                        });
                    }
                    ReservationListController.prototype.getRentals = function () {
                        var _this = this;
                        this.loading = true;
                        return this.rentalService.getAll()
                            .then(function (data) {
                            _this.rentals = data;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    ReservationListController.prototype.navigateToRental = function (rental) {
                        var _this = this;
                        this.navigatingRental = rental;
                        this.$timeout(function () {
                            _this.$state.go('app.rental-detail', { rentalId: rental.rentalId });
                        }, 100);
                    };
                    return ReservationListController;
                }());
                angular.module('app.rental')
                    .controller('ReservationListController', ReservationListController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalActivityFilter() {
                    return function (input) {
                        return Rental.Models.RentalActivity[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalActivity', RentalActivityFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalCategoryFilter() {
                    return function (input) {
                        return Rental.Models.RentalCategory[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalCategory', RentalCategoryFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var PickupHours = (function () {
                    function PickupHours() {
                        this.all = [];
                    }
                    PickupHours.prototype.getById = function (i) {
                        var _hours = Math.floor(i / 60);
                        var _minutes = i - (_hours * 60);
                        var hours = _hours;
                        var minutes = _minutes;
                        var mer = 'am';
                        if (hours > 12) {
                            hours = hours - 12;
                            mer = 'pm';
                        }
                        var hours_str = hours.toString();
                        var minutes_str = minutes.toString();
                        if (hours_str.length === 1) {
                            hours_str = '0' + hours_str;
                        }
                        if (minutes_str.length === 1) {
                            minutes_str = '0' + minutes_str;
                        }
                        return {
                            id: i,
                            label: hours_str + ":" + minutes_str + " " + mer,
                            hours: _hours,
                            minutes: _minutes
                        };
                    };
                    PickupHours.prototype.generateAll = function () {
                        var result = [];
                        var minMinutes = 360;
                        var maxMinutes = 1200;
                        var steps = 15;
                        for (var i = minMinutes; i <= maxMinutes; i = i + steps) {
                            result.push(this.getById(i));
                        }
                        this.all = result;
                    };
                    return PickupHours;
                }());
                Services.PickupHours = PickupHours;
                angular.module('app.rental')
                    .service('pickupHours', PickupHours);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function PoleSizes() {
                    var result = [];
                    for (var i = 32; i <= 57; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.PoleSizes = PoleSizes;
                angular.module('app.rental')
                    .service('poleSizes', PoleSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalActivities() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalActivity[id] }); },
                        all: Object.keys(Rental.Models.RentalActivity)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i); })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalActivity[i] }); })
                    };
                }
                Services.RentalActivities = RentalActivities;
                angular.module('app.rental')
                    .service('rentalActivities', RentalActivities);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalCategories() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalCategory[id] }); },
                        all: Object.keys(Rental.Models.RentalCategory)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i) && i !== 0; })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalCategory[i] }); })
                    };
                }
                Services.RentalCategories = RentalCategories;
                angular.module('app.rental')
                    .service('rentalCategories', RentalCategories);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalGoals() {
                    return Object.keys(Rental.Models.RentalGoal)
                        .map(function (i) { return parseInt(i, 10); })
                        .filter(function (i) { return !isNaN(i); })
                        .map(function (i) { return ({ id: i, label: Rental.Models.RentalGoal[i] }); });
                }
                Services.RentalGoals = RentalGoals;
                angular.module('app.rental')
                    .service('rentalGoals', RentalGoals);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalAPI = (function () {
                    RentalAPI.$inject = ["$q", "$http", "configService"];
                    function RentalAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    RentalAPI.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals/" + rentalId,
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.add = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'POST',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.save = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'PUT',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.checkHighDemand = function (date) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals/check_high_demand?date=" + date,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return RentalAPI;
                }());
                Services.RentalAPI = RentalAPI;
                angular.module('app.rental')
                    .service('rentalAPI', RentalAPI);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalService = (function () {
                    RentalService.$inject = ["$q", "rentalAPI", "geoService"];
                    function RentalService($q, rentalAPI, geoService) {
                        this.$q = $q;
                        this.rentalAPI = rentalAPI;
                        this.geoService = geoService;
                    }
                    RentalService.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.get(rentalId)
                                .then(function (response) {
                                resolve(new Rental.Models.Rental().serialize(response.data));
                            });
                        });
                    };
                    RentalService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Rental.Models.Rental().serialize(item);
                                }));
                            });
                        });
                    };
                    RentalService.prototype.add = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.add(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.save = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.save(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.checkHighDemand = function (date) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.checkHighDemand(date.toISOString())
                                .then(function (response) {
                                resolve(response.data);
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    return RentalService;
                }());
                Services.RentalService = RentalService;
                angular.module('app.rental')
                    .service('rentalService', RentalService);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function ShoeSizes() {
                    return [1, 2, 3, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5,
                        11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15, 15.5, 16, 16.5];
                }
                Services.ShoeSizes = ShoeSizes;
                angular.module('app.rental')
                    .service('shoeSizes', ShoeSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function SkiSizes() {
                    var result = [];
                    for (var i = 115; i <= 200; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.SkiSizes = SkiSizes;
                angular.module('app.rental')
                    .service('skiSizes', SkiSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3d3d3Jvb3QvanMvYXBwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0EsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCO0lBQ0EsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osUUFBUSxPQUFPLE9BQU87WUFDbEI7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7O09BRUwsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSzs7MERBQ1o7UUFDQSxTQUFTLElBQUksZ0JBQWdCLE1BQU07WUFDL0IsZUFBZSxNQUFNLFlBQVksS0FBSyxNQUFNOztRQUVoRCxTQUFTLFlBQVksTUFBTTtZQUN2QixLQUFLLEtBQUs7O1FBRWQsUUFBUSxPQUFPO2FBQ1YsSUFBSTtPQUNWLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixRQUFRLE9BQU8sWUFBWTtXQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsUUFBUSxPQUFPLGNBQWM7V0FDOUIsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixRQUFRLE9BQU8sWUFBWTtXQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsUUFBUSxPQUFPLGNBQWM7V0FDOUIsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07OzJFQUNiO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCO2dCQUMxQztxQkFDSyxNQUFNLGFBQWE7b0JBQ3BCLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOzs7K0VBQ2I7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sT0FBTztvQkFDZCxLQUFLO29CQUNMLFVBQVU7b0JBQ1YsWUFBWTtvQkFDWixjQUFjO29CQUNkLGFBQWE7OztZQUdyQixTQUFTLG1CQUFtQixzQkFBc0I7Z0JBQzlDLHFCQUFxQixVQUFVLFlBQVk7O1lBRS9DLFFBQVEsT0FBTztpQkFDVixPQUFPO2lCQUNQLE9BQU87V0FDYixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTs7MkVBQ2Y7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sbUJBQW1CO29CQUMxQixLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztxQkFJcEIsTUFBTSxxQkFBcUI7b0JBQzVCLEtBQUs7b0JBQ0wsUUFBUTt3QkFDSixZQUFZOztvQkFFaEIsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOztpR0FDYjtZQUNBLFNBQVMscUJBQXFCLGdCQUFnQixvQkFBb0I7Z0JBQzlEO3FCQUNLLE1BQU0sWUFBWTtvQkFDbkIsS0FBSztvQkFDTCxNQUFNO3dCQUNGLFVBQVU7O29CQUVkLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztnQkFJekIsbUJBQW1CLFVBQVU7O1lBRWpDLFFBQVEsT0FBTztpQkFDVixPQUFPO1dBQ2IsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07O2lHQUNiO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCLG9CQUFvQjtnQkFDOUQ7cUJBQ0ssTUFBTSx3QkFBd0I7b0JBQy9CLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7O3FCQUlwQixNQUFNLDBCQUEwQjtvQkFDakMsS0FBSztvQkFDTCxPQUFPO3dCQUNILFdBQVc7NEJBQ1AsWUFBWTs0QkFDWixjQUFjOzRCQUNkLGFBQWE7Ozs7O1lBSzdCLFFBQVEsT0FBTztpQkFDVixPQUFPO1dBQ2IsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7O2lHQUNmO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCLG9CQUFvQjtnQkFDOUQ7cUJBQ0ssTUFBTSxlQUFlO29CQUN0QixPQUFPO29CQUNQLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLGFBQWE7NEJBQ2IsWUFBWTs0QkFDWixjQUFjOzs7O3FCQUlyQixNQUFNLHFCQUFxQjtvQkFDNUIsT0FBTztvQkFDUCxLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxhQUFhOzRCQUNiLFlBQVk7NEJBQ1osY0FBYzs7Ozs7WUFLOUIsUUFBUSxPQUFPO2lCQUNWLE9BQU87V0FDYixTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxlQUFlLFlBQVk7b0JBQzNCLFNBQVMsY0FBYzs7b0JBRXZCLE9BQU87O2dCQUVYLE9BQU8sY0FBYztlQUN0QixTQUFTLEtBQUssV0FBVyxLQUFLLFNBQVM7V0FDM0MsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsU0FBUztvQkFDaEIsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLFdBQVcsS0FBSztvQkFDaEMsUUFBUSxRQUFRLFlBQVksS0FBSztvQkFDakMsUUFBUSxRQUFRLFdBQVcsS0FBSzttQkFDakMsT0FBTyxZQUFZLE9BQU8sVUFBVTtnQkFDdkMsSUFBSSxVQUFVLE9BQU87ZUFDdEIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLGNBQWM7b0JBQ3JCLGFBQWEsYUFBYSxhQUFhLEtBQUs7b0JBQzVDLGFBQWEsYUFBYSxTQUFTLEtBQUs7b0JBQ3hDLGFBQWEsYUFBYSxZQUFZLEtBQUs7b0JBQzNDLGFBQWEsYUFBYSxVQUFVLEtBQUs7bUJBQzFDLE9BQU8saUJBQWlCLE9BQU8sZUFBZTtnQkFDakQsSUFBSSxlQUFlLE9BQU87ZUFDM0IsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxjQUFjLFlBQVk7b0JBQzFCLFNBQVMsYUFBYTs7b0JBRXRCLE9BQU87O2dCQUVYLE9BQU8sYUFBYTtlQUNyQixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxJQUFJLFFBQVEsWUFBWTtvQkFDcEIsU0FBUyxPQUFPOztvQkFFaEIsS0FBSyxVQUFVLFlBQVksVUFBVSxNQUFNO3dCQUN2QyxLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxPQUFPLEtBQUs7d0JBQ2pCLEtBQUssU0FBUyxLQUFLO3dCQUNuQixLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssWUFBWSxLQUFLO3dCQUN0QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxjQUFjLEtBQUs7d0JBQ3hCLEtBQUssZUFBZSxLQUFLO3dCQUN6QixPQUFPOztvQkFFWCxLQUFLLFVBQVUsY0FBYyxZQUFZO3dCQUNyQyxPQUFPOzRCQUNILFFBQVEsS0FBSzs0QkFDYixNQUFNLEtBQUs7NEJBQ1gsUUFBUSxLQUFLOzRCQUNiLFFBQVEsS0FBSzs0QkFDYixVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixVQUFVLEtBQUs7NEJBQ2YsYUFBYSxLQUFLOzRCQUNsQixjQUFjLEtBQUs7OztvQkFHM0IsT0FBTzs7Z0JBRVgsT0FBTyxPQUFPO2VBQ2YsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxjQUFjLEtBQUs7b0JBQ3pDLFdBQVcsV0FBVyxrQkFBa0IsS0FBSztvQkFDN0MsV0FBVyxXQUFXLGNBQWMsS0FBSzttQkFDMUMsT0FBTyxlQUFlLE9BQU8sYUFBYTtnQkFDN0MsSUFBSSxhQUFhLE9BQU87ZUFDekIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxVQUFVLEtBQUs7b0JBQ3JDLFdBQVcsV0FBVyxZQUFZLEtBQUs7bUJBQ3hDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsS0FBSyxXQUFXLEtBQUssU0FBUztXQUMzQyxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFVBQVU7WUFDakIsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLElBQUksVUFBVSxZQUFZO29CQUN0QixTQUFTLFNBQVM7O29CQUVsQixPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQU07d0JBQ3pDLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLO3dCQUMvQixLQUFLLFVBQVUsSUFBSSxLQUFLLEtBQUs7d0JBQzdCLEtBQUssYUFBYSxLQUFLO3dCQUN2QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssT0FBTyxLQUFLO3dCQUNqQixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxVQUFVLEtBQUs7d0JBQ3BCLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsT0FBTzs7b0JBRVgsT0FBTyxVQUFVLGNBQWMsWUFBWTt3QkFDdkMsT0FBTzs0QkFDSCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixXQUFXLEtBQUssVUFBVTs0QkFDMUIsU0FBUyxLQUFLLFFBQVE7NEJBQ3RCLFlBQVksS0FBSzs0QkFDakIsVUFBVSxLQUFLOzRCQUNmLFVBQVUsS0FBSzs0QkFDZixNQUFNLEtBQUs7NEJBQ1gsVUFBVSxLQUFLOzRCQUNmLFNBQVMsS0FBSzs0QkFDZCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzs7b0JBR3hCLE9BQU87O2dCQUVYLE9BQU8sU0FBUztlQUNqQixTQUFTLFNBQVMsV0FBVyxTQUFTLFNBQVM7V0FDbkQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsU0FBUyxLQUFLO29CQUM1QyxlQUFlLGVBQWUsZUFBZSxLQUFLO21CQUNuRCxPQUFPLG1CQUFtQixPQUFPLGlCQUFpQjtnQkFDckQsSUFBSSxpQkFBaUIsT0FBTztlQUM3QixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsYUFBYSxLQUFLO29CQUNoRCxlQUFlLGVBQWUsY0FBYyxLQUFLO29CQUNqRCxlQUFlLGVBQWUsa0JBQWtCLEtBQUs7b0JBQ3JELGVBQWUsZUFBZSxjQUFjLEtBQUs7bUJBQ2xELE9BQU8sbUJBQW1CLE9BQU8saUJBQWlCO2dCQUNyRCxJQUFJLGlCQUFpQixPQUFPO2VBQzdCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLENBQUMsVUFBVSxZQUFZO29CQUNuQixXQUFXLFdBQVcsYUFBYSxLQUFLO29CQUN4QyxXQUFXLFdBQVcsVUFBVSxLQUFLO29CQUNyQyxXQUFXLFdBQVcsaUJBQWlCLEtBQUs7b0JBQzVDLFdBQVcsV0FBVyxXQUFXLEtBQUs7bUJBQ3ZDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O2dHQUNBLElBQUksbUJBQW1CLFlBQVk7b0JBQy9CLFNBQVMsZ0JBQWdCLGFBQWEsZUFBZTt3QkFDakQsS0FBSyxjQUFjO3dCQUNuQixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxZQUFZO3dCQUNqQixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxVQUFVOztvQkFFbkIsZ0JBQWdCLFVBQVUsUUFBUSxZQUFZO3dCQUMxQyxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssZ0JBQWdCO3dCQUNyQixJQUFJLEtBQUssVUFBVSxRQUFROzRCQUN2QixLQUFLLFlBQVksTUFBTSxLQUFLLFVBQVUsVUFBVSxLQUFLLFVBQVU7aUNBQzFELEtBQUssWUFBWTtnQ0FDbEIsTUFBTSxjQUFjOztpQ0FFbkIsTUFBTSxZQUFZO2dDQUNuQixNQUFNLGdCQUFnQjs7aUNBRXJCLFFBQVEsWUFBWTtnQ0FDckIsTUFBTSxVQUFVOzs7O29CQUk1QixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyxtQkFBbUI7ZUFDcEMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzt5SEFDQSxJQUFJLG9CQUFvQixZQUFZO29CQUNoQyxTQUFTLGlCQUFpQixJQUFJLFNBQVMsb0JBQW9CLGVBQWU7d0JBQ3RFLEtBQUssS0FBSzt3QkFDVixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxxQkFBcUI7d0JBQzFCLEtBQUssZ0JBQWdCOztvQkFFekIsaUJBQWlCLFVBQVUsTUFBTSxVQUFVLElBQUk7d0JBQzNDLE9BQU8sQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsaUJBQWlCOztvQkFFekYsT0FBTzs7Z0JBRVgsU0FBUyxtQkFBbUI7Z0JBQzVCLFFBQVEsT0FBTztxQkFDVixRQUFRLG9CQUFvQjtlQUNsQyxXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOztnSEFDQSxJQUFJLFdBQVcsWUFBWTtvQkFDdkIsU0FBUyxRQUFRLE9BQU8sZUFBZSw0QkFBNEI7d0JBQy9ELEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyw2QkFBNkI7O29CQUV0QyxRQUFRLFVBQVUsUUFBUSxVQUFVLFVBQVUsVUFBVTt3QkFDcEQsSUFBSSxVQUFVOzRCQUNWLEtBQUssS0FBSyxjQUFjLElBQUksTUFBTTs0QkFDbEMsUUFBUTs0QkFDUixNQUFNLEtBQUssMkJBQTJCO2dDQUNsQyxZQUFZLEtBQUssY0FBYyxlQUFlO2dDQUM5QyxXQUFXLEtBQUssY0FBYyxlQUFlO2dDQUM3QyxlQUFlLEtBQUssY0FBYyxlQUFlO2dDQUNqRCxPQUFPLEtBQUssY0FBYyxlQUFlO2dDQUN6QyxVQUFVO2dDQUNWLFVBQVU7OzRCQUVkLFNBQVM7Z0NBQ0wsZ0JBQWdCOzs7d0JBR3hCLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsT0FBTzs7Z0JBRVgsU0FBUyxVQUFVO2dCQUNuQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxXQUFXO2VBQ3pCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7O21HQUNBLElBQUksZUFBZSxZQUFZO29CQUMzQixTQUFTLFlBQVksSUFBSSxTQUFTLG9CQUFvQjt3QkFDbEQsS0FBSyxLQUFLO3dCQUNWLEtBQUssVUFBVTt3QkFDZixLQUFLLHFCQUFxQjs7b0JBRTlCLFlBQVksVUFBVSxRQUFRLFVBQVUsVUFBVSxVQUFVO3dCQUN4RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sUUFBUSxNQUFNLFVBQVU7aUNBQ3pCLEtBQUssVUFBVSxVQUFVO2dDQUMxQixNQUFNLG1CQUFtQixjQUFjLFNBQVMsS0FBSztnQ0FDckQsT0FBTyxNQUFNLG1CQUFtQjs7aUNBRS9CLEtBQUssWUFBWTtnQ0FDbEI7O2lDQUVDLE1BQU0sVUFBVSxPQUFPO2dDQUN4QixPQUFPLE1BQU07Ozs7b0JBSXpCLE9BQU87O2dCQUVYLFNBQVMsY0FBYztnQkFDdkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsZUFBZTtlQUM3QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLElBQUksMkJBQTJCOzt5SEFDL0IsSUFBSSxzQkFBc0IsWUFBWTtvQkFDbEMsU0FBUyxtQkFBbUIsSUFBSSxZQUFZLE9BQU8sZUFBZSxNQUFNO3dCQUNwRSxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxhQUFhO3dCQUNsQixLQUFLLFFBQVE7d0JBQ2IsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssT0FBTzt3QkFDWixLQUFLLGNBQWM7d0JBQ25CLEtBQUssY0FBYzt3QkFDbkIsS0FBSzt3QkFDTCxJQUFJLEtBQUssYUFBYTs0QkFDbEIsS0FBSzs7O29CQUdiLG1CQUFtQixVQUFVLE9BQU8sWUFBWTt3QkFDNUMsS0FBSyxLQUFLLEtBQUs7d0JBQ2YsSUFBSSxrQkFBa0IsUUFBUSxLQUFLLEtBQUs7d0JBQ3hDLGdCQUFnQixRQUFRO3dCQUN4QixhQUFhLFFBQVEsMEJBQTBCLEtBQUssVUFBVTs0QkFDMUQsYUFBYSxLQUFLOzRCQUNsQixhQUFhOzt3QkFFakIsS0FBSyxLQUFLLEtBQUs7O29CQUVuQixtQkFBbUIsVUFBVSxPQUFPLFlBQVk7d0JBQzVDLEtBQUssS0FBSyxLQUFLO3dCQUNmLElBQUksZ0JBQWdCLGFBQWEsUUFBUTt3QkFDekMsSUFBSSxlQUFlOzRCQUNmLElBQUksYUFBYSxLQUFLLE1BQU07NEJBQzVCLEtBQUssY0FBYyxXQUFXOzRCQUM5QixLQUFLLGNBQWMsV0FBVzs0QkFDOUIsS0FBSyxXQUFXLGNBQWMsS0FBSzs0QkFDbkMsS0FBSyxLQUFLLEtBQUs7OzZCQUVkOzRCQUNELEtBQUssS0FBSyxLQUFLOzs7b0JBR3ZCLG1CQUFtQixVQUFVLFFBQVEsWUFBWTt3QkFDN0MsS0FBSyxLQUFLLEtBQUs7d0JBQ2YsS0FBSyxjQUFjO3dCQUNuQixLQUFLLGNBQWM7d0JBQ25CLEtBQUssV0FBVyxjQUFjO3dCQUM5QixhQUFhLFFBQVEsMEJBQTBCLEtBQUssVUFBVTt3QkFDOUQsS0FBSyxLQUFLLEtBQUs7O29CQUVuQixtQkFBbUIsVUFBVSxVQUFVLFlBQVk7d0JBQy9DLElBQUksUUFBUTt3QkFDWixLQUFLLEtBQUssS0FBSzt3QkFDZixJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUTs0QkFDbEUsUUFBUTs0QkFDUixTQUFTO2dDQUNMLGlCQUFpQixZQUFZLEtBQUs7Ozt3QkFHMUMsT0FBTyxLQUFLLE1BQU07NkJBQ2IsS0FBSyxVQUFVLFVBQVU7NEJBQzFCLE1BQU0sS0FBSyxLQUFLOzRCQUNoQixNQUFNLGNBQWMsU0FBUzs0QkFDN0IsTUFBTSxXQUFXLGNBQWMsTUFBTTs0QkFDckMsTUFBTTs7NkJBRUwsTUFBTSxZQUFZOzRCQUNuQixNQUFNOzRCQUNOLE1BQU0sS0FBSyxLQUFLOzs7b0JBR3hCLE9BQU87O2dCQUVYLFNBQVMscUJBQXFCO2dCQUM5QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxzQkFBc0I7ZUFDcEMsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7eUhBQ0EsSUFBSSxrQkFBa0IsWUFBWTtvQkFDOUIsU0FBUyxlQUFlLHdCQUF3QixRQUFRLG9CQUFvQjt3QkFDeEUsS0FBSyx5QkFBeUI7d0JBQzlCLEtBQUssU0FBUzt3QkFDZCxLQUFLLHFCQUFxQjs7b0JBRTlCLGVBQWUsVUFBVSxhQUFhLFVBQVUsYUFBYTt3QkFDekQsS0FBSyxPQUFPLEdBQUc7d0JBQ2YsS0FBSyx1QkFBdUIsWUFBWTs7b0JBRTVDLGVBQWUsVUFBVSxTQUFTLFlBQVk7d0JBQzFDLEtBQUssbUJBQW1CO3dCQUN4QixLQUFLLHVCQUF1QixZQUFZOztvQkFFNUMsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsa0JBQWtCO2VBQ25DLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjtnQkFDQSxJQUFJLFVBQVUsS0FBSyxPQUFPOztrR0FDMUIsSUFBSSx5QkFBeUIsWUFBWTtvQkFDckMsU0FBUyxzQkFBc0IsZ0JBQWdCLFFBQVE7d0JBQ25ELElBQUksUUFBUTt3QkFDWixLQUFLLGlCQUFpQjt3QkFDdEIsS0FBSyxTQUFTO3dCQUNkLGVBQWUsTUFBTSxLQUFLLFVBQVUsYUFBYTs0QkFDN0MsTUFBTSxjQUFjOzs7b0JBRzVCLHNCQUFzQixVQUFVLGFBQWEsVUFBVSxJQUFJO3dCQUN2RCxPQUFPLFFBQVE7O29CQUVuQixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyx5QkFBeUI7ZUFDMUMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFlBQVk7Z0JBQ25CLFNBQVMsa0JBQWtCO29CQUN2QixTQUFTLG1CQUFtQixTQUFTLEtBQUs7d0JBQ3RDLFFBQVEsS0FBSyxTQUFTLDZCQUE2QixNQUFNOztvQkFFN0QsU0FBUyxLQUFLLE9BQU8sU0FBUyxNQUFNO3dCQUNoQyxRQUFRLFNBQVM7d0JBQ2pCLEtBQUssU0FBUyxhQUFhLFlBQVk7NEJBQ25DLG1CQUFtQixTQUFTLEtBQUs7OztvQkFHekMsT0FBTzt3QkFDSCxNQUFNOzs7Z0JBR2QsUUFBUSxPQUFPO3FCQUNWLFVBQVUsYUFBYTtlQUM3QixhQUFhLEtBQUssZUFBZSxLQUFLLGFBQWE7V0FDdkQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFlBQVk7O3NGQUNuQixJQUFJLG9CQUFvQixZQUFZO29CQUNoQyxTQUFTLGlCQUFpQixtQkFBbUI7d0JBQ3pDLEtBQUssb0JBQW9COztvQkFFN0IsaUJBQWlCLFVBQVUsU0FBUyxZQUFZO3dCQUM1QyxLQUFLLGtCQUFrQjs7b0JBRTNCLGlCQUFpQixVQUFVLFNBQVMsWUFBWTt3QkFDNUMsS0FBSyxrQkFBa0I7O29CQUUzQixPQUFPOztnQkFFWCxTQUFTLGtCQUFrQjtvQkFDdkIsT0FBTzt3QkFDSCxVQUFVO3dCQUNWLE9BQU87NEJBQ0gsT0FBTzs0QkFDUCxTQUFTOzRCQUNULFlBQVk7NEJBQ1osTUFBTTs7d0JBRVYsYUFBYTt3QkFDYixZQUFZO3dCQUNaLGNBQWM7OztnQkFHdEIsUUFBUSxPQUFPO3FCQUNWLFVBQVUsYUFBYTtlQUM3QixhQUFhLEtBQUssZUFBZSxLQUFLLGFBQWE7V0FDdkQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFlBQVk7Z0JBQ25CLFNBQVMsa0JBQWtCO29CQUN2QixJQUFJLGlCQUFpQjtvQkFDckIsU0FBUyxLQUFLLE9BQU8sU0FBUzt3QkFDMUIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sT0FBTyxLQUFLOzRCQUNsQyxRQUFRLE9BQU8sUUFBUSxRQUFRLG1CQUFtQixpQkFBaUIsTUFBTSxVQUFVOzt3QkFFdkYsS0FBSyxJQUFJLElBQUksTUFBTSxPQUFPLElBQUksTUFBTSxLQUFLLEtBQUs7NEJBQzFDLFFBQVEsT0FBTyxRQUFRLFFBQVEsbUJBQW1CLGlCQUFpQixNQUFNLFdBQVc7OztvQkFHNUYsT0FBTzt3QkFDSCxPQUFPOzRCQUNILE9BQU87NEJBQ1AsS0FBSzs0QkFDTCxTQUFTOzRCQUNULFVBQVU7O3dCQUVkLE1BQU07OztnQkFHZCxRQUFRLE9BQU87cUJBQ1YsVUFBVSxhQUFhO2VBQzdCLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZOzt1RkFDbkIsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsUUFBUSxVQUFVO3dCQUN4QyxLQUFLLFNBQVM7d0JBQ2QsS0FBSyxXQUFXO3dCQUNoQixLQUFLLFVBQVU7NEJBQ1gsYUFBYTs7d0JBRWpCLEtBQUssWUFBWTs0QkFDYixPQUFPOzs7b0JBR2YsaUJBQWlCLFVBQVUsWUFBWSxZQUFZO3dCQUMvQyxJQUFJLEtBQUssT0FBTyxVQUFVOzRCQUN0Qjs7d0JBRUosS0FBSyxTQUFTLEtBQUssS0FBSyxVQUFVLE9BQU8sU0FBUyxLQUFLLFFBQVE7O29CQUVuRSxpQkFBaUIsVUFBVSxhQUFhLFlBQVk7d0JBQ2hELEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxPQUFPLFlBQVksS0FBSyxRQUFROztvQkFFdEUsaUJBQWlCLFVBQVUsa0JBQWtCLFVBQVUsUUFBUTt3QkFDM0QsSUFBSSxLQUFLLE9BQU8sVUFBVTs0QkFDdEI7O3dCQUVKLEtBQUssT0FBTyxRQUFRO3dCQUNwQixLQUFLOztvQkFFVCxpQkFBaUIsVUFBVSxpQkFBaUIsWUFBWTt3QkFDcEQsSUFBSSxLQUFLLE9BQU8sVUFBVTs0QkFDdEI7O3dCQUVKLEtBQUssZ0JBQWdCOztvQkFFekIsT0FBTzs7Z0JBRVgsU0FBUyxrQkFBa0I7b0JBQ3ZCLE9BQU87d0JBQ0gsVUFBVTt3QkFDVixPQUFPOzRCQUNILE9BQU87NEJBQ1AsYUFBYTs0QkFDYixlQUFlOzRCQUNmLFVBQVU7NEJBQ1YsTUFBTTs0QkFDTixVQUFVOzRCQUNWLFNBQVM7O3dCQUViLGFBQWE7d0JBQ2IsWUFBWTt3QkFDWixjQUFjOzs7Z0JBR3RCLFFBQVEsT0FBTztxQkFDVixVQUFVLGFBQWE7ZUFDN0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFlBQVk7Z0JBQ25CLFNBQVMsdUJBQXVCO29CQUM1QixPQUFPO3dCQUNILE9BQU87d0JBQ1AsVUFBVTt3QkFDVixhQUFhO3dCQUNiLFlBQVk7d0JBQ1osY0FBYzs7O2dCQUd0QixRQUFRLE9BQU87cUJBQ1YsVUFBVSxrQkFBa0I7ZUFDbEMsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxTQUFTO2dCQUNoQjtnQkFDQSxTQUFTLFFBQVE7b0JBQ2IsT0FBTyxVQUFVLE9BQU8sTUFBTSxNQUFNO3dCQUNoQyxJQUFJLE1BQU0sU0FBUyxNQUFNO3dCQUN6QixJQUFJLE1BQU0sU0FBUyxNQUFNO3dCQUN6QixLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLOzRCQUM1QixNQUFNLEtBQUs7O3dCQUVmLE9BQU87OztnQkFHZixRQUFRLE9BQU87cUJBQ1YsT0FBTyxZQUFZO2VBQ3pCLFVBQVUsT0FBTyxZQUFZLE9BQU8sVUFBVTtXQUNsRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7O3NFQUNBLElBQUksaUJBQWlCLFlBQVk7b0JBQzdCLFNBQVMsY0FBYyxNQUFNO3dCQUN6QixLQUFLLFVBQVU7NEJBQ1gsaUJBQWlCOzRCQUNqQixhQUFhO2dDQUNULFVBQVU7Z0NBQ1YsV0FBVyxDQUFDOzs7d0JBR3BCLEtBQUssTUFBTTs0QkFDUCxLQUFLOzRCQUNMLE1BQU07O3dCQUVWLEtBQUssaUJBQWlCOzRCQUNsQixXQUFXOzRCQUNYLFVBQVU7NEJBQ1YsY0FBYzs0QkFDZCxPQUFPOzt3QkFFWCxLQUFLLEtBQUs7d0JBQ1YsSUFBSSxNQUFNLFNBQVMsYUFBYTs0QkFDNUIsS0FBSyxLQUFLOzRCQUNWLEtBQUssSUFBSSxNQUFNOzs2QkFFZDs0QkFDRCxLQUFLLEtBQUs7OztvQkFHbEIsT0FBTzs7Z0JBRVgsU0FBUyxnQkFBZ0I7Z0JBQ3pCLFFBQVEsT0FBTztxQkFDVixRQUFRLGlCQUFpQjtlQUMvQixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLElBQUksUUFBUTs7MEZBQ1osSUFBSSxjQUFjLFlBQVk7b0JBQzFCLFNBQVMsV0FBVyxJQUFJLGVBQWUsTUFBTTt3QkFDekMsS0FBSyxLQUFLO3dCQUNWLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLE9BQU87O29CQUVoQixXQUFXLFVBQVUsMEJBQTBCLFlBQVk7d0JBQ3ZELFFBQVEsVUFBVSxlQUFlLFVBQVUsWUFBWTs7b0JBRTNELFdBQVcsVUFBVSxjQUFjLFlBQVk7d0JBQzNDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxLQUFLLEtBQUs7NEJBQ2hCLElBQUksTUFBTSxjQUFjLFFBQVEsaUJBQWlCO2dDQUM3QyxNQUFNLEtBQUssS0FBSztnQ0FDaEIsUUFBUSxNQUFNLGNBQWMsUUFBUTs7aUNBRW5DLElBQUksTUFBTSwyQkFBMkI7Z0NBQ3RDLFVBQVUsWUFBWSxtQkFBbUIsVUFBVSxRQUFRO29DQUN2RCxRQUFRO3dDQUNKLFVBQVUsT0FBTyxPQUFPO3dDQUN4QixXQUFXLE9BQU8sT0FBTzs7bUNBRTlCLFlBQVk7b0NBQ1g7OztpQ0FHSDtnQ0FDRCxNQUFNLEtBQUssS0FBSztnQ0FDaEI7Ozs7b0JBSVosV0FBVyxVQUFVLHFCQUFxQixVQUFVLEdBQUcsR0FBRzt3QkFDdEQsSUFBSSxJQUFJO3dCQUNSLElBQUksSUFBSSxLQUFLO3dCQUNiLElBQUksSUFBSSxNQUFNLEVBQUUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxZQUFZLEtBQUssSUFBSSxFQUFFLEVBQUUsV0FBVzs0QkFDaEUsRUFBRSxFQUFFLFdBQVcsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBRSxhQUFhLE1BQU07d0JBQ25FLElBQUksVUFBVSxRQUFRLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTTt3QkFDaEQsT0FBTyxLQUFLLE1BQU0sU0FBUyxPQUFPOztvQkFFdEMsT0FBTzs7Z0JBRVgsU0FBUyxhQUFhO2dCQUN0QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxjQUFjO2VBQzVCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OzZGQUNBLElBQUkscUJBQXFCLFlBQVk7b0JBQ2pDLFNBQVMsa0JBQWtCLFFBQVEsZUFBZTt3QkFDOUMsS0FBSyxTQUFTO3dCQUNkLEtBQUssZ0JBQWdCOztvQkFFekIsa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxLQUFLLGNBQWMsZ0JBQWdCLEVBQUUsYUFBYSxNQUFNLGFBQWE7d0JBQ3JFLEtBQUssT0FBTyxHQUFHOztvQkFFbkIsa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxJQUFJLE1BQU0sU0FBUyxNQUFNLFlBQVk7NEJBQ2pDLE9BQU8sUUFBUTs7NkJBRWQ7NEJBQ0QsS0FBSyxjQUFjOzs7b0JBRzNCLE9BQU87O2dCQUVYLFNBQVMsb0JBQW9CO2dCQUM3QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxxQkFBcUI7ZUFDbkMsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7K0ZBQ0EsSUFBSSxrQkFBa0IsWUFBWTtvQkFDOUIsU0FBUyxlQUFlLElBQUksT0FBTyxlQUFlO3dCQUM5QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCOztvQkFFekIsZUFBZSxVQUFVLE1BQU0sWUFBWTt3QkFDdkMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVLFNBQVM7NEJBQy9DLE9BQU8sUUFBUTs7O29CQUd2QixPQUFPOztnQkFFWCxTQUFTLGlCQUFpQjtnQkFDMUIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsa0JBQWtCO2VBQ2hDLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7Z0JBQ0EsSUFBSSxlQUFlLE9BQU8sT0FBTzs7d0dBQ2pDLElBQUksMEJBQTBCLFlBQVk7b0JBQ3RDLFNBQVMsdUJBQXVCLGNBQWMsZUFBZTt3QkFDekQsSUFBSSxRQUFRO3dCQUNaLEtBQUssZUFBZTt3QkFDcEIsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssa0JBQWtCO3dCQUN2QixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxVQUFVO3dCQUNmLElBQUksS0FBSyxhQUFhO3dCQUN0QixJQUFJLENBQUMsYUFBYSxlQUFlOzRCQUM3QixLQUFLLGNBQWMsVUFBVSxJQUFJLEtBQUssVUFBVSxZQUFZO2dDQUN4RCxNQUFNLGFBQWE7Z0NBQ25CLE1BQU07Ozs2QkFHVDs0QkFDRCxLQUFLLGFBQWEsYUFBYTs0QkFDL0IsS0FBSzs7O29CQUdiLHVCQUF1QixVQUFVLHNCQUFzQixZQUFZO3dCQUMvRCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxjQUFjLG1CQUFtQixLQUFLLFdBQVcsYUFBYTs2QkFDOUQsS0FBSyxVQUFVLGFBQWE7NEJBQzdCLE1BQU0sa0JBQWtCOzRCQUN4QixNQUFNLFVBQVU7OztvQkFHeEIsdUJBQXVCLFVBQVUsV0FBVyxVQUFVLElBQUk7d0JBQ3RELE9BQU8sS0FBSyxjQUFjLFNBQVM7O29CQUV2Qyx1QkFBdUIsVUFBVSxrQkFBa0IsVUFBVSxJQUFJO3dCQUM3RCxPQUFPLGFBQWE7O29CQUV4QixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVywwQkFBMEI7ZUFDM0MsY0FBYyxPQUFPLGdCQUFnQixPQUFPLGNBQWM7V0FDOUQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCO2dCQUNBLElBQUksZUFBZSxPQUFPLE9BQU87O2tGQUNqQyxJQUFJLG9CQUFvQixZQUFZO29CQUNoQyxTQUFTLGlCQUFpQixlQUFlO3dCQUNyQyxLQUFLLGdCQUFnQjt3QkFDckIsS0FBSzt3QkFDTCxLQUFLO3dCQUNMLEtBQUssVUFBVTs7b0JBRW5CLGlCQUFpQixVQUFVLGlCQUFpQixZQUFZO3dCQUNwRCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssY0FBYzs2QkFDZCxLQUFLLFVBQVUsYUFBYTs0QkFDN0IsTUFBTSxjQUFjOzs2QkFFbkIsUUFBUSxZQUFZOzRCQUNyQixNQUFNLFVBQVU7OztvQkFHeEIsaUJBQWlCLFVBQVUsY0FBYyxZQUFZO3dCQUNqRCxLQUFLLFVBQVUsS0FBSyxjQUFjOztvQkFFdEMsaUJBQWlCLFVBQVUsV0FBVyxVQUFVLElBQUk7d0JBQ2hELE9BQU8sS0FBSyxjQUFjLFNBQVM7O29CQUV2QyxpQkFBaUIsVUFBVSxrQkFBa0IsVUFBVSxJQUFJO3dCQUN2RCxPQUFPLGFBQWE7O29CQUV4QixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyxvQkFBb0I7ZUFDckMsY0FBYyxPQUFPLGdCQUFnQixPQUFPLGNBQWM7V0FDOUQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzswRkFDQSxJQUFJLGFBQWEsWUFBWTtvQkFDekIsU0FBUyxVQUFVLElBQUksT0FBTyxlQUFlO3dCQUN6QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCOztvQkFFekIsVUFBVSxVQUFVLFNBQVMsWUFBWTt3QkFDckMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVLFNBQVM7NEJBQy9DLE9BQU8sUUFBUTs7O29CQUd2QixVQUFVLFVBQVUsVUFBVSxVQUFVLFVBQVUsV0FBVzt3QkFDekQsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUTtpQ0FDOUQsZUFBZTtpQ0FDZixnQkFBZ0I7NEJBQ3JCLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVLFNBQVM7NEJBQy9DLE9BQU8sUUFBUTs7O29CQUd2QixVQUFVLFVBQVUscUJBQXFCLFVBQVUsWUFBWTt3QkFDM0QsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsaUNBQWlDOzRCQUNuRyxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLFlBQVksVUFBVSxJQUFJO3dCQUMxQyxJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUSxpQkFBaUI7NEJBQ25GLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVLFNBQVM7NEJBQy9DLE9BQU8sUUFBUTs7O29CQUd2QixVQUFVLFVBQVUsV0FBVyxVQUFVLElBQUk7d0JBQ3pDLE9BQU8sQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsdUJBQXVCOztvQkFFL0YsT0FBTzs7Z0JBRVgsU0FBUyxZQUFZO2dCQUNyQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxhQUFhO2VBQzNCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OytGQUNBLElBQUksaUJBQWlCLFlBQVk7b0JBQzdCLFNBQVMsY0FBYyxJQUFJLFdBQVcsWUFBWTt3QkFDOUMsS0FBSyxLQUFLO3dCQUNWLEtBQUssWUFBWTt3QkFDakIsS0FBSyxhQUFhO3dCQUNsQixLQUFLLFdBQVc7d0JBQ2hCLEtBQUssWUFBWTs7b0JBRXJCLGNBQWMsVUFBVSxjQUFjLFVBQVUsVUFBVSxXQUFXO3dCQUNqRSxPQUFPLEtBQUssV0FBVyxtQkFBbUIsRUFBRSxVQUFVLFVBQVUsV0FBVyxhQUFhLEVBQUUsVUFBVSxLQUFLLFVBQVUsV0FBVyxLQUFLOztvQkFFdkksY0FBYyxVQUFVLHFCQUFxQixVQUFVLGFBQWE7d0JBQ2hFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLFFBQVEsSUFBSSxHQUFHLEtBQUs7NEJBQ2hELFlBQVksR0FBRyxXQUFXLEtBQUssWUFBWSxZQUFZLEdBQUcsVUFBVSxZQUFZLEdBQUc7O3dCQUV2RixPQUFPOztvQkFFWCxjQUFjLFVBQVUsU0FBUyxZQUFZO3dCQUN6QyxPQUFPLEtBQUssVUFBVTs7b0JBRTFCLGNBQWMsVUFBVSxVQUFVLFlBQVk7d0JBQzFDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVM7NEJBQzlCLE9BQU8sTUFBTSxXQUFXO2lDQUNuQixLQUFLLFVBQVUsUUFBUTtnQ0FDeEIsTUFBTSxXQUFXLE9BQU87Z0NBQ3hCLE1BQU0sWUFBWSxPQUFPO2dDQUN6QixPQUFPLE1BQU0sVUFBVSxRQUFRLE1BQU0sVUFBVSxNQUFNLFdBQVcsS0FBSyxVQUFVLGFBQWE7b0NBQ3hGLE9BQU8sUUFBUSxNQUFNLG1CQUFtQjs7Ozs7b0JBS3hELGNBQWMsVUFBVSxxQkFBcUIsVUFBVSxhQUFhO3dCQUNoRSxJQUFJLFFBQVE7d0JBQ1osSUFBSSxxQkFBcUIsWUFBWSxNQUFNO3dCQUMzQyxJQUFJLGFBQWEsbUJBQW1CLG1CQUFtQixTQUFTO3dCQUNoRSxPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVM7NEJBQzlCLE9BQU8sTUFBTSxVQUFVLG1CQUFtQixZQUFZLEtBQUssVUFBVSxLQUFLO2dDQUN0RSxJQUFJLGNBQWM7Z0NBQ2xCLElBQUksV0FBVztnQ0FDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLElBQUksR0FBRyxLQUFLO29DQUN4QyxTQUFTLEtBQUssQ0FBQyxZQUFZO3dDQUN2QixPQUFPLE1BQU0sVUFBVSxJQUFJLElBQUksS0FBSyxVQUFVLFlBQVk7NENBQ3RELFlBQVksS0FBSzs7OztnQ0FJN0IsTUFBTSxHQUFHLElBQUksVUFBVSxLQUFLLFlBQVk7b0NBQ3BDLFFBQVE7Ozs7O29CQUt4QixjQUFjLFVBQVUsWUFBWSxVQUFVLElBQUk7d0JBQzlDLE9BQU8sS0FBSyxVQUFVLFVBQVU7O29CQUVwQyxjQUFjLFVBQVUsYUFBYSxZQUFZO3dCQUM3QyxPQUFPOzRCQUNILEVBQUUsSUFBSSxXQUFXLE9BQU87NEJBQ3hCLEVBQUUsSUFBSSxnQkFBZ0IsT0FBTzs0QkFDN0IsRUFBRSxJQUFJLGNBQWMsT0FBTzs0QkFDM0IsRUFBRSxJQUFJLFlBQVksT0FBTzs0QkFDekIsRUFBRSxJQUFJLG1CQUFtQixPQUFPOzs7b0JBR3hDLGNBQWMsVUFBVSxXQUFXLFVBQVUsSUFBSTt3QkFDN0MsT0FBTyxLQUFLLFVBQVUsU0FBUzs7b0JBRW5DLE9BQU87O2dCQUVYLFNBQVMsZ0JBQWdCO2dCQUN6QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxpQkFBaUI7ZUFDL0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2I7O29HQUNBLElBQUksa0JBQWtCLFlBQVk7Z0JBQzlCLFNBQVMsZUFBZSxRQUFRLGFBQWEsa0JBQWtCO29CQUMzRCxLQUFLLFNBQVM7b0JBQ2QsS0FBSyxjQUFjO29CQUNuQixLQUFLLG1CQUFtQjs7Z0JBRTVCLGVBQWUsVUFBVSxXQUFXLFVBQVUsSUFBSTtvQkFDOUMsT0FBTyxLQUFLLGlCQUFpQixJQUFJOztnQkFFckMsT0FBTzs7WUFFWCxRQUFRLE9BQU87aUJBQ1YsV0FBVyxrQkFBa0I7V0FDbkMsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsWUFBWTtnQkFDbkIsU0FBUyxvQkFBb0I7b0JBQ3pCLE9BQU87d0JBQ0gsVUFBVTt3QkFDVixhQUFhOzs7Z0JBR3JCLFFBQVEsT0FBTztxQkFDVixVQUFVLGVBQWU7ZUFDL0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7a0lBQ0EsSUFBSSw4QkFBOEIsWUFBWTtvQkFDMUMsU0FBUywyQkFBMkIsYUFBYSxjQUFjLFlBQVksUUFBUTt3QkFDL0UsSUFBSSxRQUFRO3dCQUNaLEtBQUssY0FBYzt3QkFDbkIsS0FBSyxlQUFlO3dCQUNwQixLQUFLLGFBQWE7d0JBQ2xCLEtBQUssU0FBUzt3QkFDZCxLQUFLLFVBQVU7d0JBQ2YsS0FBSyxrQkFBa0I7d0JBQ3ZCLEtBQUssV0FBVzt3QkFDaEIsS0FBSzt3QkFDTCxPQUFPLE9BQU8sWUFBWTs0QkFDdEIsTUFBTTs7O29CQUdkLDJCQUEyQixVQUFVLFVBQVUsWUFBWTt3QkFDdkQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixLQUFLLFlBQVksSUFBSSxLQUFLLGFBQWE7NkJBQ2xDLEtBQUssVUFBVSxNQUFNOzRCQUN0QixNQUFNLE9BQU87OzZCQUVaLE1BQU0sWUFBWTs7OzZCQUdsQixRQUFRLFlBQVk7NEJBQ3JCLE1BQU0sVUFBVTs7O29CQUd4QiwyQkFBMkIsVUFBVSxjQUFjLFlBQVk7d0JBQzNELElBQUksUUFBUTt3QkFDWixJQUFJLEtBQUssaUJBQWlCOzRCQUN0QixLQUFLOzs2QkFFSjs0QkFDRCxLQUFLLFdBQVc7aUNBQ1gsS0FBSyxVQUFVLE1BQU07Z0NBQ3RCLE1BQU0sa0JBQWtCO2dDQUN4QixNQUFNOzs7O29CQUlsQiwyQkFBMkIsVUFBVSxlQUFlLFlBQVk7d0JBQzVELElBQUksS0FBSyxNQUFNOzRCQUNYLEtBQUssV0FBVyxLQUFLLFdBQVcsbUJBQW1CLEtBQUssaUJBQWlCLEVBQUUsVUFBVSxLQUFLLEtBQUssVUFBVSxXQUFXLEtBQUssS0FBSzs7O29CQUd0SSxPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyw4QkFBOEI7ZUFDL0MsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCOzt3RkFDQSxJQUFJLDRCQUE0QixZQUFZO29CQUN4QyxTQUFTLHlCQUF5QixhQUFhO3dCQUMzQyxLQUFLLGNBQWM7d0JBQ25CLEtBQUs7O29CQUVULHlCQUF5QixVQUFVLFdBQVcsWUFBWTt3QkFDdEQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixLQUFLLFlBQVk7NkJBQ1osS0FBSyxVQUFVLE1BQU07NEJBQ3RCLE1BQU0sWUFBWTs7NkJBRWpCLFFBQVEsWUFBWTs0QkFDckIsTUFBTSxVQUFVOzs7b0JBR3hCLHlCQUF5QixVQUFVLGNBQWMsVUFBVSxPQUFPO3dCQUM5RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxZQUFZO3dCQUNqQixLQUFLLGNBQWM7d0JBQ25CLE1BQU0sUUFBUSxVQUFVLE1BQU07NEJBQzFCLElBQUksS0FBSyxXQUFXLEtBQUssT0FBTyxXQUFXLE1BQU07Z0NBQzdDLE1BQU0sVUFBVSxLQUFLOztpQ0FFcEIsSUFBSSxLQUFLLFdBQVcsS0FBSyxPQUFPLFdBQVcsUUFBUTtnQ0FDcEQsTUFBTSxZQUFZLEtBQUs7Ozs7b0JBSW5DLE9BQU87O2dCQUVYLFFBQVEsT0FBTztxQkFDVixXQUFXLDRCQUE0QjtlQUM3QyxjQUFjLEtBQUssZ0JBQWdCLEtBQUssY0FBYztXQUMxRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7O3dGQUNBLElBQUksV0FBVyxZQUFZO29CQUN2QixTQUFTLFFBQVEsSUFBSSxPQUFPLGVBQWU7d0JBQ3ZDLEtBQUssS0FBSzt3QkFDVixLQUFLLFFBQVE7d0JBQ2IsS0FBSyxnQkFBZ0I7O29CQUV6QixRQUFRLFVBQVUsU0FBUyxZQUFZO3dCQUNuQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLElBQUksVUFBVTtnQ0FDVixLQUFLLENBQUMsTUFBTSxjQUFjLElBQUksTUFBTSxNQUFNLGNBQWMsSUFBSSxRQUFRO2dDQUNwRSxRQUFROzs0QkFFWixNQUFNLE1BQU07aUNBQ1AsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVE7Ozs7b0JBSXBCLFFBQVEsVUFBVSxVQUFVLFVBQVUsVUFBVSxXQUFXO3dCQUN2RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLElBQUksVUFBVTtnQ0FDVixLQUFLLENBQUMsQ0FBQyxNQUFNLGNBQWMsSUFBSSxNQUFNLE1BQU0sY0FBYyxJQUFJLFFBQVE7cUNBQ2hFLGVBQWU7cUNBQ2YsZ0JBQWdCO2dDQUNyQixRQUFROzs0QkFFWixNQUFNLE1BQU07aUNBQ1AsS0FBSyxTQUFTOzs7b0JBRzNCLFFBQVEsVUFBVSxNQUFNLFVBQVUsSUFBSTt3QkFDbEMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsV0FBVzs0QkFDN0UsUUFBUTs7d0JBRVosT0FBTyxLQUFLLE1BQU07O29CQUV0QixPQUFPOztnQkFFWCxTQUFTLFVBQVU7Z0JBQ25CLFFBQVEsT0FBTztxQkFDVixRQUFRLFdBQVc7ZUFDekIsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7MkZBQ0EsSUFBSSxlQUFlLFlBQVk7b0JBQzNCLFNBQVMsWUFBWSxJQUFJLFNBQVMsWUFBWTt3QkFDMUMsS0FBSyxLQUFLO3dCQUNWLEtBQUssVUFBVTt3QkFDZixLQUFLLGFBQWE7O29CQUV0QixZQUFZLFVBQVUsU0FBUyxZQUFZO3dCQUN2QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sUUFBUTtpQ0FDVCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUSxTQUFTLEtBQUssSUFBSSxVQUFVLE1BQU07b0NBQ3RDLE9BQU8sSUFBSSxLQUFLLE9BQU8sT0FBTyxVQUFVOzs7OztvQkFLeEQsWUFBWSxVQUFVLFVBQVUsWUFBWTt3QkFDeEMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFdBQVc7aUNBQ1osS0FBSyxVQUFVLFFBQVE7Z0NBQ3hCLE9BQU8sTUFBTSxRQUFRLFFBQVEsT0FBTyxVQUFVLE9BQU87O2lDQUVwRCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUSxTQUFTLEtBQUssSUFBSSxVQUFVLE1BQU07b0NBQ3RDLE9BQU8sSUFBSSxLQUFLLE9BQU8sT0FBTyxVQUFVOzs7aUNBRzNDLE1BQU07OztvQkFHbkIsWUFBWSxVQUFVLE1BQU0sVUFBVSxJQUFJO3dCQUN0QyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sUUFBUSxJQUFJO2lDQUNiLEtBQUssVUFBVSxRQUFRO2dDQUN4QixRQUFRLElBQUksS0FBSyxPQUFPLE9BQU8sVUFBVSxPQUFPOztpQ0FFL0MsTUFBTTs7O29CQUduQixPQUFPOztnQkFFWCxTQUFTLGNBQWM7Z0JBQ3ZCLFFBQVEsT0FBTztxQkFDVixRQUFRLGVBQWU7ZUFDN0IsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7cVBBQ0EsSUFBSSw0QkFBNEIsWUFBWTtvQkFDeEMsU0FBUyx5QkFBeUIsUUFBUSxlQUFlLGtCQUFrQixrQkFBa0IsYUFBYSxXQUFXLFVBQVUsV0FBVyxjQUFjLGFBQWEsbUJBQW1CO3dCQUNwTCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxTQUFTO3dCQUNkLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLG1CQUFtQjt3QkFDeEIsS0FBSyxtQkFBbUI7d0JBQ3hCLEtBQUssY0FBYzt3QkFDbkIsS0FBSyxZQUFZO3dCQUNqQixLQUFLLFdBQVc7d0JBQ2hCLEtBQUssWUFBWTt3QkFDakIsS0FBSyxlQUFlO3dCQUNwQixLQUFLLGNBQWM7d0JBQ25CLEtBQUssb0JBQW9CO3dCQUN6QixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxrQkFBa0I7O3dCQUV2QixLQUFLLFNBQVMsSUFBSSxPQUFPLE9BQU87d0JBQ2hDLEtBQUssWUFBWTs7d0JBRWpCLElBQUksYUFBYSxVQUFVOzRCQUN2QixLQUFLOzs2QkFFSjs0QkFDRCxLQUFLOzs7d0JBR1QsT0FBTyxZQUFZLElBQUk7d0JBQ3ZCLE9BQU8sVUFBVSxTQUFTO3dCQUMxQixPQUFPLFVBQVUsV0FBVzt3QkFDNUIsT0FBTyxVQUFVLFdBQVc7Ozs7Ozt3QkFNNUIsT0FBTyxZQUFZOzRCQUNmLEtBQUs7NEJBQ0wsTUFBTTs7Ozs7O3dCQU1WLE9BQU8sYUFBYTs0QkFDaEIsVUFBVTs0QkFDVixVQUFVOzRCQUNWLFVBQVU7NEJBQ1YsU0FBUzs7O3dCQUdiLE9BQU8saUJBQWlCLGFBQWEsWUFBWTs0QkFDN0MsSUFBSSxDQUFDLE9BQU8sVUFBVSxLQUFLO2dDQUN2Qjs7NEJBRUosTUFBTSxPQUFPLFlBQVksUUFBUSxLQUFLLE9BQU8sVUFBVTs0QkFDdkQsSUFBSSxPQUFPLFVBQVUsTUFBTTtnQ0FDdkIsTUFBTSxPQUFPLFVBQVUsU0FBUyxPQUFPLFVBQVUsS0FBSztnQ0FDdEQsTUFBTSxPQUFPLFVBQVUsV0FBVyxPQUFPLFVBQVUsS0FBSzs7NEJBRTVELE1BQU07Ozt3QkFHVixPQUFPLGlCQUFpQixjQUFjLFlBQVk7NEJBQzlDLE1BQU0sT0FBTyxXQUFXLE9BQU8sV0FBVyxXQUFXLE9BQU8sV0FBVyxTQUFTLEtBQUs7NEJBQ3JGLE1BQU0sT0FBTyxXQUFXLE9BQU8sV0FBVyxXQUFXLE9BQU8sV0FBVyxTQUFTLEtBQUs7NEJBQ3JGLE1BQU0sT0FBTyxXQUFXLE9BQU8sV0FBVyxXQUFXLE9BQU8sV0FBVyxTQUFTLEtBQUs7NEJBQ3JGLE1BQU0sT0FBTyxVQUFVLE9BQU8sV0FBVyxVQUFVLE9BQU8sV0FBVyxRQUFRLEtBQUs7OztvQkFHMUYseUJBQXlCLFVBQVUsWUFBWSxZQUFZO3dCQUN2RCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssY0FBYyxJQUFJLEtBQUssYUFBYTs2QkFDcEMsS0FBSyxVQUFVLFFBQVE7NEJBQ3hCLE1BQU0sU0FBUzs0QkFDZixNQUFNOzRCQUNOLE1BQU0sVUFBVTs7Ozs7OztvQkFPeEIseUJBQXlCLFVBQVUsaUJBQWlCLFlBQVk7d0JBQzVELElBQUksUUFBUSxLQUFLLE9BQU8sVUFBVTt3QkFDbEMsSUFBSSxVQUFVLEtBQUssT0FBTyxVQUFVO3dCQUNwQyxLQUFLLE9BQU8sWUFBWTs0QkFDcEIsS0FBSyxLQUFLLE9BQU87NEJBQ2pCLE1BQU0sS0FBSyxZQUFZLFFBQVEsQ0FBQyxRQUFRLE1BQU07O3dCQUVsRCxLQUFLLE9BQU8sYUFBYTs0QkFDckIsVUFBVSxLQUFLLGlCQUFpQixRQUFRLEtBQUssT0FBTzs0QkFDcEQsVUFBVSxLQUFLLGlCQUFpQixRQUFRLEtBQUssT0FBTzs0QkFDcEQsVUFBVSxLQUFLLFVBQVUsUUFBUSxLQUFLLE9BQU87NEJBQzdDLFNBQVMsS0FBSyxTQUFTLFFBQVEsS0FBSyxPQUFPOzs7Ozs7O29CQU9uRCx5QkFBeUIsVUFBVSxjQUFjLFlBQVk7d0JBQ3pELEtBQUssU0FBUyxJQUFJLE9BQU8sT0FBTzt3QkFDaEMsS0FBSyxJQUFJLEtBQUssS0FBSyxPQUFPLFdBQVc7NEJBQ2pDLElBQUksS0FBSyxPQUFPLFVBQVUsZUFBZSxJQUFJO2dDQUN6QyxLQUFLLE9BQU8sVUFBVSxLQUFLOzs7d0JBR25DLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTyxZQUFZOzRCQUNsQyxJQUFJLEtBQUssT0FBTyxXQUFXLGVBQWUsSUFBSTtnQ0FDMUMsS0FBSyxPQUFPLFdBQVcsS0FBSzs7OztvQkFJeEMseUJBQXlCLFVBQVUsV0FBVyxZQUFZO3dCQUN0RCxLQUFLLE9BQU8sTUFBTTs7b0JBRXRCLHlCQUF5QixVQUFVLG9CQUFvQixZQUFZO3dCQUMvRCxJQUFJLFFBQVE7d0JBQ1osSUFBSSxLQUFLLFdBQVcsUUFBUTs0QkFDeEIsS0FBSyxVQUFVOzRCQUNmLElBQUksZ0JBQWdCOzRCQUNwQixJQUFJLEtBQUssYUFBYSxVQUFVO2dDQUM1QixnQkFBZ0IsS0FBSzs7aUNBRXBCO2dDQUNELGdCQUFnQixLQUFLOzs0QkFFekI7aUNBQ0ssUUFBUSxZQUFZO2dDQUNyQixNQUFNLFVBQVU7Ozs7b0JBSTVCLHlCQUF5QixVQUFVLGlCQUFpQixZQUFZO3dCQUM1RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLGNBQWMsSUFBSSxLQUFLOzZCQUM5QixLQUFLLFlBQVk7NEJBQ2xCLE1BQU07NEJBQ04sTUFBTSxXQUFXOzRCQUNqQixNQUFNLFdBQVc7NEJBQ2pCLE1BQU07OztvQkFHZCx5QkFBeUIsVUFBVSxrQkFBa0IsWUFBWTt3QkFDN0QsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxjQUFjLEtBQUssS0FBSzs2QkFDL0IsS0FBSyxZQUFZOzRCQUNsQixNQUFNLGtCQUFrQjs7O29CQUdoQyx5QkFBeUIsVUFBVSxrQkFBa0IsWUFBWTt3QkFDN0QsSUFBSSxRQUFRO3dCQUNaLEtBQUssY0FBYyxnQkFBZ0IsS0FBSyxPQUFPOzZCQUMxQyxLQUFLLFVBQVUsUUFBUTs0QkFDeEIsTUFBTSxrQkFBa0I7OzZCQUV2QixNQUFNLFlBQVk7Ozs7b0JBSTNCLHlCQUF5QixVQUFVLG9CQUFvQixZQUFZO3dCQUMvRCxLQUFLLE9BQU8sWUFBWTt3QkFDeEIsSUFBSSxLQUFLLE9BQU8sYUFBYSxLQUFLLE9BQU8sU0FBUzs0QkFDOUMsS0FBSyxPQUFPLFlBQVk7NEJBQ3hCLElBQUksT0FBTyxLQUFLLE1BQU0sQ0FBQyxLQUFLLE9BQU8sUUFBUSxZQUFZLEtBQUssT0FBTyxVQUFVLGFBQWEsT0FBTyxLQUFLLEtBQUs7NEJBQzNHLEtBQUssT0FBTyxZQUFZLEtBQUssT0FBTyxhQUFhLE9BQU87O3dCQUU1RCxPQUFPLEtBQUssT0FBTzs7b0JBRXZCLE9BQU87O2dCQUVYLFFBQVEsT0FBTztxQkFDVixXQUFXLDRCQUE0QjtlQUM3QyxjQUFjLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztXQUM5RCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O2tIQUNBLElBQUkscUJBQXFCLFlBQVk7b0JBQ2pDLFNBQVMsa0JBQWtCLG9CQUFvQixRQUFRLGNBQWM7d0JBQ2pFLEtBQUsscUJBQXFCO3dCQUMxQixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxlQUFlO3dCQUNwQixPQUFPLElBQUksZ0JBQWdCLFlBQVk7NEJBQ25DLG1CQUFtQixhQUFhLGdCQUFnQixPQUFPOzRCQUN2RCxPQUFPLFdBQVc7OztvQkFHMUIsT0FBTzs7Z0JBRVgsWUFBWSxvQkFBb0I7Z0JBQ2hDLFFBQVEsT0FBTztxQkFDVixXQUFXLHFCQUFxQjtlQUN0QyxjQUFjLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztXQUM5RCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7OzJIQUNBLElBQUksNkJBQTZCLFlBQVk7b0JBQ3pDLFNBQVMsMEJBQTBCLFFBQVEsZUFBZSxRQUFRLFVBQVU7d0JBQ3hFLElBQUksUUFBUTt3QkFDWixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssU0FBUzt3QkFDZCxLQUFLLFdBQVc7d0JBQ2hCLEtBQUssY0FBYzt3QkFDbkIsS0FBSzt3QkFDTCxPQUFPLElBQUksMkJBQTJCLFlBQVk7NEJBQzlDLE1BQU07aUNBQ0QsUUFBUSxZQUFZO2dDQUNyQixNQUFNLGNBQWM7Ozs7b0JBSWhDLDBCQUEwQixVQUFVLGFBQWEsWUFBWTt3QkFDekQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixPQUFPLEtBQUssY0FBYzs2QkFDckIsS0FBSyxVQUFVLE1BQU07NEJBQ3RCLE1BQU0sVUFBVTs7NkJBRWYsUUFBUSxZQUFZOzRCQUNyQixNQUFNLFVBQVU7OztvQkFHeEIsMEJBQTBCLFVBQVUsbUJBQW1CLFVBQVUsUUFBUTt3QkFDckUsSUFBSSxRQUFRO3dCQUNaLEtBQUssbUJBQW1CO3dCQUN4QixLQUFLLFNBQVMsWUFBWTs0QkFDdEIsTUFBTSxPQUFPLEdBQUcscUJBQXFCLEVBQUUsVUFBVSxPQUFPOzJCQUN6RDs7b0JBRVAsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsNkJBQTZCO2VBQzlDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxTQUFTO2dCQUNoQjtnQkFDQSxTQUFTLHVCQUF1QjtvQkFDNUIsT0FBTyxVQUFVLE9BQU87d0JBQ3BCLE9BQU8sT0FBTyxPQUFPLGVBQWU7OztnQkFHNUMsUUFBUSxPQUFPO3FCQUNWLE9BQU8scUJBQXFCO2VBQ2xDLFVBQVUsT0FBTyxZQUFZLE9BQU8sVUFBVTtXQUNsRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsU0FBUztnQkFDaEI7Z0JBQ0EsU0FBUyx1QkFBdUI7b0JBQzVCLE9BQU8sVUFBVSxPQUFPO3dCQUNwQixPQUFPLE9BQU8sT0FBTyxlQUFlOzs7Z0JBRzVDLFFBQVEsT0FBTztxQkFDVixPQUFPLHFCQUFxQjtlQUNsQyxVQUFVLE9BQU8sWUFBWSxPQUFPLFVBQVU7V0FDbEQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLElBQUksZUFBZSxZQUFZO29CQUMzQixTQUFTLGNBQWM7d0JBQ25CLEtBQUssTUFBTTs7b0JBRWYsWUFBWSxVQUFVLFVBQVUsVUFBVSxHQUFHO3dCQUN6QyxJQUFJLFNBQVMsS0FBSyxNQUFNLElBQUk7d0JBQzVCLElBQUksV0FBVyxLQUFLLFNBQVM7d0JBQzdCLElBQUksUUFBUTt3QkFDWixJQUFJLFVBQVU7d0JBQ2QsSUFBSSxNQUFNO3dCQUNWLElBQUksUUFBUSxJQUFJOzRCQUNaLFFBQVEsUUFBUTs0QkFDaEIsTUFBTTs7d0JBRVYsSUFBSSxZQUFZLE1BQU07d0JBQ3RCLElBQUksY0FBYyxRQUFRO3dCQUMxQixJQUFJLFVBQVUsV0FBVyxHQUFHOzRCQUN4QixZQUFZLE1BQU07O3dCQUV0QixJQUFJLFlBQVksV0FBVyxHQUFHOzRCQUMxQixjQUFjLE1BQU07O3dCQUV4QixPQUFPOzRCQUNILElBQUk7NEJBQ0osT0FBTyxZQUFZLE1BQU0sY0FBYyxNQUFNOzRCQUM3QyxPQUFPOzRCQUNQLFNBQVM7OztvQkFHakIsWUFBWSxVQUFVLGNBQWMsWUFBWTt3QkFDNUMsSUFBSSxTQUFTO3dCQUNiLElBQUksYUFBYTt3QkFDakIsSUFBSSxhQUFhO3dCQUNqQixJQUFJLFFBQVE7d0JBQ1osS0FBSyxJQUFJLElBQUksWUFBWSxLQUFLLFlBQVksSUFBSSxJQUFJLE9BQU87NEJBQ3JELE9BQU8sS0FBSyxLQUFLLFFBQVE7O3dCQUU3QixLQUFLLE1BQU07O29CQUVmLE9BQU87O2dCQUVYLFNBQVMsY0FBYztnQkFDdkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsZUFBZTtlQUM3QixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsWUFBWTtvQkFDakIsSUFBSSxTQUFTO29CQUNiLEtBQUssSUFBSSxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7d0JBQzNCLE9BQU8sS0FBSzs0QkFDUixJQUFJOzRCQUNKLE9BQU8sSUFBSTs7O29CQUduQjtvQkFDQSxPQUFPO3dCQUNILFNBQVMsVUFBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksSUFBSSxPQUFPLEtBQUs7d0JBQ3ZELEtBQUs7OztnQkFHYixTQUFTLFlBQVk7Z0JBQ3JCLFFBQVEsT0FBTztxQkFDVixRQUFRLGFBQWE7ZUFDM0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLG1CQUFtQjtvQkFDeEIsT0FBTzt3QkFDSCxTQUFTLFVBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksT0FBTyxPQUFPLE9BQU8sZUFBZTt3QkFDL0UsS0FBSyxPQUFPLEtBQUssT0FBTyxPQUFPOzZCQUMxQixJQUFJLFVBQVUsR0FBRyxFQUFFLE9BQU8sU0FBUyxHQUFHOzZCQUN0QyxPQUFPLFVBQVUsR0FBRyxFQUFFLE9BQU8sQ0FBQyxNQUFNOzZCQUNwQyxJQUFJLFVBQVUsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsT0FBTyxPQUFPLE9BQU8sZUFBZTs7O2dCQUdyRixTQUFTLG1CQUFtQjtnQkFDNUIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsb0JBQW9CO2VBQ2xDLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxtQkFBbUI7b0JBQ3hCLE9BQU87d0JBQ0gsU0FBUyxVQUFVLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUFJLE9BQU8sT0FBTyxPQUFPLGVBQWU7d0JBQy9FLEtBQUssT0FBTyxLQUFLLE9BQU8sT0FBTzs2QkFDMUIsSUFBSSxVQUFVLEdBQUcsRUFBRSxPQUFPLFNBQVMsR0FBRzs2QkFDdEMsT0FBTyxVQUFVLEdBQUcsRUFBRSxPQUFPLENBQUMsTUFBTSxNQUFNLE1BQU07NkJBQ2hELElBQUksVUFBVSxHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxPQUFPLE9BQU8sT0FBTyxlQUFlOzs7Z0JBR3JGLFNBQVMsbUJBQW1CO2dCQUM1QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxvQkFBb0I7ZUFDbEMsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLGNBQWM7b0JBQ25CLE9BQU8sT0FBTyxLQUFLLE9BQU8sT0FBTzt5QkFDNUIsSUFBSSxVQUFVLEdBQUcsRUFBRSxPQUFPLFNBQVMsR0FBRzt5QkFDdEMsT0FBTyxVQUFVLEdBQUcsRUFBRSxPQUFPLENBQUMsTUFBTTt5QkFDcEMsSUFBSSxVQUFVLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLE9BQU8sT0FBTyxPQUFPLFdBQVc7O2dCQUU3RSxTQUFTLGNBQWM7Z0JBQ3ZCLFFBQVEsT0FBTztxQkFDVixRQUFRLGVBQWU7ZUFDN0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7MEZBQ0EsSUFBSSxhQUFhLFlBQVk7b0JBQ3pCLFNBQVMsVUFBVSxJQUFJLE9BQU8sZUFBZTt3QkFDekMsS0FBSyxLQUFLO3dCQUNWLEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjs7b0JBRXpCLFVBQVUsVUFBVSxNQUFNLFVBQVUsVUFBVTt3QkFDMUMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxJQUFJLFVBQVU7Z0NBQ1YsS0FBSyxDQUFDLE1BQU0sY0FBYyxJQUFJLE1BQU0sTUFBTSxjQUFjLElBQUksUUFBUSxhQUFhO2dDQUNqRixRQUFROzs0QkFFWixNQUFNLE1BQU07aUNBQ1AsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVE7Ozs7b0JBSXBCLFVBQVUsVUFBVSxTQUFTLFlBQVk7d0JBQ3JDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsSUFBSSxVQUFVO2dDQUNWLEtBQUssQ0FBQyxNQUFNLGNBQWMsSUFBSSxNQUFNLE1BQU0sY0FBYyxJQUFJLFFBQVE7Z0NBQ3BFLFFBQVE7OzRCQUVaLE1BQU0sTUFBTTtpQ0FDUCxLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUTs7OztvQkFJcEIsVUFBVSxVQUFVLE1BQU0sVUFBVSxRQUFRO3dCQUN4QyxJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUTs0QkFDbEUsUUFBUTs0QkFDUixNQUFNOzt3QkFFVixPQUFPLEtBQUssTUFBTTs7b0JBRXRCLFVBQVUsVUFBVSxPQUFPLFVBQVUsUUFBUTt3QkFDekMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7NEJBQ1IsTUFBTTs7d0JBRVYsT0FBTyxLQUFLLE1BQU07O29CQUV0QixVQUFVLFVBQVUsa0JBQWtCLFVBQVUsTUFBTTt3QkFDbEQsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsb0NBQW9DOzRCQUN0RyxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTTs7b0JBRXRCLE9BQU87O2dCQUVYLFNBQVMsWUFBWTtnQkFDckIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsYUFBYTtlQUMzQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzsrRkFDQSxJQUFJLGlCQUFpQixZQUFZO29CQUM3QixTQUFTLGNBQWMsSUFBSSxXQUFXLFlBQVk7d0JBQzlDLEtBQUssS0FBSzt3QkFDVixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssYUFBYTs7b0JBRXRCLGNBQWMsVUFBVSxNQUFNLFVBQVUsVUFBVTt3QkFDOUMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFVBQVUsSUFBSTtpQ0FDZixLQUFLLFVBQVUsVUFBVTtnQ0FDMUIsUUFBUSxJQUFJLE9BQU8sT0FBTyxTQUFTLFVBQVUsU0FBUzs7OztvQkFJbEUsY0FBYyxVQUFVLFNBQVMsWUFBWTt3QkFDekMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFVBQVU7aUNBQ1gsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVEsU0FBUyxLQUFLLElBQUksVUFBVSxNQUFNO29DQUN0QyxPQUFPLElBQUksT0FBTyxPQUFPLFNBQVMsVUFBVTs7Ozs7b0JBSzVELGNBQWMsVUFBVSxNQUFNLFVBQVUsUUFBUTt3QkFDNUMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFVBQVUsSUFBSSxPQUFPO2lDQUN0QixLQUFLLFlBQVk7Z0NBQ2xCOztpQ0FFQyxNQUFNLFlBQVk7Z0NBQ25COzs7O29CQUlaLGNBQWMsVUFBVSxPQUFPLFVBQVUsUUFBUTt3QkFDN0MsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFVBQVUsS0FBSyxPQUFPO2lDQUN2QixLQUFLLFlBQVk7Z0NBQ2xCOztpQ0FFQyxNQUFNLFlBQVk7Z0NBQ25COzs7O29CQUlaLGNBQWMsVUFBVSxrQkFBa0IsVUFBVSxNQUFNO3dCQUN0RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sVUFBVSxnQkFBZ0IsS0FBSztpQ0FDaEMsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVEsU0FBUzs7aUNBRWhCLE1BQU0sWUFBWTtnQ0FDbkI7Ozs7b0JBSVosT0FBTzs7Z0JBRVgsU0FBUyxnQkFBZ0I7Z0JBQ3pCLFFBQVEsT0FBTztxQkFDVixRQUFRLGlCQUFpQjtlQUMvQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsWUFBWTtvQkFDakIsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLElBQUk7d0JBQ2pFLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSTs7Z0JBRTlELFNBQVMsWUFBWTtnQkFDckIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsYUFBYTtlQUMzQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsV0FBVztvQkFDaEIsSUFBSSxTQUFTO29CQUNiLEtBQUssSUFBSSxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUs7d0JBQzdCLE9BQU8sS0FBSzs0QkFDUixJQUFJOzRCQUNKLE9BQU8sSUFBSTs7O29CQUduQjtvQkFDQSxPQUFPO3dCQUNILFNBQVMsVUFBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksSUFBSSxPQUFPLEtBQUs7d0JBQ3ZELEtBQUs7OztnQkFHYixTQUFTLFdBQVc7Z0JBQ3BCLFFBQVEsT0FBTztxQkFDVixRQUFRLFlBQVk7ZUFDMUIsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCIiwiZmlsZSI6Ii4uLy4uL3d3d3Jvb3QvanMvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgICd1c2Ugc3RyaWN0JztcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAnLCBbXG4gICAgICAgICAgICAnaW9uaWMnLFxuICAgICAgICAgICAgJ2FwcC5jb3JlJyxcbiAgICAgICAgICAgICdhcHAuYXV0aCcsXG4gICAgICAgICAgICAnYXBwLmhvbWUnLFxuICAgICAgICAgICAgJ2FwcC5saWZ0JyxcbiAgICAgICAgICAgICdhcHAuZGluaW5nJyxcbiAgICAgICAgICAgICdhcHAucmVudGFsJ1xuICAgICAgICBdKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgZnVuY3Rpb24gcnVuKCRpb25pY1BsYXRmb3JtLCAkbG9nKSB7XG4gICAgICAgICAgICAkaW9uaWNQbGF0Zm9ybS5yZWFkeShkZXZpY2VSZWFkeS5jYWxsKHRoaXMsICRsb2cpKTtcbiAgICAgICAgfVxuICAgICAgICBmdW5jdGlvbiBkZXZpY2VSZWFkeSgkbG9nKSB7XG4gICAgICAgICAgICAkbG9nLmluZm8oJ0RldmljZSBSZWFkeScpO1xuICAgICAgICB9XG4gICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAnKVxuICAgICAgICAgICAgLnJ1bihydW4pO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnLCBbXSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnLCBbXSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnLCBbXSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgSG9tZTtcbiAgICAgICAgKGZ1bmN0aW9uIChIb21lKSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmhvbWUnLCBbXSk7XG4gICAgICAgIH0pKEhvbWUgPSBBcHAuSG9tZSB8fCAoQXBwLkhvbWUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnLCBbXSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnLCBbXSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgZnVuY3Rpb24gcm91dGluZ0NvbmZpZ3VyYXRpb24oJHN0YXRlUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5sb2dpbicsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2xvZ2luJyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdMb2dpbkNvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2F1dGgvdGVtcGxhdGVzL2xvZ2luLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShBdXRoID0gQXBwLkF1dGggfHwgKEFwcC5BdXRoID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJycsXG4gICAgICAgICAgICAgICAgICAgIGFic3RyYWN0OiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnTWVudUNvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnY29yZS90ZW1wbGF0ZXMvbWVudS50ZW1wbGF0ZS5odG1sJ1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gaW9uaWNDb25maWd1cmF0aW9uKCRpb25pY0NvbmZpZ1Byb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJGlvbmljQ29uZmlnUHJvdmlkZXIuc2Nyb2xsaW5nLmpzU2Nyb2xsaW5nKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbilcbiAgICAgICAgICAgICAgICAuY29uZmlnKGlvbmljQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAuZGluaW5nLWxpc3QnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9kaW5pbmcvbGlzdCcsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnRGluaW5nQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnZGluaW5nL3RlbXBsYXRlcy9kaW5pbmctbGlzdC50ZW1wbGF0ZS5odG1sJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAuZGluaW5nLWRldGFpbCcsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2RpbmluZy9kZXRhaWwvOmlkJyxcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0YXVyYW50OiBudWxsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnRGluaW5nRGV0YWlsQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnZGluaW5nL3RlbXBsYXRlcy9kaW5pbmctZGV0YWlsLnRlbXBsYXRlLmh0bWwnXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJylcbiAgICAgICAgICAgICAgICAuY29uZmlnKHJvdXRpbmdDb25maWd1cmF0aW9uKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgSG9tZTtcbiAgICAgICAgKGZ1bmN0aW9uIChIb21lKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlciwgJHVybFJvdXRlclByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAuaG9tZScsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2hvbWUnLFxuICAgICAgICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBiYXJDb2xvcjogJ2RhcmsnXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnSG9tZUNvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2hvbWUvdGVtcGxhdGVzL2hvbWUudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAkdXJsUm91dGVyUHJvdmlkZXIub3RoZXJ3aXNlKCcvaG9tZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5ob21lJylcbiAgICAgICAgICAgICAgICAuY29uZmlnKHJvdXRpbmdDb25maWd1cmF0aW9uKTtcbiAgICAgICAgfSkoSG9tZSA9IEFwcC5Ib21lIHx8IChBcHAuSG9tZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlciwgJHVybFJvdXRlclByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAubGlmdC1zdGF0dXMtbGlzdCcsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2xpZnQvc3RhdHVzL2xpc3QnLFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0xpZnRTdGF0dXNMaXN0Q29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnbGlmdC90ZW1wbGF0ZXMvbGlmdC1zdGF0dXMtbGlzdC50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmxpZnQtc3RhdHVzLWRldGFpbCcsIHtcbiAgICAgICAgICAgICAgICAgICAgdXJsOiAnL2xpZnQvc3RhdHVzL2RldGFpbC86bGlmdElkJyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnbGlmdC90ZW1wbGF0ZXMvbGlmdC1zdGF0dXMtZGV0YWlsLnRlbXBsYXRlLmh0bWwnXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyLCAkdXJsUm91dGVyUHJvdmlkZXIpIHtcbiAgICAgICAgICAgICAgICAkc3RhdGVQcm92aWRlclxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5yZW50YWxzJywge1xuICAgICAgICAgICAgICAgICAgICBjYWNoZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9yZW50YWxzJyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAncmVudGFsL3RlbXBsYXRlcy9yZW50YWxzLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdSZW50YWxzQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5yZW50YWwtZGV0YWlsJywge1xuICAgICAgICAgICAgICAgICAgICBjYWNoZTogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9yZW50YWwvOnJlbnRhbElkJyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAncmVudGFsL3RlbXBsYXRlcy9uZXctcmVzZXJ2YXRpb24td3JhcHBlci50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICd0YWJDdHJsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBBdXRoLk1vZGVscyB8fCAoQXV0aC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShBdXRoID0gQXBwLkF1dGggfHwgKEFwcC5BdXRoID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBTdW1tYXJ5SW5mbyA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFN1bW1hcnlJbmZvKCkge1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdW1tYXJ5SW5mbztcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIE1vZGVscy5TdW1tYXJ5SW5mbyA9IFN1bW1hcnlJbmZvO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gQ29yZS5Nb2RlbHMgfHwgKENvcmUuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKFdlYXRoZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgV2VhdGhlcltXZWF0aGVyW1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIFdlYXRoZXJbV2VhdGhlcltcIlNub3dpbmdcIl0gPSAxXSA9IFwiU25vd2luZ1wiO1xuICAgICAgICAgICAgICAgICAgICBXZWF0aGVyW1dlYXRoZXJbXCJSYWlueVwiXSA9IDJdID0gXCJSYWlueVwiO1xuICAgICAgICAgICAgICAgICAgICBXZWF0aGVyW1dlYXRoZXJbXCJDbG91ZHlcIl0gPSAzXSA9IFwiQ2xvdWR5XCI7XG4gICAgICAgICAgICAgICAgICAgIFdlYXRoZXJbV2VhdGhlcltcIlN1bm55XCJdID0gNF0gPSBcIlN1bm55XCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLldlYXRoZXIgfHwgKE1vZGVscy5XZWF0aGVyID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgV2VhdGhlciA9IE1vZGVscy5XZWF0aGVyO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gQ29yZS5Nb2RlbHMgfHwgKENvcmUuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChMZXZlbE9mTm9pc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgTGV2ZWxPZk5vaXNlW0xldmVsT2ZOb2lzZVtcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBMZXZlbE9mTm9pc2VbTGV2ZWxPZk5vaXNlW1wiTG93XCJdID0gMV0gPSBcIkxvd1wiO1xuICAgICAgICAgICAgICAgICAgICBMZXZlbE9mTm9pc2VbTGV2ZWxPZk5vaXNlW1wiTWVkaXVtXCJdID0gMl0gPSBcIk1lZGl1bVwiO1xuICAgICAgICAgICAgICAgICAgICBMZXZlbE9mTm9pc2VbTGV2ZWxPZk5vaXNlW1wiTG91ZFwiXSA9IDNdID0gXCJMb3VkXCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLkxldmVsT2ZOb2lzZSB8fCAoTW9kZWxzLkxldmVsT2ZOb2lzZSA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIExldmVsT2ZOb2lzZSA9IE1vZGVscy5MZXZlbE9mTm9pc2U7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBEaW5pbmcuTW9kZWxzIHx8IChEaW5pbmcuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFJlc3RhdXJhbnQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZXN0YXVyYW50KCkge1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBSZXN0YXVyYW50O1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgTW9kZWxzLlJlc3RhdXJhbnQgPSBSZXN0YXVyYW50O1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gRGluaW5nLk1vZGVscyB8fCAoRGluaW5nLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0XzEpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIExpZnQoKSB7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdC5wcm90b3R5cGUuc2VyaWFsaXplID0gZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGlmdElkID0gZGF0YS5saWZ0SWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hbWUgPSBkYXRhLm5hbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJhdGluZyA9IGRhdGEucmF0aW5nO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGF0dXMgPSBkYXRhLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGF0aXR1ZGUgPSBkYXRhLmxhdGl0dWRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb25naXR1ZGUgPSBkYXRhLmxvbmdpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RheUF3YXkgPSBkYXRhLnN0YXlBd2F5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53YWl0aW5nVGltZSA9IGRhdGEud2FpdGluZ1RpbWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNsb3NlZFJlYXNvbiA9IGRhdGEuY2xvc2VkUmVhc29uO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnQucHJvdG90eXBlLmRlc2VyaWFsaXplID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsaWZ0SWQ6IHRoaXMubGlmdElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6IHRoaXMubmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByYXRpbmc6IHRoaXMucmF0aW5nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1czogdGhpcy5zdGF0dXMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGF0aXR1ZGU6IHRoaXMubGF0aXR1ZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9uZ2l0dWRlOiB0aGlzLmxvbmdpdHVkZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF5QXdheTogdGhpcy5zdGF5QXdheSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3YWl0aW5nVGltZTogdGhpcy53YWl0aW5nVGltZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbG9zZWRSZWFzb246IHRoaXMuY2xvc2VkUmVhc29uXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTGlmdDtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIE1vZGVscy5MaWZ0ID0gTGlmdDtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IExpZnRfMS5Nb2RlbHMgfHwgKExpZnRfMS5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoTGlmdFJhdGluZykge1xuICAgICAgICAgICAgICAgICAgICBMaWZ0UmF0aW5nW0xpZnRSYXRpbmdbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFJhdGluZ1tMaWZ0UmF0aW5nW1wiQmVnaW5uZXJcIl0gPSAxXSA9IFwiQmVnaW5uZXJcIjtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFJhdGluZ1tMaWZ0UmF0aW5nW1wiSW50ZXJtZWRpYXRlXCJdID0gMl0gPSBcIkludGVybWVkaWF0ZVwiO1xuICAgICAgICAgICAgICAgICAgICBMaWZ0UmF0aW5nW0xpZnRSYXRpbmdbXCJBZHZhbmNlZFwiXSA9IDNdID0gXCJBZHZhbmNlZFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5MaWZ0UmF0aW5nIHx8IChNb2RlbHMuTGlmdFJhdGluZyA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIExpZnRSYXRpbmcgPSBNb2RlbHMuTGlmdFJhdGluZztcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IExpZnQuTW9kZWxzIHx8IChMaWZ0Lk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChMaWZ0U3RhdHVzKSB7XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNbTGlmdFN0YXR1c1tcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzW0xpZnRTdGF0dXNbXCJPcGVuXCJdID0gMV0gPSBcIk9wZW5cIjtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c1tMaWZ0U3RhdHVzW1wiQ2xvc2VkXCJdID0gMl0gPSBcIkNsb3NlZFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5MaWZ0U3RhdHVzIHx8IChNb2RlbHMuTGlmdFN0YXR1cyA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIExpZnRTdGF0dXMgPSBNb2RlbHMuTGlmdFN0YXR1cztcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IExpZnQuTW9kZWxzIHx8IChMaWZ0Lk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gUmVudGFsLk1vZGVscyB8fCAoUmVudGFsLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbF8xKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbCA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlbnRhbCgpIHtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBSZW50YWwucHJvdG90eXBlLnNlcmlhbGl6ZSA9IGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbElkID0gZGF0YS5yZW50YWxJZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXNlckVtYWlsID0gZGF0YS51c2VyRW1haWw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXJ0RGF0ZSA9IG5ldyBEYXRlKGRhdGEuc3RhcnREYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZW5kRGF0ZSA9IG5ldyBEYXRlKGRhdGEuZW5kRGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBpY2t1cEhvdXIgPSBkYXRhLnBpY2t1cEhvdXI7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjdGl2aXR5ID0gZGF0YS5hY3Rpdml0eTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2F0ZWdvcnkgPSBkYXRhLmNhdGVnb3J5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nb2FsID0gZGF0YS5nb2FsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG9lU2l6ZSA9IGRhdGEuc2hvZVNpemU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNraVNpemUgPSBkYXRhLnNraVNpemU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBvbGVTaXplID0gZGF0YS5wb2xlU2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudG90YWxDb3N0ID0gZGF0YS50b3RhbENvc3Q7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsLnByb3RvdHlwZS5kZXNlcmlhbGl6ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVudGFsSWQ6IHRoaXMucmVudGFsSWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlckVtYWlsOiB0aGlzLnVzZXJFbWFpbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFydERhdGU6IHRoaXMuc3RhcnREYXRlLnRvSlNPTigpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuZERhdGU6IHRoaXMuZW5kRGF0ZS50b0pTT04oKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwaWNrdXBIb3VyOiB0aGlzLnBpY2t1cEhvdXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdHk6IHRoaXMuYWN0aXZpdHksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2F0ZWdvcnk6IHRoaXMuY2F0ZWdvcnksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ29hbDogdGhpcy5nb2FsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob2VTaXplOiB0aGlzLnNob2VTaXplLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraVNpemU6IHRoaXMuc2tpU2l6ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb2xlU2l6ZTogdGhpcy5wb2xlU2l6ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3RhbENvc3Q6IHRoaXMudG90YWxDb3N0XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVudGFsO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgTW9kZWxzLlJlbnRhbCA9IFJlbnRhbDtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IFJlbnRhbF8xLk1vZGVscyB8fCAoUmVudGFsXzEuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChSZW50YWxBY3Rpdml0eSkge1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxBY3Rpdml0eVtSZW50YWxBY3Rpdml0eVtcIlNraVwiXSA9IDBdID0gXCJTa2lcIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQWN0aXZpdHlbUmVudGFsQWN0aXZpdHlbXCJTbm93Ym9hcmRcIl0gPSAxXSA9IFwiU25vd2JvYXJkXCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLlJlbnRhbEFjdGl2aXR5IHx8IChNb2RlbHMuUmVudGFsQWN0aXZpdHkgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxBY3Rpdml0eSA9IE1vZGVscy5SZW50YWxBY3Rpdml0eTtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IFJlbnRhbC5Nb2RlbHMgfHwgKFJlbnRhbC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbENhdGVnb3J5KSB7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbENhdGVnb3J5W1JlbnRhbENhdGVnb3J5W1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbENhdGVnb3J5W1JlbnRhbENhdGVnb3J5W1wiQmVnaW5uZXJcIl0gPSAxXSA9IFwiQmVnaW5uZXJcIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQ2F0ZWdvcnlbUmVudGFsQ2F0ZWdvcnlbXCJJbnRlcm1lZGlhdGVcIl0gPSAyXSA9IFwiSW50ZXJtZWRpYXRlXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbENhdGVnb3J5W1JlbnRhbENhdGVnb3J5W1wiQWR2YW5jZWRcIl0gPSAzXSA9IFwiQWR2YW5jZWRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuUmVudGFsQ2F0ZWdvcnkgfHwgKE1vZGVscy5SZW50YWxDYXRlZ29yeSA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbENhdGVnb3J5ID0gTW9kZWxzLlJlbnRhbENhdGVnb3J5O1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gUmVudGFsLk1vZGVscyB8fCAoUmVudGFsLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoUmVudGFsR29hbCkge1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxHb2FsW1JlbnRhbEdvYWxbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsR29hbFtSZW50YWxHb2FsW1wiRGVtb1wiXSA9IDFdID0gXCJEZW1vXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEdvYWxbUmVudGFsR29hbFtcIlBlcmZvcm1hbmNlXCJdID0gMl0gPSBcIlBlcmZvcm1hbmNlXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEdvYWxbUmVudGFsR29hbFtcIlNwb3J0XCJdID0gM10gPSBcIlNwb3J0XCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLlJlbnRhbEdvYWwgfHwgKE1vZGVscy5SZW50YWxHb2FsID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsR29hbCA9IE1vZGVscy5SZW50YWxHb2FsO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gUmVudGFsLk1vZGVscyB8fCAoUmVudGFsLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTG9naW5Db250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTG9naW5Db250cm9sbGVyKGF1dGhTZXJ2aWNlLCAkaW9uaWNIaXN0b3J5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhTZXJ2aWNlID0gYXV0aFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkgPSAkaW9uaWNIaXN0b3J5O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2dpbkRhdGEgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JvbmdQYXNzd29yZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTG9naW5Db250cm9sbGVyLnByb3RvdHlwZS5sb2dpbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cm9uZ1Bhc3N3b3JkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5sb2dpbkZvcm0uJHZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoU2VydmljZS5sb2dpbih0aGlzLmxvZ2luRGF0YS51c2VybmFtZSwgdGhpcy5sb2dpbkRhdGEucGFzc3dvcmQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGlvbmljSGlzdG9yeS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy53cm9uZ1Bhc3N3b3JkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExvZ2luQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdMb2dpbkNvbnRyb2xsZXInLCBMb2dpbkNvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBBdXRoLkNvbnRyb2xsZXJzIHx8IChBdXRoLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBBdXRoSW1hZ2VTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gQXV0aEltYWdlU2VydmljZSgkcSwgYXV0aEFQSSwgY3VycmVudFVzZXJTZXJ2aWNlLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhBUEkgPSBhdXRoQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlclNlcnZpY2UgPSBjdXJyZW50VXNlclNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEF1dGhJbWFnZVNlcnZpY2UucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInVzZXJzL3Bob3RvL1wiICsgaWQ7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBdXRoSW1hZ2VTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQXV0aEltYWdlU2VydmljZSA9IEF1dGhJbWFnZVNlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2F1dGhJbWFnZVNlcnZpY2UnLCBBdXRoSW1hZ2VTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQXV0aEFQSSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEF1dGhBUEkoJGh0dHAsIGNvbmZpZ1NlcnZpY2UsICRodHRwUGFyYW1TZXJpYWxpemVySlFMaWtlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cFBhcmFtU2VyaWFsaXplckpRTGlrZSA9ICRodHRwUGFyYW1TZXJpYWxpemVySlFMaWtlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEF1dGhBUEkucHJvdG90eXBlLmxvZ2luID0gZnVuY3Rpb24gKHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIFwiY29ubmVjdC90b2tlblwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IHRoaXMuJGh0dHBQYXJhbVNlcmlhbGl6ZXJKUUxpa2Uoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBncmFudF90eXBlOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQXV0aGVudGljYXRpb24uR3JhbnRUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGllbnRfaWQ6IHRoaXMuY29uZmlnU2VydmljZS5BdXRoZW50aWNhdGlvbi5DbGllbnRJRCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50X3NlY3JldDogdGhpcy5jb25maWdTZXJ2aWNlLkF1dGhlbnRpY2F0aW9uLkNsaWVudFNlY3JldCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHRoaXMuY29uZmlnU2VydmljZS5BdXRoZW50aWNhdGlvbi5TY29wZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcm5hbWU6IHVzZXJuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogcGFzc3dvcmRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEF1dGhBUEk7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5BdXRoQVBJID0gQXV0aEFQSTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnYXV0aEFQSScsIEF1dGhBUEkpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBBdXRoLlNlcnZpY2VzIHx8IChBdXRoLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBBdXRoU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEF1dGhTZXJ2aWNlKCRxLCBhdXRoQVBJLCBjdXJyZW50VXNlclNlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXV0aEFQSSA9IGF1dGhBUEk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyU2VydmljZSA9IGN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBBdXRoU2VydmljZS5wcm90b3R5cGUubG9naW4gPSBmdW5jdGlvbiAodXNlcm5hbWUsIHBhc3N3b3JkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmF1dGhBUEkubG9naW4odXNlcm5hbWUsIHBhc3N3b3JkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY3VycmVudFVzZXJTZXJ2aWNlLmFjY2Vzc1Rva2VuID0gcmVzcG9uc2UuZGF0YS5hY2Nlc3NfdG9rZW47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5jdXJyZW50VXNlclNlcnZpY2UuZ2V0SW5mbygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KGVycm9yLmRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBdXRoU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkF1dGhTZXJ2aWNlID0gQXV0aFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2F1dGhTZXJ2aWNlJywgQXV0aFNlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBBdXRoLlNlcnZpY2VzIHx8IChBdXRoLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQXV0aDtcbiAgICAgICAgKGZ1bmN0aW9uIChBdXRoKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBDVVJSRU5UX1VTRVJfU1RPUkFHRV9LRVkgPSAnX2N1cnJlbnRVc2VyRGF0YSc7XG4gICAgICAgICAgICAgICAgdmFyIEN1cnJlbnRVc2VyU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEN1cnJlbnRVc2VyU2VydmljZSgkcSwgJHJvb3RTY29wZSwgJGh0dHAsIGNvbmZpZ1NlcnZpY2UsICRsb2cpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHJvb3RTY29wZSA9ICRyb290U2NvcGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nID0gJGxvZztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlciA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZXRJbmZvKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudFVzZXJTZXJ2aWNlLnByb3RvdHlwZS5zYXZlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSBzYXZpbmcgdG8gTG9jYWxTdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgY3VycmVudFVzZXJDb3B5ID0gYW5ndWxhci5jb3B5KHRoaXMuY3VycmVudFVzZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudFVzZXJDb3B5LnBob3RvID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKENVUlJFTlRfVVNFUl9TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjY2Vzc1Rva2VuOiB0aGlzLmFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyOiBjdXJyZW50VXNlckNvcHlcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIFN1Y2Nlc3NmdWxseSBzYXZlZCcpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBDdXJyZW50VXNlclNlcnZpY2UucHJvdG90eXBlLmxvYWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRsb2cuaW5mbygnQ3VycmVudFVzZXJTZXJ2aWNlIGxvYWRpbmcgZnJvbSBMb2NhbFN0b3JhZ2UnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZWRSYXdEYXRhID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oQ1VSUkVOVF9VU0VSX1NUT1JBR0VfS0VZKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzdG9yZWRSYXdEYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0b3JlZERhdGEgPSBKU09OLnBhcnNlKHN0b3JlZFJhd0RhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBzdG9yZWREYXRhLmFjY2Vzc1Rva2VuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSBzdG9yZWREYXRhLmN1cnJlbnRVc2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHJvb3RTY29wZS5jdXJyZW50VXNlciA9IHRoaXMuY3VycmVudFVzZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJy0gU3VjY2Vzc2Z1bGx5IGxvYWRlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJy0gTG9jYWxTdG9yYWdlIGlzIGVtcHR5Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIEN1cnJlbnRVc2VyU2VydmljZS5wcm90b3R5cGUucmVzZXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRsb2cuaW5mbygnQ3VycmVudFVzZXJTZXJ2aWNlIHJlc2V0dGluZyBMb2NhbFN0b3JhZ2UnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWNjZXNzVG9rZW4gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlciA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRyb290U2NvcGUuY3VycmVudFVzZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oQ1VSUkVOVF9VU0VSX1NUT1JBR0VfS0VZLCBKU09OLnN0cmluZ2lmeSh7fSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJy0gRG9uZScpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBDdXJyZW50VXNlclNlcnZpY2UucHJvdG90eXBlLmdldEluZm8gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSBnZXR0aW5nIGluZm9ybWF0aW9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInVzZXJzL3VzZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiBcIkJlYXJlciBcIiArIHRoaXMuYWNjZXNzVG9rZW5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kbG9nLmluZm8oJy0gSW5mb3JtYXRpb24gZ2V0dGVkIHN1Y2Nlc3NmdWxseScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmN1cnJlbnRVc2VyID0gcmVzcG9uc2UuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kcm9vdFNjb3BlLmN1cnJlbnRVc2VyID0gX3RoaXMuY3VycmVudFVzZXI7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2F2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy53YXJuKCctIFNvbWV0aGluZyB3ZW50IHdyb25nIHdoaWxlIGdldHRpbmcgaW5mb3JtYXRpb24nKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQ3VycmVudFVzZXJTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQ3VycmVudFVzZXJTZXJ2aWNlID0gQ3VycmVudFVzZXJTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdjdXJyZW50VXNlclNlcnZpY2UnLCBDdXJyZW50VXNlclNlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBBdXRoLlNlcnZpY2VzIHx8IChBdXRoLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBNZW51Q29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIE1lbnVDb250cm9sbGVyKCRpb25pY1NpZGVNZW51RGVsZWdhdGUsICRzdGF0ZSwgY3VycmVudFVzZXJTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY1NpZGVNZW51RGVsZWdhdGUgPSAkaW9uaWNTaWRlTWVudURlbGVnYXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUgPSAkc3RhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyU2VydmljZSA9IGN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBNZW51Q29udHJvbGxlci5wcm90b3R5cGUubmF2aWdhdGVUbyA9IGZ1bmN0aW9uICh0b1N0YXRlTmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUuZ28odG9TdGF0ZU5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNTaWRlTWVudURlbGVnYXRlLnRvZ2dsZVJpZ2h0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTWVudUNvbnRyb2xsZXIucHJvdG90eXBlLmxvZ291dCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXJTZXJ2aWNlLnJlc2V0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY1NpZGVNZW51RGVsZWdhdGUudG9nZ2xlUmlnaHQoZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTWVudUNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignTWVudUNvbnRyb2xsZXInLCBNZW51Q29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IENvcmUuQ29udHJvbGxlcnMgfHwgKENvcmUuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFdlYXRoZXIgPSBDb3JlLk1vZGVscy5XZWF0aGVyO1xuICAgICAgICAgICAgICAgIHZhciBTdW1tYXJ5SW5mb0NvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBTdW1tYXJ5SW5mb0NvbnRyb2xsZXIoc3VtbWFyeUluZm9BUEksICRzdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3VtbWFyeUluZm9BUEkgPSBzdW1tYXJ5SW5mb0FQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlID0gJHN0YXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgc3VtbWFyeUluZm9BUEkuZ2V0KCkudGhlbihmdW5jdGlvbiAoc3VtbWFyeUluZm8pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5zdW1tYXJ5SW5mbyA9IHN1bW1hcnlJbmZvO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgU3VtbWFyeUluZm9Db250cm9sbGVyLnByb3RvdHlwZS5nZXRXZWF0aGVyID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gV2VhdGhlcltpZF07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdW1tYXJ5SW5mb0NvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignU3VtbWFyeUluZm9Db250cm9sbGVyJywgU3VtbWFyeUluZm9Db250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gQ29yZS5Db250cm9sbGVycyB8fCAoQ29yZS5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdmF0YXJEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHNldEJhY2tncm91bmRJbWFnZShlbGVtZW50LCB1cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignc3R5bGUnLCAnYmFja2dyb3VuZC1pbWFnZTogdXJsKFxcJycgKyB1cmwgKyAnXFwnKTsnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBsaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdza2ktYXZhdGFyJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyLiRvYnNlcnZlKCdza2lBdmF0YXInLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QmFja2dyb3VuZEltYWdlKGVsZW1lbnQsIGF0dHIuc2tpQXZhdGFyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5rOiBsaW5rXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraUF2YXRhcicsIEF2YXRhckRpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgdmFyIE5hdkJhckNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBOYXZCYXJDb250cm9sbGVyKG5hdmlnYXRpb25TZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlID0gbmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTmF2QmFyQ29udHJvbGxlci5wcm90b3R5cGUuZ29Ib21lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5nb0hvbWUoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmF2QmFyQ29udHJvbGxlci5wcm90b3R5cGUuZ29CYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5hdkJhckNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBOYXZCYXJEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvZ29CaWc6ICc9JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW1idXJndWVyOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFjazogJz0nXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9uYXYtYmFyLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogTmF2QmFyQ29udHJvbGxlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lOYXZCYXInLCBOYXZCYXJEaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgRGlyZWN0aXZlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRGlyZWN0aXZlcykge1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJhdGluZ0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRlZmF1bHRDbGFzc2VzID0gJ2ljb24gJztcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gbGluayhzY29wZSwgZWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzY29wZS52YWx1ZTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hcHBlbmQoYW5ndWxhci5lbGVtZW50KFwiPHNwYW4gY2xhc3M9XFxcIlwiICsgZGVmYXVsdENsYXNzZXMgKyBzY29wZS5jbGFzc09uICsgXCJcXFwiLz5cIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IHNjb3BlLnZhbHVlOyBqIDwgc2NvcGUubWF4OyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZChhbmd1bGFyLmVsZW1lbnQoXCI8c3BhbiBjbGFzcz1cXFwiXCIgKyBkZWZhdWx0Q2xhc3NlcyArIHNjb3BlLmNsYXNzT2ZmICsgXCJcXFwiLz5cIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4OiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NPbjogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzT2ZmOiAnQCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5rOiBsaW5rXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVJhdGluZycsIFJhdGluZ0RpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICB2YXIgU2VsZWN0Q29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNlbGVjdENvbnRyb2xsZXIoJHNjb3BlLCAkZWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUgPSAkc2NvcGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRlbGVtZW50ID0gJGVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNsYXNzZXMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kYWxPcGVuZWQ6ICdza2ktc2VsZWN0LW1vZGFsLS1vcGVuZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RvcnMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kYWw6ICcuc2tpLXNlbGVjdC1tb2RhbCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0Q29udHJvbGxlci5wcm90b3R5cGUuc2hvd01vZGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuJHNjb3BlLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kZWxlbWVudC5maW5kKHRoaXMuc2VsZWN0b3JzLm1vZGFsKS5hZGRDbGFzcyh0aGlzLmNsYXNzZXMubW9kYWxPcGVuZWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS5jbG9zZU1vZGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kZWxlbWVudC5maW5kKHRoaXMuc2VsZWN0b3JzLm1vZGFsKS5yZW1vdmVDbGFzcyh0aGlzLmNsYXNzZXMubW9kYWxPcGVuZWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS51cGRhdGVTZWxlY3Rpb24gPSBmdW5jdGlvbiAob3B0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5tb2RlbCA9IG9wdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VNb2RhbCgpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS5yZXNldFNlbGVjdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLiRzY29wZS5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlU2VsZWN0aW9uKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFNlbGVjdENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTZWxlY3REaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyOiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0T3B0aW9uczogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFzVGFiczogJ0AnXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9zZWxlY3QudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiBTZWxlY3RDb250cm9sbGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVNlbGVjdCcsIFNlbGVjdERpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTdW1tYXJ5SW5mb0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2NvcmUvdGVtcGxhdGVzL3N1bW1hcnktaW5mby50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdTdW1tYXJ5SW5mb0NvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVN1bW1hcnlJbmZvJywgU3VtbWFyeUluZm9EaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIEZpbHRlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKEZpbHRlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmFuZ2UoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaW5wdXQsIF9taW4sIF9tYXgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW4gPSBwYXJzZUludChfbWluLCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWF4ID0gcGFyc2VJbnQoX21heCwgMTApO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IG1pbjsgaSA8IG1heDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXQucHVzaChpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpbnB1dDtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKCdza2lSYW5nZScsIFJhbmdlKTtcbiAgICAgICAgICAgIH0pKEZpbHRlcnMgPSBSZW50YWwuRmlsdGVycyB8fCAoUmVudGFsLkZpbHRlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIENvbmZpZ1NlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBDb25maWdTZXJ2aWNlKCRsb2cpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuR2VuZXJhbCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBGYWtlR2VvbG9jYXRpb246IHRydWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR2VvbG9jYXRpb246IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGF0aXR1ZGU6IDQwLjcyMjg0NixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9uZ2l0dWRlOiAtNzQuMDA3MzI1XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQVBJID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFVSTDogJy8nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBhdGg6ICdhcGkvJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQXV0aGVudGljYXRpb24gPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgR3JhbnRUeXBlOiAncGFzc3dvcmQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIENsaWVudElEOiAnU2t5UmVzb3J0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGllbnRTZWNyZXQ6ICdzZWNyZXQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNjb3BlOiAnYXBpJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRsb2cuaW5mbygnQ29uZmlnU2VydmljZSBpbml0aWFsaXplZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlvbmljLlBsYXRmb3JtLmlzV2ViVmlldygpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJGxvZy5pbmZvKCcgLSBXZWJWaWV3IGRldGVjdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5BUEkuVVJMID0gJ2h0dHA6Ly9hZHZlbnR1cmV3b3Jrc2tpcmVzb3J0LmF6dXJld2Vic2l0ZXMubmV0Lyc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkbG9nLmluZm8oJy0gQnJvd3NlciBkZXRlY3RlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBDb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQ29uZmlnU2VydmljZSA9IENvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2NvbmZpZ1NlcnZpY2UnLCBDb25maWdTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQ29yZS5TZXJ2aWNlcyB8fCAoQ29yZS5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUEkxODAgPSAwLjAxNzQ1MzI5MjUxOTk0MzI5NTsgLy8gKE1hdGguUEkvMTgwKVxuICAgICAgICAgICAgICAgIHZhciBHZW9TZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gR2VvU2VydmljZSgkcSwgY29uZmlnU2VydmljZSwgJGxvZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZyA9ICRsb2c7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgR2VvU2VydmljZS5wcm90b3R5cGUuZ2VvbG9jYXRpb25BcGlBdmFpbGFibGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKG5hdmlnYXRvci5nZW9sb2NhdGlvbiAmJiBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uZ2V0Q3VycmVudFBvc2l0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgR2VvU2VydmljZS5wcm90b3R5cGUuZ2V0UG9zaXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRsb2cuaW5mbygnR2VvbG9jYXRpb24gcmVxdWVzdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF90aGlzLmNvbmZpZ1NlcnZpY2UuR2VuZXJhbC5GYWtlR2VvbG9jYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy5pbmZvKCctIFJldHVybmluZyBmYWtlIGdlb2xvY2F0aW9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoX3RoaXMuY29uZmlnU2VydmljZS5HZW5lcmFsLkdlb2xvY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3RoaXMuZ2VvbG9jYXRpb25BcGlBdmFpbGFibGUoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uZ2V0Q3VycmVudFBvc2l0aW9uKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiByZXN1bHQuY29vcmRzLmxhdGl0dWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvbmdpdHVkZTogcmVzdWx0LmNvb3Jkcy5sb25naXR1ZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kbG9nLndhcm4oJy0gR2VvbG9jYXRpb24gQVBJIG5vdCBhdmFpbGFibGUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIEdlb1NlcnZpY2UucHJvdG90eXBlLmdldERpc3RhbmNlQmV0d2VlbiA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcCA9IFBJMTgwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGMgPSBNYXRoLmNvcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByID0gMC41IC0gYygoYS5sYXRpdHVkZSAtIGIubGF0aXR1ZGUpICogcCkgLyAyICsgYyhiLmxhdGl0dWRlICogcCkgKlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGMoYS5sYXRpdHVkZSAqIHApICogKDEgLSBjKChhLmxvbmdpdHVkZSAtIGIubG9uZ2l0dWRlKSAqIHApKSAvIDI7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gKDEyNzQyICogTWF0aC5hc2luKE1hdGguc3FydChyKSkgKiAwLjYyMTM3MSk7IC8vIDIgKiBSOyBSID0gNjM3MSBrbVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE1hdGgucm91bmQocmVzdWx0ICogMWUyKSAvIDFlMjtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5HZW9TZXJ2aWNlID0gR2VvU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnZ2VvU2VydmljZScsIEdlb1NlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBDb3JlLlNlcnZpY2VzIHx8IChDb3JlLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBOYXZpZ2F0aW9uU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIE5hdmlnYXRpb25TZXJ2aWNlKCRzdGF0ZSwgJGlvbmljSGlzdG9yeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUgPSAkc3RhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkgPSAkaW9uaWNIaXN0b3J5O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0hvbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkubmV4dFZpZXdPcHRpb25zKHsgZGlzYWJsZUJhY2s6IHRydWUsIGhpc3RvcnlSb290OiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUuZ28oJ2FwcC5ob21lJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0JhY2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW9uaWMuUGxhdGZvcm1bJ2lzJ10oJ2Jyb3dzZXInKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGlvbmljSGlzdG9yeS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTmF2aWdhdGlvblNlcnZpY2UgPSBOYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnbmF2aWdhdGlvblNlcnZpY2UnLCBOYXZpZ2F0aW9uU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IENvcmUuU2VydmljZXMgfHwgKENvcmUuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFN1bW1hcnlJbmZvQVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm9BUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFN1bW1hcnlJbmZvQVBJLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInN1bW1hcmllc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3VtbWFyeUluZm9BUEk7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5TdW1tYXJ5SW5mb0FQSSA9IFN1bW1hcnlJbmZvQVBJO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdzdW1tYXJ5SW5mb0FQSScsIFN1bW1hcnlJbmZvQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQ29yZS5TZXJ2aWNlcyB8fCAoQ29yZS5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExldmVsT2ZOb2lzZSA9IERpbmluZy5Nb2RlbHMuTGV2ZWxPZk5vaXNlO1xuICAgICAgICAgICAgICAgIHZhciBEaW5pbmdEZXRhaWxDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gRGluaW5nRGV0YWlsQ29udHJvbGxlcigkc3RhdGVQYXJhbXMsIGRpbmluZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZVBhcmFtcyA9ICRzdGF0ZVBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZSA9IGRpbmluZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlY29tbWVuZGF0aW9ucyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlkID0gJHN0YXRlUGFyYW1zWydpZCddO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEkc3RhdGVQYXJhbXNbJ3Jlc3RhdXJhbnQnXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZS5nZXRTaW5nbGUoaWQpLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVzdGF1cmFudCA9IHJlc3RhdXJhbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdldEV4dHJhSW5mb3JtYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVzdGF1cmFudCA9ICRzdGF0ZVBhcmFtc1sncmVzdGF1cmFudCddO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0RXh0cmFJbmZvcm1hdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldEV4dHJhSW5mb3JtYXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaW5pbmdTZXJ2aWNlLmdldFJlY29tbWVuZGF0aW9ucyh0aGlzLnJlc3RhdXJhbnQucmVzdGF1cmFudElkLnRvU3RyaW5nKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVjb21tZW5kYXRpb25zID0gcmVzdGF1cmFudHM7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldEltYWdlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kaW5pbmdTZXJ2aWNlLmdldEltYWdlKGlkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nRGV0YWlsQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0TGV2ZWxPZk5vaXNlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gTGV2ZWxPZk5vaXNlW2lkXTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIERpbmluZ0RldGFpbENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdEaW5pbmdEZXRhaWxDb250cm9sbGVyJywgRGluaW5nRGV0YWlsQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IERpbmluZy5Db250cm9sbGVycyB8fCAoRGluaW5nLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGV2ZWxPZk5vaXNlID0gRGluaW5nLk1vZGVscy5MZXZlbE9mTm9pc2U7XG4gICAgICAgICAgICAgICAgdmFyIERpbmluZ0NvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBEaW5pbmdDb250cm9sbGVyKGRpbmluZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZSA9IGRpbmluZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldFJlc3RhdXJhbnRzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZpbGxGaWx0ZXJzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9yZGVyQnkgPSAnJztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBEaW5pbmdDb250cm9sbGVyLnByb3RvdHlwZS5nZXRSZXN0YXVyYW50cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaW5pbmdTZXJ2aWNlLmdldE5lYXIoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN0YXVyYW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlc3RhdXJhbnRzID0gcmVzdGF1cmFudHM7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQ29udHJvbGxlci5wcm90b3R5cGUuZmlsbEZpbHRlcnMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmZpbHRlcnMgPSB0aGlzLmRpbmluZ1NlcnZpY2UuZ2V0RmlsdGVycygpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdDb250cm9sbGVyLnByb3RvdHlwZS5nZXRJbWFnZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGluaW5nU2VydmljZS5nZXRJbWFnZShpZCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0NvbnRyb2xsZXIucHJvdG90eXBlLmdldExldmVsT2ZOb2lzZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExldmVsT2ZOb2lzZVtpZF07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBEaW5pbmdDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5kaW5pbmcnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignRGluaW5nQ29udHJvbGxlcicsIERpbmluZ0NvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBEaW5pbmcuQ29udHJvbGxlcnMgfHwgKERpbmluZy5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIERpbmluZ0FQSSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIERpbmluZ0FQSSgkcSwgJGh0dHAsIGNvbmZpZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGh0dHAgPSAkaHR0cDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU2VydmljZSA9IGNvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQVBJLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlc3RhdXJhbnRzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpLnRoZW4oZnVuY3Rpb24gKHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cy5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0FQSS5wcm90b3R5cGUuZ2V0TmVhciA9IGZ1bmN0aW9uIChsYXRpdHVkZSwgbG9uZ2l0dWRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICgodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZXN0YXVyYW50cy9uZWFyYnlcIikgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoXCI/bGF0aXR1ZGU9XCIgKyBsYXRpdHVkZSkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoXCImbG9uZ2l0dWRlPVwiICsgbG9uZ2l0dWRlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCkudGhlbihmdW5jdGlvbiAocmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQVBJLnByb3RvdHlwZS5nZXRSZWNvbW1lbmRhdGlvbnMgPSBmdW5jdGlvbiAoc2VhcmNodGV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZXN0YXVyYW50cy9yZWNvbW1lbmRhdGlvbnMvXCIgKyBzZWFyY2h0ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdBUEkucHJvdG90eXBlLmdldFNpbmdsZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZXN0YXVyYW50cy9cIiArIGlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdBUEkucHJvdG90eXBlLmdldEltYWdlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVzdGF1cmFudHMvcGhvdG8vXCIgKyBpZDtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIERpbmluZ0FQSTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkRpbmluZ0FQSSA9IERpbmluZ0FQSTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdkaW5pbmdBUEknLCBEaW5pbmdBUEkpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBEaW5pbmcuU2VydmljZXMgfHwgKERpbmluZy5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIERpbmluZ1NlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBEaW5pbmdTZXJ2aWNlKCRxLCBkaW5pbmdBUEksIGdlb1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nQVBJID0gZGluaW5nQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZW9TZXJ2aWNlID0gZ2VvU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGF0aXR1ZGUgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb25naXR1ZGUgPSAwO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldERpc3RhbmNlID0gZnVuY3Rpb24gKGxhdGl0dWRlLCBsb25naXR1ZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmdlb1NlcnZpY2UuZ2V0RGlzdGFuY2VCZXR3ZWVuKHsgbGF0aXR1ZGU6IGxhdGl0dWRlLCBsb25naXR1ZGU6IGxvbmdpdHVkZSB9LCB7IGxhdGl0dWRlOiB0aGlzLmxhdGl0dWRlLCBsb25naXR1ZGU6IHRoaXMubG9uZ2l0dWRlIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5jYWxjdWxhdGVEaXN0YW5jZXMgPSBmdW5jdGlvbiAocmVzdGF1cmFudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0gcmVzdGF1cmFudHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdGF1cmFudHNbaV0uZGlzdGFuY2UgPSB0aGlzLmdldERpc3RhbmNlKHJlc3RhdXJhbnRzW2ldLmxhdGl0dWRlLCByZXN0YXVyYW50c1tpXS5sb25naXR1ZGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3RhdXJhbnRzO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kaW5pbmdBUEkuZ2V0QWxsKCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldE5lYXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuZ2VvU2VydmljZS5nZXRQb3NpdGlvbigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGF0aXR1ZGUgPSByZXN1bHQubGF0aXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvbmdpdHVkZSA9IHJlc3VsdC5sb25naXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5kaW5pbmdBUEkuZ2V0TmVhcihfdGhpcy5sYXRpdHVkZSwgX3RoaXMubG9uZ2l0dWRlKS50aGVuKGZ1bmN0aW9uIChyZXN0YXVyYW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoX3RoaXMuY2FsY3VsYXRlRGlzdGFuY2VzKHJlc3RhdXJhbnRzKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldFJlY29tbWVuZGF0aW9ucyA9IGZ1bmN0aW9uIChfc2VhcmNodGV4dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzZWFyY2h0ZXh0U3BsaXR0ZWQgPSBfc2VhcmNodGV4dC5zcGxpdCgnICcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNlYXJjaHRleHQgPSBzZWFyY2h0ZXh0U3BsaXR0ZWRbc2VhcmNodGV4dFNwbGl0dGVkLmxlbmd0aCAtIDFdO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuZGluaW5nQVBJLmdldFJlY29tbWVuZGF0aW9ucyhzZWFyY2h0ZXh0KS50aGVuKGZ1bmN0aW9uIChpZHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3RhdXJhbnRzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcm9taXNlcyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMCwgbCA9IGlkcy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHByb21pc2VzLnB1c2goKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuZ2V0U2luZ2xlKGlkc1tpXSkudGhlbihmdW5jdGlvbiAocmVzdGF1cmFudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN0YXVyYW50cy5wdXNoKHJlc3RhdXJhbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJHEuYWxsKHByb21pc2VzKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzdGF1cmFudHMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXRTaW5nbGUgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRpbmluZ0FQSS5nZXRTaW5nbGUoaWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXRGaWx0ZXJzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnLXJhdGluZycsIGxhYmVsOiAnUmF0aW5nJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdsZXZlbE9mTm9pc2UnLCBsYWJlbDogJ0xldmVsIE5vaXNlJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdwcmljZUxldmVsJywgbGFiZWw6ICdQcmljZScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnZGlzdGFuY2UnLCBsYWJlbDogJ01pbGVzIEF3YXknIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJy1mYW1pbHlGcmllbmRseScsIGxhYmVsOiAnRmFtaWx5IEZyaWVuZGx5JyB9XG4gICAgICAgICAgICAgICAgICAgICAgICBdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdTZXJ2aWNlLnByb3RvdHlwZS5nZXRJbWFnZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGluaW5nQVBJLmdldEltYWdlKGlkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIERpbmluZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5EaW5pbmdTZXJ2aWNlID0gRGluaW5nU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdkaW5pbmdTZXJ2aWNlJywgRGluaW5nU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IERpbmluZy5TZXJ2aWNlcyB8fCAoRGluaW5nLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgSG9tZTtcbiAgICAgICAgKGZ1bmN0aW9uIChIb21lKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICB2YXIgSG9tZUNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEhvbWVDb250cm9sbGVyKCRzY29wZSwgYXV0aFNlcnZpY2UsIGF1dGhJbWFnZVNlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUgPSAkc2NvcGU7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuYXV0aFNlcnZpY2UgPSBhdXRoU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoSW1hZ2VTZXJ2aWNlID0gYXV0aEltYWdlU2VydmljZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgSG9tZUNvbnRyb2xsZXIucHJvdG90eXBlLmdldEltYWdlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmF1dGhJbWFnZVNlcnZpY2UuZ2V0KGlkKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHJldHVybiBIb21lQ29udHJvbGxlcjtcbiAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmhvbWUnKVxuICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdIb21lQ29udHJvbGxlcicsIEhvbWVDb250cm9sbGVyKTtcbiAgICAgICAgfSkoSG9tZSA9IEFwcC5Ib21lIHx8IChBcHAuSG9tZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBIb21lO1xuICAgICAgICAoZnVuY3Rpb24gKEhvbWUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gSG9tZU1lbnVEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdob21lL3RlbXBsYXRlcy9ob21lLW1lbnUudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5ob21lJylcbiAgICAgICAgICAgICAgICAgICAgLmRpcmVjdGl2ZSgnc2tpSG9tZU1lbnUnLCBIb21lTWVudURpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gSG9tZS5EaXJlY3RpdmVzIHx8IChIb21lLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShIb21lID0gQXBwLkhvbWUgfHwgKEFwcC5Ib21lID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIobGlmdFNlcnZpY2UsICRzdGF0ZVBhcmFtcywgZ2VvU2VydmljZSwgJHNjb3BlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZSA9IGxpZnRTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGVQYXJhbXMgPSAkc3RhdGVQYXJhbXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb1NlcnZpY2UgPSBnZW9TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUgPSAkc2NvcGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXNlckdlb2xvY2F0aW9uID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGlzdGFuY2UgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZXRMaWZ0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5nZXREaXN0YW5jZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldExpZnQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGlmdFNlcnZpY2UuZ2V0KHRoaXMuJHN0YXRlUGFyYW1zLmxpZnRJZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAobGlmdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxpZnQgPSBsaWZ0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhhbmRsZSBlcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyLnByb3RvdHlwZS5nZXREaXN0YW5jZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy51c2VyR2VvbG9jYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNhbGNEaXN0YW5jZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZW9TZXJ2aWNlLmdldFBvc2l0aW9uKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMudXNlckdlb2xvY2F0aW9uID0gZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY2FsY0Rpc3RhbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyLnByb3RvdHlwZS5jYWxjRGlzdGFuY2UgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5saWZ0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXN0YW5jZSA9IHRoaXMuZ2VvU2VydmljZS5nZXREaXN0YW5jZUJldHdlZW4odGhpcy51c2VyR2VvbG9jYXRpb24sIHsgbGF0aXR1ZGU6IHRoaXMubGlmdC5sYXRpdHVkZSwgbG9uZ2l0dWRlOiB0aGlzLmxpZnQubG9uZ2l0dWRlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXInLCBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IExpZnQuQ29udHJvbGxlcnMgfHwgKExpZnQuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlcihsaWZ0U2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZSA9IGxpZnRTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZXRMaWZ0cygpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlci5wcm90b3R5cGUuZ2V0TGlmdHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGlmdFNlcnZpY2UuZ2V0TmVhcigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5kaWdlc3RMaWZ0cyhkYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXIucHJvdG90eXBlLmRpZ2VzdExpZnRzID0gZnVuY3Rpb24gKGxpZnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5vcGVuTGlmdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VkTGlmdHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpZnRzLmZvckVhY2goZnVuY3Rpb24gKGxpZnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobGlmdC5zdGF0dXMgPT09IExpZnQuTW9kZWxzLkxpZnRTdGF0dXMuT3Blbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5vcGVuTGlmdHMucHVzaChsaWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAobGlmdC5zdGF0dXMgPT09IExpZnQuTW9kZWxzLkxpZnRTdGF0dXMuQ2xvc2VkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmNsb3NlZExpZnRzLnB1c2gobGlmdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyJywgTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gTGlmdC5Db250cm9sbGVycyB8fCAoTGlmdC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdEFQSSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIExpZnRBUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIExpZnRBUEkucHJvdG90eXBlLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKF90aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIF90aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJsaWZ0c1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kaHR0cChyZXF1ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdEFQSS5wcm90b3R5cGUuZ2V0TmVhciA9IGZ1bmN0aW9uIChsYXRpdHVkZSwgbG9uZ2l0dWRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICgoX3RoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgX3RoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcImxpZnRzL25lYXJieVwiKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoXCI/bGF0aXR1ZGU9XCIgKyBsYXRpdHVkZSkgK1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKFwiJmxvbmdpdHVkZT1cIiArIGxvbmdpdHVkZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRodHRwKHJlcXVlc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKHJlc29sdmUsIHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdEFQSS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcImxpZnRzL1wiICsgaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gTGlmdEFQSTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkxpZnRBUEkgPSBMaWZ0QVBJO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdsaWZ0QVBJJywgTGlmdEFQSSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IExpZnQuU2VydmljZXMgfHwgKExpZnQuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExpZnRTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdFNlcnZpY2UoJHEsIGxpZnRBUEksIGdlb1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubGlmdEFQSSA9IGxpZnRBUEk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb1NlcnZpY2UgPSBnZW9TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIExpZnRTZXJ2aWNlLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxpZnRBUEkuZ2V0QWxsKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UuZGF0YS5tYXAoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgTGlmdC5Nb2RlbHMuTGlmdCgpLnNlcmlhbGl6ZShpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTZXJ2aWNlLnByb3RvdHlwZS5nZXROZWFyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5nZW9TZXJ2aWNlLmdldFBvc2l0aW9uKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMubGlmdEFQSS5nZXROZWFyKHJlc3VsdC5sYXRpdHVkZSwgcmVzdWx0LmxvbmdpdHVkZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UuZGF0YS5tYXAoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgTGlmdC5Nb2RlbHMuTGlmdCgpLnNlcmlhbGl6ZShpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTZXJ2aWNlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGlmdEFQSS5nZXQoaWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShuZXcgTGlmdC5Nb2RlbHMuTGlmdCgpLnNlcmlhbGl6ZShyZXN1bHQuZGF0YSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChyZWplY3QpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0U2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkxpZnRTZXJ2aWNlID0gTGlmdFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5saWZ0JylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2xpZnRTZXJ2aWNlJywgTGlmdFNlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBMaWZ0LlNlcnZpY2VzIHx8IChMaWZ0LlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyKCRzY29wZSwgcmVudGFsU2VydmljZSwgcmVudGFsQWN0aXZpdGllcywgcmVudGFsQ2F0ZWdvcmllcywgcmVudGFsR29hbHMsIHNob2VTaXplcywgc2tpU2l6ZXMsIHBvbGVTaXplcywgJHN0YXRlUGFyYW1zLCBwaWNrdXBIb3VycywgbmF2aWdhdGlvblNlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsU2VydmljZSA9IHJlbnRhbFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbEFjdGl2aXRpZXMgPSByZW50YWxBY3Rpdml0aWVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxDYXRlZ29yaWVzID0gcmVudGFsQ2F0ZWdvcmllcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsR29hbHMgPSByZW50YWxHb2FscztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvZVNpemVzID0gc2hvZVNpemVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5za2lTaXplcyA9IHNraVNpemVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wb2xlU2l6ZXMgPSBwb2xlU2l6ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZVBhcmFtcyA9ICRzdGF0ZVBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucGlja3VwSG91cnMgPSBwaWNrdXBIb3VycztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubmF2aWdhdGlvblNlcnZpY2UgPSBuYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5oaWdoRGVtYW5kQWxlcnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIEluaXRpYWxpemUgcmVudGFsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbCA9IG5ldyBSZW50YWwuTW9kZWxzLlJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waWNrdXBIb3Vycy5nZW5lcmF0ZUFsbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSWYgdGhlcmUncyBhIHJlbnRhbElkLCB3ZSdyZSBlZGl0aW5nLCBub3QgY3JlYXRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgkc3RhdGVQYXJhbXMucmVudGFsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldFJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZXNldFJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gU2V0IHRoZSB0b2RheURhdGVkLCB1c2VkIGFzICdtaW4nIHZhbHVlIGZvciBzdGFydERhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS50b2RheURhdGUgPSBuZXcgRGF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZS5zZXRIb3VycygwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS50b2RheURhdGUuc2V0TWludXRlcygwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS50b2RheURhdGUuc2V0U2Vjb25kcygwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnREYXRlIGlzIGVkaXRlZCBpbiB0d28gc2VwYXJhdGVkIGlucHV0cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzbywgaXQgbmVlZHMgdG8gYmUgaW4gcmVwYXJhdGVkIG1vZGVscyBmb3JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlYWNoIG5nLW1vZGVsXG4gICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnN0YXJ0RGF0ZSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXk6IG51bGwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cjogbnVsbFxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8qXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVGhlc2UgdmFsdWVzIChvcHRpb25zIGluIHNlbGVjdG9ycykgYXJlIG1hcHBlZCB0byB0aGUgb3JpZ2luYWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZW50YWwgbW9kZWwgdXNpbmcgJHNjb3BlLiR3YXRjaENvbGxlY3Rpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUucmVudGFsVGVtcCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb2xlU2l6ZTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBza2lTaXplOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVXBkYXRlIHN0YXJ0RGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiR3YXRjaENvbGxlY3Rpb24oJ3N0YXJ0RGF0ZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoISRzY29wZS5zdGFydERhdGUuZGF5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLnN0YXJ0RGF0ZSA9IGFuZ3VsYXIuY29weSgkc2NvcGUuc3RhcnREYXRlLmRheSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCRzY29wZS5zdGFydERhdGUuaG91cikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuc3RhcnREYXRlLnNldEhvdXJzKCRzY29wZS5zdGFydERhdGUuaG91ci5ob3Vycyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbC5zdGFydERhdGUuc2V0TWludXRlcygkc2NvcGUuc3RhcnREYXRlLmhvdXIubWludXRlcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmNoZWNrSGlnaERlbWFuZCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgYWN0aXZpdHksIGNhdGVnb3J5LCBwb2xlU2l6ZSBhbmQgc2tpU2l6ZVxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiR3YXRjaENvbGxlY3Rpb24oJ3JlbnRhbFRlbXAnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLmFjdGl2aXR5ID0gJHNjb3BlLnJlbnRhbFRlbXAuYWN0aXZpdHkgPyAkc2NvcGUucmVudGFsVGVtcC5hY3Rpdml0eS5pZCA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLmNhdGVnb3J5ID0gJHNjb3BlLnJlbnRhbFRlbXAuY2F0ZWdvcnkgPyAkc2NvcGUucmVudGFsVGVtcC5jYXRlZ29yeS5pZCA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLnBvbGVTaXplID0gJHNjb3BlLnJlbnRhbFRlbXAucG9sZVNpemUgPyAkc2NvcGUucmVudGFsVGVtcC5wb2xlU2l6ZS5pZCA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLnNraVNpemUgPSAkc2NvcGUucmVudGFsVGVtcC5za2lTaXplID8gJHNjb3BlLnJlbnRhbFRlbXAuc2tpU2l6ZS5pZCA6IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLmdldFJlbnRhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxTZXJ2aWNlLmdldCh0aGlzLiRzdGF0ZVBhcmFtcy5yZW50YWxJZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsID0gcmVudGFsO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnVwZGF0ZVRlbXBEYXRhKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIC8vIFRoaXMgd2lsbCB1cGRhdGUgYWxsIHRoZSB0ZW1wb3JhbCBkYXRhIHVzZWQgaW4gdGhlIGN1c3RvbSBzZWxlY3RzXG4gICAgICAgICAgICAgICAgICAgIC8vIGJhc2VkIG9uIHRoZSBhY3R1YWwgcmVudGFsIG9iamVjdC5cbiAgICAgICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyBtZXRob2QgaXMgdXNlZCBhdCBzdGFydCB3aGVuIHdlJ3JlIGVkaXRpbmcgYSByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS51cGRhdGVUZW1wRGF0YSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBob3VycyA9IHRoaXMucmVudGFsLnN0YXJ0RGF0ZS5nZXRIb3VycygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1pbnV0ZXMgPSB0aGlzLnJlbnRhbC5zdGFydERhdGUuZ2V0TWludXRlcygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUuc3RhcnREYXRlID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogdGhpcy5yZW50YWwuc3RhcnREYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXI6IHRoaXMucGlja3VwSG91cnMuZ2V0QnlJZCgoaG91cnMgKiA2MCkgKyBtaW51dGVzKVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlLnJlbnRhbFRlbXAgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aXZpdHk6IHRoaXMucmVudGFsQWN0aXZpdGllcy5nZXRCeUlkKHRoaXMucmVudGFsLmFjdGl2aXR5KSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjYXRlZ29yeTogdGhpcy5yZW50YWxDYXRlZ29yaWVzLmdldEJ5SWQodGhpcy5yZW50YWwuY2F0ZWdvcnkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvbGVTaXplOiB0aGlzLnBvbGVTaXplcy5nZXRCeUlkKHRoaXMucmVudGFsLnBvbGVTaXplKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBza2lTaXplOiB0aGlzLnNraVNpemVzLmdldEJ5SWQodGhpcy5yZW50YWwuc2tpU2l6ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIC8vIFRoaXMgd2lsbCBwdXQgdGhlIHJlbnRhbCBhbmQgYWxsIHRoZSB0ZW1wb3JhbCB2YWx1ZXMgZm9yIGN1c3RvbVxuICAgICAgICAgICAgICAgICAgICAvLyBzZWxlY3RzIHRvIG51bGxcbiAgICAgICAgICAgICAgICAgICAgLy9cbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyBtZXRob2QgaXMgdXNlZCBhdCBzdGFydCB3aGVuIHdlJ3JlIGNyZWF0aW5nIGEgcmVudGFsXG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUucmVzZXRSZW50YWwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbCA9IG5ldyBSZW50YWwuTW9kZWxzLlJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSBpbiB0aGlzLiRzY29wZS5zdGFydERhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUuc3RhcnREYXRlLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlLnN0YXJ0RGF0ZVtpXSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgeCBpbiB0aGlzLiRzY29wZS5yZW50YWxUZW1wKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuJHNjb3BlLnJlbnRhbFRlbXAuaGFzT3duUHJvcGVydHkoeCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUucmVudGFsVGVtcFt4XSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLmVtaXRTYXZlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUuJGVtaXQoJ3JlbnRhbF9zYXZlZCcpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLnN1Ym1pdFJlc2VydmF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnJlbnRhbEZvcm0uJHZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWN0aW9uUHJvbWlzZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuJHN0YXRlUGFyYW1zLnJlbnRhbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvblByb21pc2UgPSB0aGlzLnNhdmVSZXNlcnZhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uUHJvbWlzZSA9IHRoaXMuYWRkUmVzZXJ2YXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uUHJvbWlzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5hZGRSZXNlcnZhdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZW50YWxTZXJ2aWNlLmFkZCh0aGlzLnJlbnRhbClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVzZXRSZW50YWwoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWxGb3JtLiRzZXRQcmlzdGluZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEZvcm0uJHNldFVudG91Y2hlZCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmVtaXRTYXZlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5zYXZlUmVzZXJ2YXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVudGFsU2VydmljZS5zYXZlKHRoaXMucmVudGFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLmNoZWNrSGlnaERlbWFuZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbFNlcnZpY2UuY2hlY2tIaWdoRGVtYW5kKHRoaXMucmVudGFsLnN0YXJ0RGF0ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuaGlnaERlbWFuZEFsZXJ0ID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEhhbmRsZSBlcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0Q2FsY3VsYXRlZENvc3QgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbC50b3RhbENvc3QgPSAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucmVudGFsLnN0YXJ0RGF0ZSAmJiB0aGlzLnJlbnRhbC5lbmREYXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWwudG90YWxDb3N0ID0gMjA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGRheXMgPSBNYXRoLmZsb29yKCh0aGlzLnJlbnRhbC5lbmREYXRlLmdldFRpbWUoKSAtIHRoaXMucmVudGFsLnN0YXJ0RGF0ZS5nZXRUaW1lKCkpIC8gMTAwMCAvIDYwIC8gNjAgLyAyNCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWwudG90YWxDb3N0ID0gdGhpcy5yZW50YWwudG90YWxDb3N0ICsgKGRheXMgKiA1KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlbnRhbC50b3RhbENvc3Q7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXInLCBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBSZW50YWwuQ29udHJvbGxlcnMgfHwgKFJlbnRhbC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbHNDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsc0NvbnRyb2xsZXIoJGlvbmljVGFic0RlbGVnYXRlLCAkc2NvcGUsICRzdGF0ZVBhcmFtcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNUYWJzRGVsZWdhdGUgPSAkaW9uaWNUYWJzRGVsZWdhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlUGFyYW1zID0gJHN0YXRlUGFyYW1zO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiRvbigncmVudGFsX3NhdmVkJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRpb25pY1RhYnNEZWxlZ2F0ZS4kZ2V0QnlIYW5kbGUoJ3NlY3Rpb24tdGFicycpLnNlbGVjdCgwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJGJyb2FkY2FzdCgndXBkYXRlX3Jlc2VydmF0aW9uX2xpc3QnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWxzQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIENvbnRyb2xsZXJzLlJlbnRhbHNDb250cm9sbGVyID0gUmVudGFsc0NvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignUmVudGFsc0NvbnRyb2xsZXInLCBSZW50YWxzQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IFJlbnRhbC5Db250cm9sbGVycyB8fCAoUmVudGFsLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXIoJHNjb3BlLCByZW50YWxTZXJ2aWNlLCAkc3RhdGUsICR0aW1lb3V0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUgPSAkc2NvcGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbFNlcnZpY2UgPSByZW50YWxTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUgPSAkc3RhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiR0aW1lb3V0ID0gJHRpbWVvdXQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNob3dNZXNzYWdlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldFJlbnRhbHMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kb24oJ3VwZGF0ZV9yZXNlcnZhdGlvbl9saXN0JywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdldFJlbnRhbHMoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnNob3dNZXNzYWdlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXIucHJvdG90eXBlLmdldFJlbnRhbHMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlbnRhbFNlcnZpY2UuZ2V0QWxsKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbHMgPSBkYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXIucHJvdG90eXBlLm5hdmlnYXRlVG9SZW50YWwgPSBmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW5nUmVudGFsID0gcmVudGFsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kdGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJHN0YXRlLmdvKCdhcHAucmVudGFsLWRldGFpbCcsIHsgcmVudGFsSWQ6IHJlbnRhbC5yZW50YWxJZCB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIDEwMCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBSZXNlcnZhdGlvbkxpc3RDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlcicsIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBSZW50YWwuQ29udHJvbGxlcnMgfHwgKFJlbnRhbC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBGaWx0ZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChGaWx0ZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlbnRhbEFjdGl2aXR5RmlsdGVyKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKGlucHV0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVudGFsLk1vZGVscy5SZW50YWxBY3Rpdml0eVtpbnB1dF07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcignc2tpUmVudGFsQWN0aXZpdHknLCBSZW50YWxBY3Rpdml0eUZpbHRlcik7XG4gICAgICAgICAgICB9KShGaWx0ZXJzID0gUmVudGFsLkZpbHRlcnMgfHwgKFJlbnRhbC5GaWx0ZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIEZpbHRlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKEZpbHRlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsQ2F0ZWdvcnlGaWx0ZXIoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaW5wdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWwuTW9kZWxzLlJlbnRhbENhdGVnb3J5W2lucHV0XTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKCdza2lSZW50YWxDYXRlZ29yeScsIFJlbnRhbENhdGVnb3J5RmlsdGVyKTtcbiAgICAgICAgICAgIH0pKEZpbHRlcnMgPSBSZW50YWwuRmlsdGVycyB8fCAoUmVudGFsLkZpbHRlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBQaWNrdXBIb3VycyA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFBpY2t1cEhvdXJzKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGwgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBQaWNrdXBIb3Vycy5wcm90b3R5cGUuZ2V0QnlJZCA9IGZ1bmN0aW9uIChpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX2hvdXJzID0gTWF0aC5mbG9vcihpIC8gNjApO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF9taW51dGVzID0gaSAtIChfaG91cnMgKiA2MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaG91cnMgPSBfaG91cnM7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWludXRlcyA9IF9taW51dGVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1lciA9ICdhbSc7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaG91cnMgPiAxMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzID0gaG91cnMgLSAxMjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXIgPSAncG0nO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGhvdXJzX3N0ciA9IGhvdXJzLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWludXRlc19zdHIgPSBtaW51dGVzLnRvU3RyaW5nKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaG91cnNfc3RyLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzX3N0ciA9ICcwJyArIGhvdXJzX3N0cjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChtaW51dGVzX3N0ci5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGVzX3N0ciA9ICcwJyArIG1pbnV0ZXNfc3RyO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaG91cnNfc3RyICsgXCI6XCIgKyBtaW51dGVzX3N0ciArIFwiIFwiICsgbWVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhvdXJzOiBfaG91cnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWludXRlczogX21pbnV0ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFBpY2t1cEhvdXJzLnByb3RvdHlwZS5nZW5lcmF0ZUFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW5NaW51dGVzID0gMzYwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1heE1pbnV0ZXMgPSAxMjAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHN0ZXBzID0gMTU7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gbWluTWludXRlczsgaSA8PSBtYXhNaW51dGVzOyBpID0gaSArIHN0ZXBzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godGhpcy5nZXRCeUlkKGkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYWxsID0gcmVzdWx0O1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUGlja3VwSG91cnM7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5QaWNrdXBIb3VycyA9IFBpY2t1cEhvdXJzO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3BpY2t1cEhvdXJzJywgUGlja3VwSG91cnMpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUG9sZVNpemVzKCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAzMjsgaSA8PSA1NzsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGkgKyAnIGluJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QnlJZDogZnVuY3Rpb24gKGlkKSB7IHJldHVybiAoeyBpZDogaWQsIGxhYmVsOiBpZCArICcgaW4nIH0pOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsOiByZXN1bHRcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuUG9sZVNpemVzID0gUG9sZVNpemVzO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3BvbGVTaXplcycsIFBvbGVTaXplcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxBY3Rpdml0aWVzKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QnlJZDogZnVuY3Rpb24gKGlkKSB7IHJldHVybiAoeyBpZDogaWQsIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5W2lkXSB9KTsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbDogT2JqZWN0LmtleXMoUmVudGFsLk1vZGVscy5SZW50YWxBY3Rpdml0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpKSB7IHJldHVybiBwYXJzZUludChpLCAxMCk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoaSkgeyByZXR1cm4gIWlzTmFOKGkpOyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICh7IGlkOiBpLCBsYWJlbDogUmVudGFsLk1vZGVscy5SZW50YWxBY3Rpdml0eVtpXSB9KTsgfSlcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuUmVudGFsQWN0aXZpdGllcyA9IFJlbnRhbEFjdGl2aXRpZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncmVudGFsQWN0aXZpdGllcycsIFJlbnRhbEFjdGl2aXRpZXMpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsQ2F0ZWdvcmllcygpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGdldEJ5SWQ6IGZ1bmN0aW9uIChpZCkgeyByZXR1cm4gKHsgaWQ6IGlkLCBsYWJlbDogUmVudGFsLk1vZGVscy5SZW50YWxDYXRlZ29yeVtpZF0gfSk7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGw6IE9iamVjdC5rZXlzKFJlbnRhbC5Nb2RlbHMuUmVudGFsQ2F0ZWdvcnkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoaSkgeyByZXR1cm4gcGFyc2VJbnQoaSwgMTApOyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICFpc05hTihpKSAmJiBpICE9PSAwOyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICh7IGlkOiBpLCBsYWJlbDogUmVudGFsLk1vZGVscy5SZW50YWxDYXRlZ29yeVtpXSB9KTsgfSlcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuUmVudGFsQ2F0ZWdvcmllcyA9IFJlbnRhbENhdGVnb3JpZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncmVudGFsQ2F0ZWdvcmllcycsIFJlbnRhbENhdGVnb3JpZXMpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsR29hbHMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhSZW50YWwuTW9kZWxzLlJlbnRhbEdvYWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpKSB7IHJldHVybiBwYXJzZUludChpLCAxMCk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChpKSB7IHJldHVybiAhaXNOYU4oaSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpKSB7IHJldHVybiAoeyBpZDogaSwgbGFiZWw6IFJlbnRhbC5Nb2RlbHMuUmVudGFsR29hbFtpXSB9KTsgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlJlbnRhbEdvYWxzID0gUmVudGFsR29hbHM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncmVudGFsR29hbHMnLCBSZW50YWxHb2Fscyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsQVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsQVBJKCRxLCAkaHR0cCwgY29uZmlnU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBSZW50YWxBUEkucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChyZW50YWxJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAoX3RoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgX3RoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlbnRhbHMvXCIgKyByZW50YWxJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGh0dHAocmVxdWVzdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAoX3RoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgX3RoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlbnRhbHNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGh0dHAocmVxdWVzdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuYWRkID0gZnVuY3Rpb24gKHJlbnRhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZW50YWxzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogcmVudGFsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuc2F2ZSA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFsc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BVVCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YTogcmVudGFsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuY2hlY2tIaWdoRGVtYW5kID0gZnVuY3Rpb24gKGRhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFscy9jaGVja19oaWdoX2RlbWFuZD9kYXRlPVwiICsgZGF0ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWxBUEk7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxBUEkgPSBSZW50YWxBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncmVudGFsQVBJJywgUmVudGFsQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsU2VydmljZSgkcSwgcmVudGFsQVBJLCBnZW9TZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbEFQSSA9IHJlbnRhbEFQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgUmVudGFsU2VydmljZS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKHJlbnRhbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5nZXQocmVudGFsSWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG5ldyBSZW50YWwuTW9kZWxzLlJlbnRhbCgpLnNlcmlhbGl6ZShyZXNwb25zZS5kYXRhKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsU2VydmljZS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWxBUEkuZ2V0QWxsKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UuZGF0YS5tYXAoZnVuY3Rpb24gKGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBuZXcgUmVudGFsLk1vZGVscy5SZW50YWwoKS5zZXJpYWxpemUoaXRlbSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5hZGQocmVudGFsLmRlc2VyaWFsaXplKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbFNlcnZpY2UucHJvdG90eXBlLnNhdmUgPSBmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5zYXZlKHJlbnRhbC5kZXNlcmlhbGl6ZSgpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5jaGVja0hpZ2hEZW1hbmQgPSBmdW5jdGlvbiAoZGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWxBUEkuY2hlY2tIaWdoRGVtYW5kKGRhdGUudG9JU09TdHJpbmcoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UuZGF0YSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxTZXJ2aWNlID0gUmVudGFsU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxTZXJ2aWNlJywgUmVudGFsU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTaG9lU2l6ZXMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBbMSwgMiwgMywgNCwgNC41LCA1LCA1LjUsIDYsIDYuNSwgNywgNy41LCA4LCA4LjUsIDksIDkuNSwgMTAsIDEwLjUsXG4gICAgICAgICAgICAgICAgICAgICAgICAxMSwgMTEuNSwgMTIsIDEyLjUsIDEzLCAxMy41LCAxNCwgMTQuNSwgMTUsIDE1LjUsIDE2LCAxNi41XTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuU2hvZVNpemVzID0gU2hvZVNpemVzO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3Nob2VTaXplcycsIFNob2VTaXplcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTa2lTaXplcygpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gMTE1OyBpIDw9IDIwMDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw6IGkgKyAnIGluJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QnlJZDogZnVuY3Rpb24gKGlkKSB7IHJldHVybiAoeyBpZDogaWQsIGxhYmVsOiBpZCArICcgaW4nIH0pOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsOiByZXN1bHRcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuU2tpU2l6ZXMgPSBTa2lTaXplcztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdza2lTaXplcycsIFNraVNpemVzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbiJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==
