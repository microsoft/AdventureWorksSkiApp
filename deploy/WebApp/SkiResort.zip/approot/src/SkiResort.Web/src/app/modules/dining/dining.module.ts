/// <reference path='../../../../typings/browser.d.ts'/>

module SkiResort.App {
    'use strict';

    export module Dining {
        angular.module('app.dining', []);
    }
}
