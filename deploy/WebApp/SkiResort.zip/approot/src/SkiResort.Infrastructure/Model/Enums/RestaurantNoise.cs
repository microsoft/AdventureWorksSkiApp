﻿
namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum Noise
    {
        Unknown = 0,
        Low = 1,
        Medium = 2,
        Loud = 3
    }
}
