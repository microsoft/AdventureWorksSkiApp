﻿
namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum PriceLevel
    {
        Unknown = 0,
        Low = 1,
        Medium = 2,
        Hight = 3,
    }
}
