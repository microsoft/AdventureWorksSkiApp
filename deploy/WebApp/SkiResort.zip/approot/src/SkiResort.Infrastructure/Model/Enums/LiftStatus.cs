﻿namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum LiftStatus
    {
        Unknown = 0,
        Open = 1,
        Closed = 2
    }
}
