﻿namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum FoodType
    {
        Unknown = 0,
        American = 1,
        Spanish = 2
    }
}
