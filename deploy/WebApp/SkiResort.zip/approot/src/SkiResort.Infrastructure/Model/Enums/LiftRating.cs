﻿
namespace AdventureWorks.SkiResort.Infrastructure.Model.Enums
{
    public enum LiftRating
    {
        Unknown = 0,
        Beginner = 1,
        Intermediate = 2,
        Advanced = 3
    }
}
