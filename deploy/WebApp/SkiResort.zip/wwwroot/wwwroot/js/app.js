/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    'use strict';
    var App;
    (function (App) {
        angular.module('app', [
            'ionic',
            'app.core',
            'app.auth',
            'app.home',
            'app.lift',
            'app.dining',
            'app.rental'
        ]);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        run.$inject = ["$ionicPlatform", "$log"];
        function run($ionicPlatform, $log) {
            $ionicPlatform.ready(deviceReady.call(this, $log));
        }
        function deviceReady($log) {
            $log.info('Device Ready');
        }
        angular.module('app')
            .run(run);
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Auth;
        (function (Auth) {
            angular.module('app.auth', []);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Core;
        (function (Core) {
            angular.module('app.core', []);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Dining;
        (function (Dining) {
            angular.module('app.dining', []);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Home;
        (function (Home) {
            angular.module('app.home', []);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Lift;
        (function (Lift) {
            angular.module('app.lift', []);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        'use strict';
        var Rental;
        (function (Rental) {
            angular.module('app.rental', []);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.login', {
                    url: '/login',
                    views: {
                        'content': {
                            controller: 'LoginController',
                            controllerAs: '$ctrl',
                            templateUrl: 'auth/templates/login.template.html',
                        }
                    }
                });
            }
            angular.module('app.auth')
                .config(routingConfiguration);
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            ionicConfiguration.$inject = ["$ionicConfigProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app', {
                    url: '',
                    abstract: true,
                    controller: 'MenuController',
                    controllerAs: '$ctrl',
                    templateUrl: 'core/templates/menu.template.html'
                });
            }
            function ionicConfiguration($ionicConfigProvider) {
                $ionicConfigProvider.scrolling.jsScrolling(false);
            }
            angular.module('app.core')
                .config(routingConfiguration)
                .config(ionicConfiguration);
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider"];
            function routingConfiguration($stateProvider) {
                $stateProvider
                    .state('app.dining-list', {
                    url: '/dining/list',
                    views: {
                        'content': {
                            controller: 'DiningController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-list.template.html'
                        }
                    }
                })
                    .state('app.dining-detail', {
                    url: '/dining/detail/:id',
                    params: {
                        restaurant: null
                    },
                    views: {
                        'content': {
                            controller: 'DiningDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'dining/templates/dining-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.dining')
                .config(routingConfiguration);
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.home', {
                    url: '/home',
                    data: {
                        barColor: 'dark'
                    },
                    views: {
                        'content': {
                            controller: 'HomeController',
                            controllerAs: '$ctrl',
                            templateUrl: 'home/templates/home.template.html',
                        }
                    }
                });
                $urlRouterProvider.otherwise('/home');
            }
            angular.module('app.home')
                .config(routingConfiguration);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.lift-status-list', {
                    url: '/lift/status/list',
                    views: {
                        'content': {
                            controller: 'LiftStatusListController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-list.template.html',
                        }
                    }
                })
                    .state('app.lift-status-detail', {
                    url: '/lift/status/detail/:liftId',
                    views: {
                        'content': {
                            controller: 'LiftStatusDetailController',
                            controllerAs: '$ctrl',
                            templateUrl: 'lift/templates/lift-status-detail.template.html'
                        }
                    }
                });
            }
            angular.module('app.lift')
                .config(routingConfiguration);
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            'use strict';
            routingConfiguration.$inject = ["$stateProvider", "$urlRouterProvider"];
            function routingConfiguration($stateProvider, $urlRouterProvider) {
                $stateProvider
                    .state('app.rentals', {
                    cache: false,
                    url: '/rentals',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/rentals.template.html',
                            controller: 'RentalsController',
                            controllerAs: '$ctrl'
                        }
                    }
                })
                    .state('app.rental-detail', {
                    cache: false,
                    url: '/rental/:rentalId',
                    views: {
                        'content': {
                            templateUrl: 'rental/templates/new-reservation-wrapper.template.html',
                            controller: 'NewReservationController',
                            controllerAs: 'tabCtrl'
                        }
                    }
                });
            }
            angular.module('app.rental')
                .config(routingConfiguration);
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Auth.Models || (Auth.Models = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                var SummaryInfo = (function () {
                    function SummaryInfo() {
                    }
                    return SummaryInfo;
                }());
                Models.SummaryInfo = SummaryInfo;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Models;
            (function (Models) {
                'use strict';
                (function (Weather) {
                    Weather[Weather["Unknown"] = 0] = "Unknown";
                    Weather[Weather["Snowing"] = 1] = "Snowing";
                    Weather[Weather["Rainy"] = 2] = "Rainy";
                    Weather[Weather["Cloudy"] = 3] = "Cloudy";
                    Weather[Weather["Sunny"] = 4] = "Sunny";
                })(Models.Weather || (Models.Weather = {}));
                var Weather = Models.Weather;
            })(Models = Core.Models || (Core.Models = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LevelOfNoise) {
                    LevelOfNoise[LevelOfNoise["Unknown"] = 0] = "Unknown";
                    LevelOfNoise[LevelOfNoise["Low"] = 1] = "Low";
                    LevelOfNoise[LevelOfNoise["Medium"] = 2] = "Medium";
                    LevelOfNoise[LevelOfNoise["Loud"] = 3] = "Loud";
                })(Models.LevelOfNoise || (Models.LevelOfNoise = {}));
                var LevelOfNoise = Models.LevelOfNoise;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Models;
            (function (Models) {
                'use strict';
                var Restaurant = (function () {
                    function Restaurant() {
                    }
                    return Restaurant;
                }());
                Models.Restaurant = Restaurant;
            })(Models = Dining.Models || (Dining.Models = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Lift = (function () {
                    function Lift() {
                    }
                    Lift.prototype.serialize = function (data) {
                        this.liftId = data.liftId;
                        this.name = data.name;
                        this.rating = data.rating;
                        this.status = data.status;
                        this.latitude = data.latitude;
                        this.longitude = data.longitude;
                        this.stayAway = data.stayAway;
                        this.waitingTime = data.waitingTime;
                        this.closedReason = data.closedReason;
                        return this;
                    };
                    Lift.prototype.deserialize = function () {
                        return {
                            liftId: this.liftId,
                            name: this.name,
                            rating: this.rating,
                            status: this.status,
                            latitude: this.latitude,
                            longitude: this.longitude,
                            stayAway: this.stayAway,
                            waitingTime: this.waitingTime,
                            closedReason: this.closedReason
                        };
                    };
                    return Lift;
                }());
                Models.Lift = Lift;
            })(Models = Lift_1.Models || (Lift_1.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftRating) {
                    LiftRating[LiftRating["Unknown"] = 0] = "Unknown";
                    LiftRating[LiftRating["Beginner"] = 1] = "Beginner";
                    LiftRating[LiftRating["Intermediate"] = 2] = "Intermediate";
                    LiftRating[LiftRating["Advanced"] = 3] = "Advanced";
                })(Models.LiftRating || (Models.LiftRating = {}));
                var LiftRating = Models.LiftRating;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Models;
            (function (Models) {
                'use strict';
                (function (LiftStatus) {
                    LiftStatus[LiftStatus["Unknown"] = 0] = "Unknown";
                    LiftStatus[LiftStatus["Open"] = 1] = "Open";
                    LiftStatus[LiftStatus["Closed"] = 2] = "Closed";
                })(Models.LiftStatus || (Models.LiftStatus = {}));
                var LiftStatus = Models.LiftStatus;
            })(Models = Lift.Models || (Lift.Models = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental_1) {
            var Models;
            (function (Models) {
                'use strict';
                var Rental = (function () {
                    function Rental() {
                    }
                    Rental.prototype.serialize = function (data) {
                        this.rentalId = data.rentalId;
                        this.userEmail = data.userEmail;
                        this.startDate = new Date(data.startDate);
                        this.endDate = new Date(data.endDate);
                        this.pickupHour = data.pickupHour;
                        this.activity = data.activity;
                        this.category = data.category;
                        this.goal = data.goal;
                        this.shoeSize = data.shoeSize;
                        this.skiSize = data.skiSize;
                        this.poleSize = data.poleSize;
                        this.totalCost = data.totalCost;
                        return this;
                    };
                    Rental.prototype.deserialize = function () {
                        return {
                            rentalId: this.rentalId,
                            userEmail: this.userEmail,
                            startDate: this.startDate.toJSON(),
                            endDate: this.endDate.toJSON(),
                            pickupHour: this.pickupHour,
                            activity: this.activity,
                            category: this.category,
                            goal: this.goal,
                            shoeSize: this.shoeSize,
                            skiSize: this.skiSize,
                            poleSize: this.poleSize,
                            totalCost: this.totalCost
                        };
                    };
                    return Rental;
                }());
                Models.Rental = Rental;
            })(Models = Rental_1.Models || (Rental_1.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalActivity) {
                    RentalActivity[RentalActivity["Ski"] = 0] = "Ski";
                    RentalActivity[RentalActivity["Snowboard"] = 1] = "Snowboard";
                })(Models.RentalActivity || (Models.RentalActivity = {}));
                var RentalActivity = Models.RentalActivity;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalCategory) {
                    RentalCategory[RentalCategory["Unknown"] = 0] = "Unknown";
                    RentalCategory[RentalCategory["Beginner"] = 1] = "Beginner";
                    RentalCategory[RentalCategory["Intermediate"] = 2] = "Intermediate";
                    RentalCategory[RentalCategory["Advanced"] = 3] = "Advanced";
                })(Models.RentalCategory || (Models.RentalCategory = {}));
                var RentalCategory = Models.RentalCategory;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Models;
            (function (Models) {
                'use strict';
                (function (RentalGoal) {
                    RentalGoal[RentalGoal["Unknown"] = 0] = "Unknown";
                    RentalGoal[RentalGoal["Demo"] = 1] = "Demo";
                    RentalGoal[RentalGoal["Performance"] = 2] = "Performance";
                    RentalGoal[RentalGoal["Sport"] = 3] = "Sport";
                })(Models.RentalGoal || (Models.RentalGoal = {}));
                var RentalGoal = Models.RentalGoal;
            })(Models = Rental.Models || (Rental.Models = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LoginController = (function () {
                    LoginController.$inject = ["authService", "$ionicHistory"];
                    function LoginController(authService, $ionicHistory) {
                        this.authService = authService;
                        this.$ionicHistory = $ionicHistory;
                        this.loginData = {};
                        this.wrongPassword = false;
                        this.loading = false;
                    }
                    LoginController.prototype.login = function () {
                        var _this = this;
                        this.loading = true;
                        this.wrongPassword = false;
                        if (this.loginForm.$valid) {
                            this.authService.login(this.loginData.username, this.loginData.password)
                                .then(function () {
                                _this.$ionicHistory.goBack();
                            })
                                .catch(function () {
                                _this.wrongPassword = true;
                            })
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    return LoginController;
                }());
                angular.module('app.auth')
                    .controller('LoginController', LoginController);
            })(Controllers = Auth.Controllers || (Auth.Controllers = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthImageService = (function () {
                    AuthImageService.$inject = ["$q", "authAPI", "currentUserService", "configService"];
                    function AuthImageService($q, authAPI, currentUserService, configService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                        this.configService = configService;
                    }
                    AuthImageService.prototype.get = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "users/photo/" + id;
                    };
                    return AuthImageService;
                }());
                Services.AuthImageService = AuthImageService;
                angular.module('app.auth')
                    .service('authImageService', AuthImageService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthAPI = (function () {
                    AuthAPI.$inject = ["$http", "configService", "$httpParamSerializerJQLike"];
                    function AuthAPI($http, configService, $httpParamSerializerJQLike) {
                        this.$http = $http;
                        this.configService = configService;
                        this.$httpParamSerializerJQLike = $httpParamSerializerJQLike;
                    }
                    AuthAPI.prototype.login = function (username, password) {
                        var request = {
                            url: this.configService.API.URL + "connect/token",
                            method: 'POST',
                            data: this.$httpParamSerializerJQLike({
                                grant_type: this.configService.Authentication.GrantType,
                                client_id: this.configService.Authentication.ClientID,
                                client_secret: this.configService.Authentication.ClientSecret,
                                scope: this.configService.Authentication.Scope,
                                username: username,
                                password: password
                            }),
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded'
                            }
                        };
                        return this.$http(request);
                    };
                    return AuthAPI;
                }());
                Services.AuthAPI = AuthAPI;
                angular.module('app.auth')
                    .service('authAPI', AuthAPI);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var AuthService = (function () {
                    AuthService.$inject = ["$q", "authAPI", "currentUserService"];
                    function AuthService($q, authAPI, currentUserService) {
                        this.$q = $q;
                        this.authAPI = authAPI;
                        this.currentUserService = currentUserService;
                    }
                    AuthService.prototype.login = function (username, password) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.authAPI.login(username, password)
                                .then(function (response) {
                                _this.currentUserService.accessToken = response.data.access_token;
                                return _this.currentUserService.getInfo();
                            })
                                .then(function () {
                                resolve();
                            })
                                .catch(function (error) {
                                reject(error.data);
                            });
                        });
                    };
                    return AuthService;
                }());
                Services.AuthService = AuthService;
                angular.module('app.auth')
                    .service('authService', AuthService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Auth;
        (function (Auth) {
            var Services;
            (function (Services) {
                'use strict';
                var CURRENT_USER_STORAGE_KEY = '_currentUserData';
                var CurrentUserService = (function () {
                    CurrentUserService.$inject = ["$q", "$rootScope", "$http", "configService", "$log"];
                    function CurrentUserService($q, $rootScope, $http, configService, $log) {
                        this.$q = $q;
                        this.$rootScope = $rootScope;
                        this.$http = $http;
                        this.configService = configService;
                        this.$log = $log;
                        this.accessToken = null;
                        this.currentUser = null;
                        this.load();
                        if (this.accessToken) {
                            this.getInfo();
                        }
                    }
                    CurrentUserService.prototype.save = function () {
                        this.$log.info('CurrentUserService saving to LocalStorage');
                        var currentUserCopy = angular.copy(this.currentUser);
                        currentUserCopy.photo = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({
                            accessToken: this.accessToken,
                            currentUser: currentUserCopy
                        }));
                        this.$log.info('- Successfully saved');
                    };
                    CurrentUserService.prototype.load = function () {
                        this.$log.info('CurrentUserService loading from LocalStorage');
                        var storedRawData = localStorage.getItem(CURRENT_USER_STORAGE_KEY);
                        if (storedRawData) {
                            var storedData = JSON.parse(storedRawData);
                            this.accessToken = storedData.accessToken;
                            this.currentUser = storedData.currentUser;
                            this.$rootScope.currentUser = this.currentUser;
                            this.$log.info('- Successfully loaded');
                        }
                        else {
                            this.$log.info('- LocalStorage is empty');
                        }
                    };
                    CurrentUserService.prototype.reset = function () {
                        this.$log.info('CurrentUserService resetting LocalStorage');
                        this.accessToken = null;
                        this.currentUser = null;
                        this.$rootScope.currentUser = null;
                        localStorage.setItem(CURRENT_USER_STORAGE_KEY, JSON.stringify({}));
                        this.$log.info('- Done');
                    };
                    CurrentUserService.prototype.getInfo = function () {
                        var _this = this;
                        this.$log.info('CurrentUserService getting information');
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "users/user",
                            method: 'GET',
                            headers: {
                                'Authorization': "Bearer " + this.accessToken
                            }
                        };
                        return this.$http(request)
                            .then(function (response) {
                            _this.$log.info('- Information getted successfully');
                            _this.currentUser = response.data;
                            _this.$rootScope.currentUser = _this.currentUser;
                            _this.save();
                        })
                            .catch(function () {
                            _this.reset();
                            _this.$log.warn('- Something went wrong while getting information');
                        });
                    };
                    return CurrentUserService;
                }());
                Services.CurrentUserService = CurrentUserService;
                angular.module('app.auth')
                    .service('currentUserService', CurrentUserService);
            })(Services = Auth.Services || (Auth.Services = {}));
        })(Auth = App.Auth || (App.Auth = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var MenuController = (function () {
                    MenuController.$inject = ["$ionicSideMenuDelegate", "$state", "currentUserService"];
                    function MenuController($ionicSideMenuDelegate, $state, currentUserService) {
                        this.$ionicSideMenuDelegate = $ionicSideMenuDelegate;
                        this.$state = $state;
                        this.currentUserService = currentUserService;
                    }
                    MenuController.prototype.navigateTo = function (toStateName) {
                        this.$state.go(toStateName);
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    MenuController.prototype.logout = function () {
                        this.currentUserService.reset();
                        this.$ionicSideMenuDelegate.toggleRight(false);
                    };
                    return MenuController;
                }());
                angular.module('app.core')
                    .controller('MenuController', MenuController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var Weather = Core.Models.Weather;
                var SummaryInfoController = (function () {
                    SummaryInfoController.$inject = ["summaryInfoAPI", "$state"];
                    function SummaryInfoController(summaryInfoAPI, $state) {
                        var _this = this;
                        this.summaryInfoAPI = summaryInfoAPI;
                        this.$state = $state;
                        summaryInfoAPI.get().then(function (summaryInfo) {
                            _this.summaryInfo = summaryInfo;
                        });
                    }
                    SummaryInfoController.prototype.getWeather = function (id) {
                        return Weather[id];
                    };
                    return SummaryInfoController;
                }());
                angular.module('app.core')
                    .controller('SummaryInfoController', SummaryInfoController);
            })(Controllers = Core.Controllers || (Core.Controllers = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function Range() {
                    return function (input, _min, _max) {
                        var min = parseInt(_min, 10);
                        var max = parseInt(_max, 10);
                        for (var i = min; i < max; i++) {
                            input.push(i);
                        }
                        return input;
                    };
                }
                angular.module('app.rental')
                    .filter('skiRange', Range);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function AvatarDirective() {
                    function setBackgroundImage(element, url) {
                        element.attr('style', 'background-image: url(\'' + url + '\');');
                    }
                    function link(scope, element, attr) {
                        element.addClass('ski-avatar');
                        attr.$observe('skiAvatar', function () {
                            setBackgroundImage(element, attr.skiAvatar);
                        });
                    }
                    return {
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiAvatar', AvatarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var NavBarController = (function () {
                    NavBarController.$inject = ["navigationService"];
                    function NavBarController(navigationService) {
                        this.navigationService = navigationService;
                    }
                    NavBarController.prototype.goHome = function () {
                        this.navigationService.goHome();
                    };
                    NavBarController.prototype.goBack = function () {
                        this.navigationService.goBack();
                    };
                    return NavBarController;
                }());
                function NavBarDirective() {
                    return {
                        restrict: 'A',
                        scope: {
                            title: '@',
                            logoBig: '=',
                            hamburguer: '=',
                            back: '='
                        },
                        templateUrl: 'core/templates/nav-bar.template.html',
                        controller: NavBarController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiNavBar', NavBarDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function RatingDirective() {
                    var defaultClasses = 'icon ';
                    function link(scope, element) {
                        for (var i = 0; i < scope.value; i++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOn + "\"/>"));
                        }
                        for (var j = scope.value; j < scope.max; j++) {
                            element.append(angular.element("<span class=\"" + defaultClasses + scope.classOff + "\"/>"));
                        }
                    }
                    return {
                        scope: {
                            value: '@',
                            max: '@',
                            classOn: '@',
                            classOff: '@'
                        },
                        link: link
                    };
                }
                angular.module('app.core')
                    .directive('skiRating', RatingDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                var SelectController = (function () {
                    SelectController.$inject = ["$scope", "$element"];
                    function SelectController($scope, $element) {
                        this.$scope = $scope;
                        this.$element = $element;
                        this.classes = {
                            modalOpened: 'ski-select-modal--opened'
                        };
                        this.selectors = {
                            modal: '.ski-select-modal'
                        };
                    }
                    SelectController.prototype.showModal = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$element.find(this.selectors.modal).addClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.closeModal = function () {
                        this.$element.find(this.selectors.modal).removeClass(this.classes.modalOpened);
                    };
                    SelectController.prototype.updateSelection = function (option) {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.$scope.model = option;
                        this.closeModal();
                    };
                    SelectController.prototype.resetSelection = function () {
                        if (this.$scope.disabled) {
                            return;
                        }
                        this.updateSelection('');
                    };
                    return SelectController;
                }());
                function SelectDirective() {
                    return {
                        restrict: 'E',
                        scope: {
                            model: '=',
                            placeholder: '@',
                            selectOptions: '=',
                            required: '=',
                            name: '@',
                            disabled: '=',
                            hasTabs: '@'
                        },
                        templateUrl: 'core/templates/select.template.html',
                        controller: SelectController,
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSelect', SelectDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Directives;
            (function (Directives) {
                function SummaryInfoDirective() {
                    return {
                        scope: {},
                        restrict: 'E',
                        templateUrl: 'core/templates/summary-info.template.html',
                        controller: 'SummaryInfoController',
                        controllerAs: '$ctrl'
                    };
                }
                angular.module('app.core')
                    .directive('skiSummaryInfo', SummaryInfoDirective);
            })(Directives = Core.Directives || (Core.Directives = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var ConfigService = (function () {
                    ConfigService.$inject = ["$log"];
                    function ConfigService($log) {
                        this.General = {
                            FakeGeolocation: true,
                            Geolocation: {
                                latitude: 40.722846,
                                longitude: -74.007325
                            }
                        };
                        this.API = {
                            URL: '/',
                            Path: 'api/'
                        };
                        this.Authentication = {
                            GrantType: 'password',
                            ClientID: 'SkyResort',
                            ClientSecret: 'secret',
                            Scope: 'api'
                        };
                        $log.info('ConfigService initialized');
                        if (ionic.Platform.isWebView()) {
                            $log.info(' - WebView detected');
                            this.API.URL = '__YOURWEBAPIURL__';
                        }
                        else {
                            $log.info('- Browser detected');
                        }
                    }
                    return ConfigService;
                }());
                Services.ConfigService = ConfigService;
                angular.module('app.core')
                    .service('configService', ConfigService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var PI180 = 0.017453292519943295; // (Math.PI/180)
                var GeoService = (function () {
                    GeoService.$inject = ["$q", "configService", "$log"];
                    function GeoService($q, configService, $log) {
                        this.$q = $q;
                        this.configService = configService;
                        this.$log = $log;
                    }
                    GeoService.prototype.geolocationApiAvailable = function () {
                        return (navigator.geolocation && navigator.geolocation.getCurrentPosition);
                    };
                    GeoService.prototype.getPosition = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.$log.info('Geolocation requested');
                            if (_this.configService.General.FakeGeolocation) {
                                _this.$log.info('- Returning fake geolocation');
                                resolve(_this.configService.General.Geolocation);
                            }
                            else if (_this.geolocationApiAvailable()) {
                                navigator.geolocation.getCurrentPosition(function (result) {
                                    resolve({
                                        latitude: result.coords.latitude,
                                        longitude: result.coords.longitude
                                    });
                                }, function () {
                                    reject();
                                });
                            }
                            else {
                                _this.$log.warn('- Geolocation API not available');
                                reject();
                            }
                        });
                    };
                    GeoService.prototype.getDistanceBetween = function (a, b) {
                        var p = PI180;
                        var c = Math.cos;
                        var r = 0.5 - c((a.latitude - b.latitude) * p) / 2 + c(b.latitude * p) *
                            c(a.latitude * p) * (1 - c((a.longitude - b.longitude) * p)) / 2;
                        var result = (12742 * Math.asin(Math.sqrt(r)) * 0.621371); // 2 * R; R = 6371 km
                        return Math.round(result * 1e2) / 1e2;
                    };
                    return GeoService;
                }());
                Services.GeoService = GeoService;
                angular.module('app.core')
                    .service('geoService', GeoService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var NavigationService = (function () {
                    NavigationService.$inject = ["$state", "$ionicHistory"];
                    function NavigationService($state, $ionicHistory) {
                        this.$state = $state;
                        this.$ionicHistory = $ionicHistory;
                    }
                    NavigationService.prototype.goHome = function () {
                        this.$ionicHistory.nextViewOptions({ disableBack: true, historyRoot: true });
                        this.$state.go('app.home');
                    };
                    NavigationService.prototype.goBack = function () {
                        if (ionic.Platform['is']('browser')) {
                            window.history.back();
                        }
                        else {
                            this.$ionicHistory.goBack();
                        }
                    };
                    return NavigationService;
                }());
                Services.NavigationService = NavigationService;
                angular.module('app.core')
                    .service('navigationService', NavigationService);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Core;
        (function (Core) {
            var Services;
            (function (Services) {
                'use strict';
                var SummaryInfoAPI = (function () {
                    SummaryInfoAPI.$inject = ["$q", "$http", "configService"];
                    function SummaryInfoAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    SummaryInfoAPI.prototype.get = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "summaries",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    return SummaryInfoAPI;
                }());
                Services.SummaryInfoAPI = SummaryInfoAPI;
                angular.module('app.core')
                    .service('summaryInfoAPI', SummaryInfoAPI);
            })(Services = Core.Services || (Core.Services = {}));
        })(Core = App.Core || (App.Core = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningDetailController = (function () {
                    DiningDetailController.$inject = ["$stateParams", "diningService"];
                    function DiningDetailController($stateParams, diningService) {
                        var _this = this;
                        this.$stateParams = $stateParams;
                        this.diningService = diningService;
                        this.recommendations = [];
                        this.loading = false;
                        this.loading = true;
                        var id = $stateParams['id'];
                        if (!$stateParams['restaurant']) {
                            this.diningService.getSingle(id).then(function (restaurant) {
                                _this.restaurant = restaurant;
                                _this.getExtraInformation();
                            });
                        }
                        else {
                            this.restaurant = $stateParams['restaurant'];
                            this.getExtraInformation();
                        }
                    }
                    DiningDetailController.prototype.getExtraInformation = function () {
                        var _this = this;
                        this.diningService.getRecommendations(this.restaurant.name)
                            .then(function (restaurants) {
                            _this.recommendations = restaurants;
                            _this.loading = false;
                        });
                    };
                    DiningDetailController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningDetailController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningDetailController;
                }());
                angular.module('app.dining')
                    .controller('DiningDetailController', DiningDetailController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LevelOfNoise = Dining.Models.LevelOfNoise;
                var DiningController = (function () {
                    DiningController.$inject = ["diningService"];
                    function DiningController(diningService) {
                        this.diningService = diningService;
                        this.getRestaurants();
                        this.fillFilters();
                        this.orderBy = '';
                    }
                    DiningController.prototype.getRestaurants = function () {
                        var _this = this;
                        this.loading = true;
                        this.diningService.getNear()
                            .then(function (restaurants) {
                            _this.restaurants = restaurants;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    DiningController.prototype.fillFilters = function () {
                        this.filters = this.diningService.getFilters();
                    };
                    DiningController.prototype.getImage = function (id) {
                        return this.diningService.getImage(id);
                    };
                    DiningController.prototype.getLevelOfNoise = function (id) {
                        return LevelOfNoise[id];
                    };
                    return DiningController;
                }());
                angular.module('app.dining')
                    .controller('DiningController', DiningController);
            })(Controllers = Dining.Controllers || (Dining.Controllers = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningAPI = (function () {
                    DiningAPI.$inject = ["$q", "$http", "configService"];
                    function DiningAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    DiningAPI.prototype.getAll = function () {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants",
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getNear = function (latitude, longitude) {
                        var request = {
                            url: ((this.configService.API.URL + this.configService.API.Path) + "restaurants/nearby") +
                                ("?latitude=" + latitude) +
                                ("&longitude=" + longitude),
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getRecommendations = function (searchtext) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/recommendations/" + searchtext,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getSingle = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "restaurants/" + id,
                            method: 'GET'
                        };
                        return this.$http(request).then(function (results) {
                            return results.data;
                        });
                    };
                    DiningAPI.prototype.getImage = function (id) {
                        return (this.configService.API.URL + this.configService.API.Path) + "restaurants/photo/" + id;
                    };
                    return DiningAPI;
                }());
                Services.DiningAPI = DiningAPI;
                angular.module('app.dining')
                    .service('diningAPI', DiningAPI);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Dining;
        (function (Dining) {
            var Services;
            (function (Services) {
                'use strict';
                var DiningService = (function () {
                    DiningService.$inject = ["$q", "diningAPI", "geoService"];
                    function DiningService($q, diningAPI, geoService) {
                        this.$q = $q;
                        this.diningAPI = diningAPI;
                        this.geoService = geoService;
                        this.latitude = 0;
                        this.longitude = 0;
                    }
                    DiningService.prototype.getDistance = function (latitude, longitude) {
                        return this.geoService.getDistanceBetween({ latitude: latitude, longitude: longitude }, { latitude: this.latitude, longitude: this.longitude });
                    };
                    DiningService.prototype.calculateDistances = function (restaurants) {
                        for (var i = 0, l = restaurants.length; i < l; i++) {
                            restaurants[i].distance = this.getDistance(restaurants[i].latitude, restaurants[i].longitude);
                        }
                        return restaurants;
                    };
                    DiningService.prototype.getAll = function () {
                        return this.diningAPI.getAll();
                    };
                    DiningService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve) {
                            return _this.geoService.getPosition()
                                .then(function (result) {
                                _this.latitude = result.latitude;
                                _this.longitude = result.longitude;
                                return _this.diningAPI.getNear(_this.latitude, _this.longitude).then(function (restaurants) {
                                    return resolve(_this.calculateDistances(restaurants));
                                });
                            });
                        });
                    };
                    DiningService.prototype.getRecommendations = function (_searchtext) {
                        var _this = this;
                        var searchtextSplitted = _searchtext.split(' ');
                        var searchtext = searchtextSplitted[searchtextSplitted.length - 1];
                        return this.$q(function (resolve) {
                            return _this.diningAPI.getRecommendations(searchtext).then(function (ids) {
                                var restaurants = [];
                                var promises = [];
                                for (var i = 0, l = ids.length; i < l; i++) {
                                    promises.push((function () {
                                        return _this.getSingle(ids[i]).then(function (restaurant) {
                                            restaurants.push(restaurant);
                                        });
                                    })());
                                }
                                _this.$q.all(promises).then(function () {
                                    resolve(restaurants);
                                });
                            });
                        });
                    };
                    DiningService.prototype.getSingle = function (id) {
                        return this.diningAPI.getSingle(id);
                    };
                    DiningService.prototype.getFilters = function () {
                        return [
                            { id: '-rating', label: 'Rating' },
                            { id: 'levelOfNoise', label: 'Level Noise' },
                            { id: 'priceLevel', label: 'Price' },
                            { id: 'distance', label: 'Miles Away' },
                            { id: '-familyFriendly', label: 'Family Friendly' }
                        ];
                    };
                    DiningService.prototype.getImage = function (id) {
                        return this.diningAPI.getImage(id);
                    };
                    return DiningService;
                }());
                Services.DiningService = DiningService;
                angular.module('app.dining')
                    .service('diningService', DiningService);
            })(Services = Dining.Services || (Dining.Services = {}));
        })(Dining = App.Dining || (App.Dining = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            'use strict';
            var HomeController = (function () {
                HomeController.$inject = ["$scope", "authService", "authImageService"];
                function HomeController($scope, authService, authImageService) {
                    this.$scope = $scope;
                    this.authService = authService;
                    this.authImageService = authImageService;
                }
                HomeController.prototype.getImage = function (id) {
                    return this.authImageService.get(id);
                };
                return HomeController;
            }());
            angular.module('app.home')
                .controller('HomeController', HomeController);
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Home;
        (function (Home) {
            var Directives;
            (function (Directives) {
                function HomeMenuDirective() {
                    return {
                        restrict: 'E',
                        templateUrl: 'home/templates/home-menu.template.html'
                    };
                }
                angular.module('app.home')
                    .directive('skiHomeMenu', HomeMenuDirective);
            })(Directives = Home.Directives || (Home.Directives = {}));
        })(Home = App.Home || (App.Home = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusDetailController = (function () {
                    LiftStatusDetailController.$inject = ["liftService", "$stateParams", "geoService", "$scope"];
                    function LiftStatusDetailController(liftService, $stateParams, geoService, $scope) {
                        var _this = this;
                        this.liftService = liftService;
                        this.$stateParams = $stateParams;
                        this.geoService = geoService;
                        this.$scope = $scope;
                        this.loading = false;
                        this.userGeolocation = null;
                        this.distance = null;
                        this.getLift();
                        $scope.$watch(function () {
                            _this.getDistance();
                        });
                    }
                    LiftStatusDetailController.prototype.getLift = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.get(this.$stateParams.liftId)
                            .then(function (lift) {
                            _this.lift = lift;
                        })
                            .catch(function () {
                            // Handle error
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusDetailController.prototype.getDistance = function () {
                        var _this = this;
                        if (this.userGeolocation) {
                            this.calcDistance();
                        }
                        else {
                            this.geoService.getPosition()
                                .then(function (data) {
                                _this.userGeolocation = data;
                                _this.calcDistance();
                            });
                        }
                    };
                    LiftStatusDetailController.prototype.calcDistance = function () {
                        if (this.lift) {
                            this.distance = this.geoService.getDistanceBetween(this.userGeolocation, { latitude: this.lift.latitude, longitude: this.lift.longitude });
                        }
                    };
                    return LiftStatusDetailController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusDetailController', LiftStatusDetailController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var LiftStatusListController = (function () {
                    LiftStatusListController.$inject = ["liftService"];
                    function LiftStatusListController(liftService) {
                        this.liftService = liftService;
                        this.getLifts();
                    }
                    LiftStatusListController.prototype.getLifts = function () {
                        var _this = this;
                        this.loading = true;
                        this.liftService.getNear()
                            .then(function (data) {
                            _this.digestLifts(data);
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    LiftStatusListController.prototype.digestLifts = function (lifts) {
                        var _this = this;
                        this.openLifts = [];
                        this.closedLifts = [];
                        lifts.forEach(function (lift) {
                            if (lift.status === Lift.Models.LiftStatus.Open) {
                                _this.openLifts.push(lift);
                            }
                            else if (lift.status === Lift.Models.LiftStatus.Closed) {
                                _this.closedLifts.push(lift);
                            }
                        });
                    };
                    return LiftStatusListController;
                }());
                angular.module('app.lift')
                    .controller('LiftStatusListController', LiftStatusListController);
            })(Controllers = Lift.Controllers || (Lift.Controllers = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftAPI = (function () {
                    LiftAPI.$inject = ["$q", "$http", "configService"];
                    function LiftAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    LiftAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "lifts",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    LiftAPI.prototype.getNear = function (latitude, longitude) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: ((_this.configService.API.URL + _this.configService.API.Path) + "lifts/nearby") +
                                    ("?latitude=" + latitude) +
                                    ("&longitude=" + longitude),
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(resolve, reject);
                        });
                    };
                    LiftAPI.prototype.get = function (id) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "lifts/" + id,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return LiftAPI;
                }());
                Services.LiftAPI = LiftAPI;
                angular.module('app.lift')
                    .service('liftAPI', LiftAPI);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Lift;
        (function (Lift) {
            var Services;
            (function (Services) {
                'use strict';
                var LiftService = (function () {
                    LiftService.$inject = ["$q", "liftAPI", "geoService"];
                    function LiftService($q, liftAPI, geoService) {
                        this.$q = $q;
                        this.liftAPI = liftAPI;
                        this.geoService = geoService;
                    }
                    LiftService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            });
                        });
                    };
                    LiftService.prototype.getNear = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.geoService.getPosition()
                                .then(function (result) {
                                return _this.liftAPI.getNear(result.latitude, result.longitude);
                            })
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Lift.Models.Lift().serialize(item);
                                }));
                            })
                                .catch(reject);
                        });
                    };
                    LiftService.prototype.get = function (id) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.liftAPI.get(id)
                                .then(function (result) {
                                resolve(new Lift.Models.Lift().serialize(result.data));
                            })
                                .catch(reject);
                        });
                    };
                    return LiftService;
                }());
                Services.LiftService = LiftService;
                angular.module('app.lift')
                    .service('liftService', LiftService);
            })(Services = Lift.Services || (Lift.Services = {}));
        })(Lift = App.Lift || (App.Lift = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var NewReservationController = (function () {
                    NewReservationController.$inject = ["$scope", "rentalService", "rentalActivities", "rentalCategories", "rentalGoals", "shoeSizes", "skiSizes", "poleSizes", "$stateParams", "pickupHours", "navigationService"];
                    function NewReservationController($scope, rentalService, rentalActivities, rentalCategories, rentalGoals, shoeSizes, skiSizes, poleSizes, $stateParams, pickupHours, navigationService) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.rentalActivities = rentalActivities;
                        this.rentalCategories = rentalCategories;
                        this.rentalGoals = rentalGoals;
                        this.shoeSizes = shoeSizes;
                        this.skiSizes = skiSizes;
                        this.poleSizes = poleSizes;
                        this.$stateParams = $stateParams;
                        this.pickupHours = pickupHours;
                        this.navigationService = navigationService;
                        this.loading = false;
                        this.highDemandAlert = false;
                        // Initialize rental
                        this.rental = new Rental.Models.Rental();
                        this.pickupHours.generateAll();
                        // If there's a rentalId, we're editing, not creating
                        if ($stateParams.rentalId) {
                            this.getRental();
                        }
                        else {
                            this.resetRental();
                        }
                        // Set the todayDated, used as 'min' value for startDate
                        $scope.todayDate = new Date();
                        $scope.todayDate.setHours(0);
                        $scope.todayDate.setMinutes(0);
                        $scope.todayDate.setSeconds(0);
                        /*
                            startDate is edited in two separated inputs,
                            so, it needs to be in reparated models for
                            each ng-model
                        */
                        $scope.startDate = {
                            day: null,
                            hour: null
                        };
                        /*
                            These values (options in selectors) are mapped to the original
                            rental model using $scope.$watchCollection
                        */
                        $scope.rentalTemp = {
                            activity: null,
                            category: null,
                            poleSize: null,
                            skiSize: null
                        };
                        // Update startDate
                        $scope.$watchCollection('startDate', function () {
                            if (!$scope.startDate.day) {
                                return;
                            }
                            _this.rental.startDate = angular.copy($scope.startDate.day);
                            if ($scope.startDate.hour) {
                                _this.rental.startDate.setHours($scope.startDate.hour.hours);
                                _this.rental.startDate.setMinutes($scope.startDate.hour.minutes);
                            }
                            _this.checkHighDemand();
                        });
                        // Update activity, category, poleSize and skiSize
                        $scope.$watchCollection('rentalTemp', function () {
                            _this.rental.activity = $scope.rentalTemp.activity ? $scope.rentalTemp.activity.id : null;
                            _this.rental.category = $scope.rentalTemp.category ? $scope.rentalTemp.category.id : null;
                            _this.rental.poleSize = $scope.rentalTemp.poleSize ? $scope.rentalTemp.poleSize.id : null;
                            _this.rental.skiSize = $scope.rentalTemp.skiSize ? $scope.rentalTemp.skiSize.id : null;
                        });
                    }
                    NewReservationController.prototype.getRental = function () {
                        var _this = this;
                        this.loading = true;
                        this.rentalService.get(this.$stateParams.rentalId)
                            .then(function (rental) {
                            _this.rental = rental;
                            _this.updateTempData();
                            _this.loading = false;
                        });
                    };
                    // This will update all the temporal data used in the custom selects
                    // based on the actual rental object.
                    //
                    // This method is used at start when we're editing a rental
                    NewReservationController.prototype.updateTempData = function () {
                        var hours = this.rental.startDate.getHours();
                        var minutes = this.rental.startDate.getMinutes();
                        this.$scope.startDate = {
                            day: this.rental.startDate,
                            hour: this.pickupHours.getById((hours * 60) + minutes)
                        };
                        this.$scope.rentalTemp = {
                            activity: this.rentalActivities.getById(this.rental.activity),
                            category: this.rentalCategories.getById(this.rental.category),
                            poleSize: this.poleSizes.getById(this.rental.poleSize),
                            skiSize: this.skiSizes.getById(this.rental.skiSize)
                        };
                    };
                    // This will put the rental and all the temporal values for custom
                    // selects to null
                    //
                    // This method is used at start when we're creating a rental
                    NewReservationController.prototype.resetRental = function () {
                        this.rental = new Rental.Models.Rental();
                        for (var i in this.$scope.startDate) {
                            if (this.$scope.startDate.hasOwnProperty(i)) {
                                this.$scope.startDate[i] = null;
                            }
                        }
                        for (var x in this.$scope.rentalTemp) {
                            if (this.$scope.rentalTemp.hasOwnProperty(x)) {
                                this.$scope.rentalTemp[x] = null;
                            }
                        }
                    };
                    NewReservationController.prototype.emitSave = function () {
                        this.$scope.$emit('rental_saved');
                    };
                    NewReservationController.prototype.submitReservation = function () {
                        var _this = this;
                        if (this.rentalForm.$valid) {
                            this.loading = true;
                            var actionPromise = null;
                            if (this.$stateParams.rentalId) {
                                actionPromise = this.saveReservation();
                            }
                            else {
                                actionPromise = this.addReservation();
                            }
                            actionPromise
                                .finally(function () {
                                _this.loading = false;
                            });
                        }
                    };
                    NewReservationController.prototype.addReservation = function () {
                        var _this = this;
                        return this.rentalService.add(this.rental)
                            .then(function () {
                            _this.resetRental();
                            _this.rentalForm.$setPristine();
                            _this.rentalForm.$setUntouched();
                            _this.emitSave();
                        });
                    };
                    NewReservationController.prototype.saveReservation = function () {
                        var _this = this;
                        return this.rentalService.save(this.rental)
                            .then(function () {
                            _this.navigationService.goBack();
                        });
                    };
                    NewReservationController.prototype.checkHighDemand = function () {
                        var _this = this;
                        this.rentalService.checkHighDemand(this.rental.startDate)
                            .then(function (result) {
                            _this.highDemandAlert = result;
                        })
                            .catch(function () {
                            // Handle error
                        });
                    };
                    NewReservationController.prototype.getCalculatedCost = function () {
                        this.rental.totalCost = 0;
                        if (this.rental.startDate && this.rental.endDate) {
                            this.rental.totalCost = 20;
                            var days = Math.floor((this.rental.endDate.getTime() - this.rental.startDate.getTime()) / 1000 / 60 / 60 / 24);
                            this.rental.totalCost = this.rental.totalCost + (days * 5);
                        }
                        return this.rental.totalCost;
                    };
                    return NewReservationController;
                }());
                angular.module('app.rental')
                    .controller('NewReservationController', NewReservationController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var RentalsController = (function () {
                    RentalsController.$inject = ["$ionicTabsDelegate", "$scope", "$stateParams"];
                    function RentalsController($ionicTabsDelegate, $scope, $stateParams) {
                        this.$ionicTabsDelegate = $ionicTabsDelegate;
                        this.$scope = $scope;
                        this.$stateParams = $stateParams;
                        $scope.$on('rental_saved', function () {
                            $ionicTabsDelegate.$getByHandle('section-tabs').select(0);
                            $scope.$broadcast('update_reservation_list');
                        });
                    }
                    return RentalsController;
                }());
                Controllers.RentalsController = RentalsController;
                angular.module('app.rental')
                    .controller('RentalsController', RentalsController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Controllers;
            (function (Controllers) {
                'use strict';
                var ReservationListController = (function () {
                    ReservationListController.$inject = ["$scope", "rentalService", "$state", "$timeout"];
                    function ReservationListController($scope, rentalService, $state, $timeout) {
                        var _this = this;
                        this.$scope = $scope;
                        this.rentalService = rentalService;
                        this.$state = $state;
                        this.$timeout = $timeout;
                        this.showMessage = false;
                        this.getRentals();
                        $scope.$on('update_reservation_list', function () {
                            _this.getRentals()
                                .finally(function () {
                                _this.showMessage = true;
                            });
                        });
                    }
                    ReservationListController.prototype.getRentals = function () {
                        var _this = this;
                        this.loading = true;
                        return this.rentalService.getAll()
                            .then(function (data) {
                            _this.rentals = data;
                        })
                            .finally(function () {
                            _this.loading = false;
                        });
                    };
                    ReservationListController.prototype.navigateToRental = function (rental) {
                        var _this = this;
                        this.navigatingRental = rental;
                        this.$timeout(function () {
                            _this.$state.go('app.rental-detail', { rentalId: rental.rentalId });
                        }, 100);
                    };
                    return ReservationListController;
                }());
                angular.module('app.rental')
                    .controller('ReservationListController', ReservationListController);
            })(Controllers = Rental.Controllers || (Rental.Controllers = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalActivityFilter() {
                    return function (input) {
                        return Rental.Models.RentalActivity[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalActivity', RentalActivityFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Filters;
            (function (Filters) {
                'use strict';
                function RentalCategoryFilter() {
                    return function (input) {
                        return Rental.Models.RentalCategory[input];
                    };
                }
                angular.module('app.rental')
                    .filter('skiRentalCategory', RentalCategoryFilter);
            })(Filters = Rental.Filters || (Rental.Filters = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var PickupHours = (function () {
                    function PickupHours() {
                        this.all = [];
                    }
                    PickupHours.prototype.getById = function (i) {
                        var _hours = Math.floor(i / 60);
                        var _minutes = i - (_hours * 60);
                        var hours = _hours;
                        var minutes = _minutes;
                        var mer = 'am';
                        if (hours > 12) {
                            hours = hours - 12;
                            mer = 'pm';
                        }
                        var hours_str = hours.toString();
                        var minutes_str = minutes.toString();
                        if (hours_str.length === 1) {
                            hours_str = '0' + hours_str;
                        }
                        if (minutes_str.length === 1) {
                            minutes_str = '0' + minutes_str;
                        }
                        return {
                            id: i,
                            label: hours_str + ":" + minutes_str + " " + mer,
                            hours: _hours,
                            minutes: _minutes
                        };
                    };
                    PickupHours.prototype.generateAll = function () {
                        var result = [];
                        var minMinutes = 360;
                        var maxMinutes = 1200;
                        var steps = 15;
                        for (var i = minMinutes; i <= maxMinutes; i = i + steps) {
                            result.push(this.getById(i));
                        }
                        this.all = result;
                    };
                    return PickupHours;
                }());
                Services.PickupHours = PickupHours;
                angular.module('app.rental')
                    .service('pickupHours', PickupHours);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function PoleSizes() {
                    var result = [];
                    for (var i = 32; i <= 57; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.PoleSizes = PoleSizes;
                angular.module('app.rental')
                    .service('poleSizes', PoleSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalActivities() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalActivity[id] }); },
                        all: Object.keys(Rental.Models.RentalActivity)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i); })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalActivity[i] }); })
                    };
                }
                Services.RentalActivities = RentalActivities;
                angular.module('app.rental')
                    .service('rentalActivities', RentalActivities);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalCategories() {
                    return {
                        getById: function (id) { return ({ id: id, label: Rental.Models.RentalCategory[id] }); },
                        all: Object.keys(Rental.Models.RentalCategory)
                            .map(function (i) { return parseInt(i, 10); })
                            .filter(function (i) { return !isNaN(i) && i !== 0; })
                            .map(function (i) { return ({ id: i, label: Rental.Models.RentalCategory[i] }); })
                    };
                }
                Services.RentalCategories = RentalCategories;
                angular.module('app.rental')
                    .service('rentalCategories', RentalCategories);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function RentalGoals() {
                    return Object.keys(Rental.Models.RentalGoal)
                        .map(function (i) { return parseInt(i, 10); })
                        .filter(function (i) { return !isNaN(i); })
                        .map(function (i) { return ({ id: i, label: Rental.Models.RentalGoal[i] }); });
                }
                Services.RentalGoals = RentalGoals;
                angular.module('app.rental')
                    .service('rentalGoals', RentalGoals);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalAPI = (function () {
                    RentalAPI.$inject = ["$q", "$http", "configService"];
                    function RentalAPI($q, $http, configService) {
                        this.$q = $q;
                        this.$http = $http;
                        this.configService = configService;
                    }
                    RentalAPI.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals/" + rentalId,
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            var request = {
                                url: (_this.configService.API.URL + _this.configService.API.Path) + "rentals",
                                method: 'GET'
                            };
                            _this.$http(request)
                                .then(function (response) {
                                resolve(response);
                            });
                        });
                    };
                    RentalAPI.prototype.add = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'POST',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.save = function (rental) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals",
                            method: 'PUT',
                            data: rental
                        };
                        return this.$http(request);
                    };
                    RentalAPI.prototype.checkHighDemand = function (date) {
                        var request = {
                            url: (this.configService.API.URL + this.configService.API.Path) + "rentals/check_high_demand?date=" + date,
                            method: 'GET'
                        };
                        return this.$http(request);
                    };
                    return RentalAPI;
                }());
                Services.RentalAPI = RentalAPI;
                angular.module('app.rental')
                    .service('rentalAPI', RentalAPI);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                var RentalService = (function () {
                    RentalService.$inject = ["$q", "rentalAPI", "geoService"];
                    function RentalService($q, rentalAPI, geoService) {
                        this.$q = $q;
                        this.rentalAPI = rentalAPI;
                        this.geoService = geoService;
                    }
                    RentalService.prototype.get = function (rentalId) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.get(rentalId)
                                .then(function (response) {
                                resolve(new Rental.Models.Rental().serialize(response.data));
                            });
                        });
                    };
                    RentalService.prototype.getAll = function () {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.getAll()
                                .then(function (response) {
                                resolve(response.data.map(function (item) {
                                    return new Rental.Models.Rental().serialize(item);
                                }));
                            });
                        });
                    };
                    RentalService.prototype.add = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.add(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.save = function (rental) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.save(rental.deserialize())
                                .then(function () {
                                resolve();
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    RentalService.prototype.checkHighDemand = function (date) {
                        var _this = this;
                        return this.$q(function (resolve, reject) {
                            _this.rentalAPI.checkHighDemand(date.toISOString())
                                .then(function (response) {
                                resolve(response.data);
                            })
                                .catch(function () {
                                reject();
                            });
                        });
                    };
                    return RentalService;
                }());
                Services.RentalService = RentalService;
                angular.module('app.rental')
                    .service('rentalService', RentalService);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function ShoeSizes() {
                    return [1, 2, 3, 4, 4.5, 5, 5.5, 6, 6.5, 7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5,
                        11, 11.5, 12, 12.5, 13, 13.5, 14, 14.5, 15, 15.5, 16, 16.5];
                }
                Services.ShoeSizes = ShoeSizes;
                angular.module('app.rental')
                    .service('shoeSizes', ShoeSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));
/// <reference path='../../../../../typings/browser.d.ts'/>
var SkiResort;
(function (SkiResort) {
    var App;
    (function (App) {
        var Rental;
        (function (Rental) {
            var Services;
            (function (Services) {
                'use strict';
                function SkiSizes() {
                    var result = [];
                    for (var i = 115; i <= 200; i++) {
                        result.push({
                            id: i,
                            label: i + ' in'
                        });
                    }
                    ;
                    return {
                        getById: function (id) { return ({ id: id, label: id + ' in' }); },
                        all: result
                    };
                }
                Services.SkiSizes = SkiSizes;
                angular.module('app.rental')
                    .service('skiSizes', SkiSizes);
            })(Services = Rental.Services || (Rental.Services = {}));
        })(Rental = App.Rental || (App.Rental = {}));
    })(App = SkiResort.App || (SkiResort.App = {}));
})(SkiResort || (SkiResort = {}));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3d3d3Jvb3QvanMvYXBwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0EsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCO0lBQ0EsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osUUFBUSxPQUFPLE9BQU87WUFDbEI7WUFDQTtZQUNBO1lBQ0E7WUFDQTtZQUNBO1lBQ0E7O09BRUwsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSzs7MERBQ1o7UUFDQSxTQUFTLElBQUksZ0JBQWdCLE1BQU07WUFDL0IsZUFBZSxNQUFNLFlBQVksS0FBSyxNQUFNOztRQUVoRCxTQUFTLFlBQVksTUFBTTtZQUN2QixLQUFLLEtBQUs7O1FBRWQsUUFBUSxPQUFPO2FBQ1YsSUFBSTtPQUNWLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixRQUFRLE9BQU8sWUFBWTtXQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsUUFBUSxPQUFPLGNBQWM7V0FDOUIsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWjtRQUNBLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLFFBQVEsT0FBTyxZQUFZO1dBQzVCLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1o7UUFDQSxJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixRQUFRLE9BQU8sWUFBWTtXQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaO1FBQ0EsSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsUUFBUSxPQUFPLGNBQWM7V0FDOUIsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07OzJFQUNiO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCO2dCQUMxQztxQkFDSyxNQUFNLGFBQWE7b0JBQ3BCLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOzs7K0VBQ2I7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sT0FBTztvQkFDZCxLQUFLO29CQUNMLFVBQVU7b0JBQ1YsWUFBWTtvQkFDWixjQUFjO29CQUNkLGFBQWE7OztZQUdyQixTQUFTLG1CQUFtQixzQkFBc0I7Z0JBQzlDLHFCQUFxQixVQUFVLFlBQVk7O1lBRS9DLFFBQVEsT0FBTztpQkFDVixPQUFPO2lCQUNQLE9BQU87V0FDYixPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTs7MkVBQ2Y7WUFDQSxTQUFTLHFCQUFxQixnQkFBZ0I7Z0JBQzFDO3FCQUNLLE1BQU0sbUJBQW1CO29CQUMxQixLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztxQkFJcEIsTUFBTSxxQkFBcUI7b0JBQzVCLEtBQUs7b0JBQ0wsUUFBUTt3QkFDSixZQUFZOztvQkFFaEIsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7OztZQUs3QixRQUFRLE9BQU87aUJBQ1YsT0FBTztXQUNiLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNOztpR0FDYjtZQUNBLFNBQVMscUJBQXFCLGdCQUFnQixvQkFBb0I7Z0JBQzlEO3FCQUNLLE1BQU0sWUFBWTtvQkFDbkIsS0FBSztvQkFDTCxNQUFNO3dCQUNGLFVBQVU7O29CQUVkLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxZQUFZOzRCQUNaLGNBQWM7NEJBQ2QsYUFBYTs7OztnQkFJekIsbUJBQW1CLFVBQVU7O1lBRWpDLFFBQVEsT0FBTztpQkFDVixPQUFPO1dBQ2IsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07O2lHQUNiO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCLG9CQUFvQjtnQkFDOUQ7cUJBQ0ssTUFBTSx3QkFBd0I7b0JBQy9CLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLFlBQVk7NEJBQ1osY0FBYzs0QkFDZCxhQUFhOzs7O3FCQUlwQixNQUFNLDBCQUEwQjtvQkFDakMsS0FBSztvQkFDTCxPQUFPO3dCQUNILFdBQVc7NEJBQ1AsWUFBWTs0QkFDWixjQUFjOzRCQUNkLGFBQWE7Ozs7O1lBSzdCLFFBQVEsT0FBTztpQkFDVixPQUFPO1dBQ2IsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7O2lHQUNmO1lBQ0EsU0FBUyxxQkFBcUIsZ0JBQWdCLG9CQUFvQjtnQkFDOUQ7cUJBQ0ssTUFBTSxlQUFlO29CQUN0QixPQUFPO29CQUNQLEtBQUs7b0JBQ0wsT0FBTzt3QkFDSCxXQUFXOzRCQUNQLGFBQWE7NEJBQ2IsWUFBWTs0QkFDWixjQUFjOzs7O3FCQUlyQixNQUFNLHFCQUFxQjtvQkFDNUIsT0FBTztvQkFDUCxLQUFLO29CQUNMLE9BQU87d0JBQ0gsV0FBVzs0QkFDUCxhQUFhOzRCQUNiLFlBQVk7NEJBQ1osY0FBYzs7Ozs7WUFLOUIsUUFBUSxPQUFPO2lCQUNWLE9BQU87V0FDYixTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxlQUFlLFlBQVk7b0JBQzNCLFNBQVMsY0FBYzs7b0JBRXZCLE9BQU87O2dCQUVYLE9BQU8sY0FBYztlQUN0QixTQUFTLEtBQUssV0FBVyxLQUFLLFNBQVM7V0FDM0MsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsU0FBUztvQkFDaEIsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLGFBQWEsS0FBSztvQkFDbEMsUUFBUSxRQUFRLFdBQVcsS0FBSztvQkFDaEMsUUFBUSxRQUFRLFlBQVksS0FBSztvQkFDakMsUUFBUSxRQUFRLFdBQVcsS0FBSzttQkFDakMsT0FBTyxZQUFZLE9BQU8sVUFBVTtnQkFDdkMsSUFBSSxVQUFVLE9BQU87ZUFDdEIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLGNBQWM7b0JBQ3JCLGFBQWEsYUFBYSxhQUFhLEtBQUs7b0JBQzVDLGFBQWEsYUFBYSxTQUFTLEtBQUs7b0JBQ3hDLGFBQWEsYUFBYSxZQUFZLEtBQUs7b0JBQzNDLGFBQWEsYUFBYSxVQUFVLEtBQUs7bUJBQzFDLE9BQU8saUJBQWlCLE9BQU8sZUFBZTtnQkFDakQsSUFBSSxlQUFlLE9BQU87ZUFDM0IsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsSUFBSSxjQUFjLFlBQVk7b0JBQzFCLFNBQVMsYUFBYTs7b0JBRXRCLE9BQU87O2dCQUVYLE9BQU8sYUFBYTtlQUNyQixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxJQUFJLFFBQVEsWUFBWTtvQkFDcEIsU0FBUyxPQUFPOztvQkFFaEIsS0FBSyxVQUFVLFlBQVksVUFBVSxNQUFNO3dCQUN2QyxLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxPQUFPLEtBQUs7d0JBQ2pCLEtBQUssU0FBUyxLQUFLO3dCQUNuQixLQUFLLFNBQVMsS0FBSzt3QkFDbkIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssWUFBWSxLQUFLO3dCQUN0QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxjQUFjLEtBQUs7d0JBQ3hCLEtBQUssZUFBZSxLQUFLO3dCQUN6QixPQUFPOztvQkFFWCxLQUFLLFVBQVUsY0FBYyxZQUFZO3dCQUNyQyxPQUFPOzRCQUNILFFBQVEsS0FBSzs0QkFDYixNQUFNLEtBQUs7NEJBQ1gsUUFBUSxLQUFLOzRCQUNiLFFBQVEsS0FBSzs0QkFDYixVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixVQUFVLEtBQUs7NEJBQ2YsYUFBYSxLQUFLOzRCQUNsQixjQUFjLEtBQUs7OztvQkFHM0IsT0FBTzs7Z0JBRVgsT0FBTyxPQUFPO2VBQ2YsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxjQUFjLEtBQUs7b0JBQ3pDLFdBQVcsV0FBVyxrQkFBa0IsS0FBSztvQkFDN0MsV0FBVyxXQUFXLGNBQWMsS0FBSzttQkFDMUMsT0FBTyxlQUFlLE9BQU8sYUFBYTtnQkFDN0MsSUFBSSxhQUFhLE9BQU87ZUFDekIsU0FBUyxLQUFLLFdBQVcsS0FBSyxTQUFTO1dBQzNDLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFFBQVE7Z0JBQ2Y7Z0JBQ0EsQ0FBQyxVQUFVLFlBQVk7b0JBQ25CLFdBQVcsV0FBVyxhQUFhLEtBQUs7b0JBQ3hDLFdBQVcsV0FBVyxVQUFVLEtBQUs7b0JBQ3JDLFdBQVcsV0FBVyxZQUFZLEtBQUs7bUJBQ3hDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsS0FBSyxXQUFXLEtBQUssU0FBUztXQUMzQyxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2VBQ0QsU0FBUyxPQUFPLFdBQVcsT0FBTyxTQUFTO1dBQy9DLFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFVBQVU7WUFDakIsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLElBQUksVUFBVSxZQUFZO29CQUN0QixTQUFTLFNBQVM7O29CQUVsQixPQUFPLFVBQVUsWUFBWSxVQUFVLE1BQU07d0JBQ3pDLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsS0FBSyxZQUFZLElBQUksS0FBSyxLQUFLO3dCQUMvQixLQUFLLFVBQVUsSUFBSSxLQUFLLEtBQUs7d0JBQzdCLEtBQUssYUFBYSxLQUFLO3dCQUN2QixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxXQUFXLEtBQUs7d0JBQ3JCLEtBQUssT0FBTyxLQUFLO3dCQUNqQixLQUFLLFdBQVcsS0FBSzt3QkFDckIsS0FBSyxVQUFVLEtBQUs7d0JBQ3BCLEtBQUssV0FBVyxLQUFLO3dCQUNyQixLQUFLLFlBQVksS0FBSzt3QkFDdEIsT0FBTzs7b0JBRVgsT0FBTyxVQUFVLGNBQWMsWUFBWTt3QkFDdkMsT0FBTzs0QkFDSCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzRCQUNoQixXQUFXLEtBQUssVUFBVTs0QkFDMUIsU0FBUyxLQUFLLFFBQVE7NEJBQ3RCLFlBQVksS0FBSzs0QkFDakIsVUFBVSxLQUFLOzRCQUNmLFVBQVUsS0FBSzs0QkFDZixNQUFNLEtBQUs7NEJBQ1gsVUFBVSxLQUFLOzRCQUNmLFNBQVMsS0FBSzs0QkFDZCxVQUFVLEtBQUs7NEJBQ2YsV0FBVyxLQUFLOzs7b0JBR3hCLE9BQU87O2dCQUVYLE9BQU8sU0FBUztlQUNqQixTQUFTLFNBQVMsV0FBVyxTQUFTLFNBQVM7V0FDbkQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsU0FBUyxLQUFLO29CQUM1QyxlQUFlLGVBQWUsZUFBZSxLQUFLO21CQUNuRCxPQUFPLG1CQUFtQixPQUFPLGlCQUFpQjtnQkFDckQsSUFBSSxpQkFBaUIsT0FBTztlQUM3QixTQUFTLE9BQU8sV0FBVyxPQUFPLFNBQVM7V0FDL0MsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsUUFBUTtnQkFDZjtnQkFDQSxDQUFDLFVBQVUsZ0JBQWdCO29CQUN2QixlQUFlLGVBQWUsYUFBYSxLQUFLO29CQUNoRCxlQUFlLGVBQWUsY0FBYyxLQUFLO29CQUNqRCxlQUFlLGVBQWUsa0JBQWtCLEtBQUs7b0JBQ3JELGVBQWUsZUFBZSxjQUFjLEtBQUs7bUJBQ2xELE9BQU8sbUJBQW1CLE9BQU8saUJBQWlCO2dCQUNyRCxJQUFJLGlCQUFpQixPQUFPO2VBQzdCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxRQUFRO2dCQUNmO2dCQUNBLENBQUMsVUFBVSxZQUFZO29CQUNuQixXQUFXLFdBQVcsYUFBYSxLQUFLO29CQUN4QyxXQUFXLFdBQVcsVUFBVSxLQUFLO29CQUNyQyxXQUFXLFdBQVcsaUJBQWlCLEtBQUs7b0JBQzVDLFdBQVcsV0FBVyxXQUFXLEtBQUs7bUJBQ3ZDLE9BQU8sZUFBZSxPQUFPLGFBQWE7Z0JBQzdDLElBQUksYUFBYSxPQUFPO2VBQ3pCLFNBQVMsT0FBTyxXQUFXLE9BQU8sU0FBUztXQUMvQyxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O2dHQUNBLElBQUksbUJBQW1CLFlBQVk7b0JBQy9CLFNBQVMsZ0JBQWdCLGFBQWEsZUFBZTt3QkFDakQsS0FBSyxjQUFjO3dCQUNuQixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxZQUFZO3dCQUNqQixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxVQUFVOztvQkFFbkIsZ0JBQWdCLFVBQVUsUUFBUSxZQUFZO3dCQUMxQyxJQUFJLFFBQVE7d0JBQ1osS0FBSyxVQUFVO3dCQUNmLEtBQUssZ0JBQWdCO3dCQUNyQixJQUFJLEtBQUssVUFBVSxRQUFROzRCQUN2QixLQUFLLFlBQVksTUFBTSxLQUFLLFVBQVUsVUFBVSxLQUFLLFVBQVU7aUNBQzFELEtBQUssWUFBWTtnQ0FDbEIsTUFBTSxjQUFjOztpQ0FFbkIsTUFBTSxZQUFZO2dDQUNuQixNQUFNLGdCQUFnQjs7aUNBRXJCLFFBQVEsWUFBWTtnQ0FDckIsTUFBTSxVQUFVOzs7O29CQUk1QixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyxtQkFBbUI7ZUFDcEMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzt5SEFDQSxJQUFJLG9CQUFvQixZQUFZO29CQUNoQyxTQUFTLGlCQUFpQixJQUFJLFNBQVMsb0JBQW9CLGVBQWU7d0JBQ3RFLEtBQUssS0FBSzt3QkFDVixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxxQkFBcUI7d0JBQzFCLEtBQUssZ0JBQWdCOztvQkFFekIsaUJBQWlCLFVBQVUsTUFBTSxVQUFVLElBQUk7d0JBQzNDLE9BQU8sQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsaUJBQWlCOztvQkFFekYsT0FBTzs7Z0JBRVgsU0FBUyxtQkFBbUI7Z0JBQzVCLFFBQVEsT0FBTztxQkFDVixRQUFRLG9CQUFvQjtlQUNsQyxXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOztnSEFDQSxJQUFJLFdBQVcsWUFBWTtvQkFDdkIsU0FBUyxRQUFRLE9BQU8sZUFBZSw0QkFBNEI7d0JBQy9ELEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyw2QkFBNkI7O29CQUV0QyxRQUFRLFVBQVUsUUFBUSxVQUFVLFVBQVUsVUFBVTt3QkFDcEQsSUFBSSxVQUFVOzRCQUNWLEtBQUssS0FBSyxjQUFjLElBQUksTUFBTTs0QkFDbEMsUUFBUTs0QkFDUixNQUFNLEtBQUssMkJBQTJCO2dDQUNsQyxZQUFZLEtBQUssY0FBYyxlQUFlO2dDQUM5QyxXQUFXLEtBQUssY0FBYyxlQUFlO2dDQUM3QyxlQUFlLEtBQUssY0FBYyxlQUFlO2dDQUNqRCxPQUFPLEtBQUssY0FBYyxlQUFlO2dDQUN6QyxVQUFVO2dDQUNWLFVBQVU7OzRCQUVkLFNBQVM7Z0NBQ0wsZ0JBQWdCOzs7d0JBR3hCLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsT0FBTzs7Z0JBRVgsU0FBUyxVQUFVO2dCQUNuQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxXQUFXO2VBQ3pCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7O21HQUNBLElBQUksZUFBZSxZQUFZO29CQUMzQixTQUFTLFlBQVksSUFBSSxTQUFTLG9CQUFvQjt3QkFDbEQsS0FBSyxLQUFLO3dCQUNWLEtBQUssVUFBVTt3QkFDZixLQUFLLHFCQUFxQjs7b0JBRTlCLFlBQVksVUFBVSxRQUFRLFVBQVUsVUFBVSxVQUFVO3dCQUN4RCxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLE1BQU0sUUFBUSxNQUFNLFVBQVU7aUNBQ3pCLEtBQUssVUFBVSxVQUFVO2dDQUMxQixNQUFNLG1CQUFtQixjQUFjLFNBQVMsS0FBSztnQ0FDckQsT0FBTyxNQUFNLG1CQUFtQjs7aUNBRS9CLEtBQUssWUFBWTtnQ0FDbEI7O2lDQUVDLE1BQU0sVUFBVSxPQUFPO2dDQUN4QixPQUFPLE1BQU07Ozs7b0JBSXpCLE9BQU87O2dCQUVYLFNBQVMsY0FBYztnQkFDdkIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsZUFBZTtlQUM3QixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLElBQUksMkJBQTJCOzt5SEFDL0IsSUFBSSxzQkFBc0IsWUFBWTtvQkFDbEMsU0FBUyxtQkFBbUIsSUFBSSxZQUFZLE9BQU8sZUFBZSxNQUFNO3dCQUNwRSxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxhQUFhO3dCQUNsQixLQUFLLFFBQVE7d0JBQ2IsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssT0FBTzt3QkFDWixLQUFLLGNBQWM7d0JBQ25CLEtBQUssY0FBYzt3QkFDbkIsS0FBSzt3QkFDTCxJQUFJLEtBQUssYUFBYTs0QkFDbEIsS0FBSzs7O29CQUdiLG1CQUFtQixVQUFVLE9BQU8sWUFBWTt3QkFDNUMsS0FBSyxLQUFLLEtBQUs7d0JBQ2YsSUFBSSxrQkFBa0IsUUFBUSxLQUFLLEtBQUs7d0JBQ3hDLGdCQUFnQixRQUFRO3dCQUN4QixhQUFhLFFBQVEsMEJBQTBCLEtBQUssVUFBVTs0QkFDMUQsYUFBYSxLQUFLOzRCQUNsQixhQUFhOzt3QkFFakIsS0FBSyxLQUFLLEtBQUs7O29CQUVuQixtQkFBbUIsVUFBVSxPQUFPLFlBQVk7d0JBQzVDLEtBQUssS0FBSyxLQUFLO3dCQUNmLElBQUksZ0JBQWdCLGFBQWEsUUFBUTt3QkFDekMsSUFBSSxlQUFlOzRCQUNmLElBQUksYUFBYSxLQUFLLE1BQU07NEJBQzVCLEtBQUssY0FBYyxXQUFXOzRCQUM5QixLQUFLLGNBQWMsV0FBVzs0QkFDOUIsS0FBSyxXQUFXLGNBQWMsS0FBSzs0QkFDbkMsS0FBSyxLQUFLLEtBQUs7OzZCQUVkOzRCQUNELEtBQUssS0FBSyxLQUFLOzs7b0JBR3ZCLG1CQUFtQixVQUFVLFFBQVEsWUFBWTt3QkFDN0MsS0FBSyxLQUFLLEtBQUs7d0JBQ2YsS0FBSyxjQUFjO3dCQUNuQixLQUFLLGNBQWM7d0JBQ25CLEtBQUssV0FBVyxjQUFjO3dCQUM5QixhQUFhLFFBQVEsMEJBQTBCLEtBQUssVUFBVTt3QkFDOUQsS0FBSyxLQUFLLEtBQUs7O29CQUVuQixtQkFBbUIsVUFBVSxVQUFVLFlBQVk7d0JBQy9DLElBQUksUUFBUTt3QkFDWixLQUFLLEtBQUssS0FBSzt3QkFDZixJQUFJLFVBQVU7NEJBQ1YsS0FBSyxDQUFDLEtBQUssY0FBYyxJQUFJLE1BQU0sS0FBSyxjQUFjLElBQUksUUFBUTs0QkFDbEUsUUFBUTs0QkFDUixTQUFTO2dDQUNMLGlCQUFpQixZQUFZLEtBQUs7Ozt3QkFHMUMsT0FBTyxLQUFLLE1BQU07NkJBQ2IsS0FBSyxVQUFVLFVBQVU7NEJBQzFCLE1BQU0sS0FBSyxLQUFLOzRCQUNoQixNQUFNLGNBQWMsU0FBUzs0QkFDN0IsTUFBTSxXQUFXLGNBQWMsTUFBTTs0QkFDckMsTUFBTTs7NkJBRUwsTUFBTSxZQUFZOzRCQUNuQixNQUFNOzRCQUNOLE1BQU0sS0FBSyxLQUFLOzs7b0JBR3hCLE9BQU87O2dCQUVYLFNBQVMscUJBQXFCO2dCQUM5QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxzQkFBc0I7ZUFDcEMsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7eUhBQ0EsSUFBSSxrQkFBa0IsWUFBWTtvQkFDOUIsU0FBUyxlQUFlLHdCQUF3QixRQUFRLG9CQUFvQjt3QkFDeEUsS0FBSyx5QkFBeUI7d0JBQzlCLEtBQUssU0FBUzt3QkFDZCxLQUFLLHFCQUFxQjs7b0JBRTlCLGVBQWUsVUFBVSxhQUFhLFVBQVUsYUFBYTt3QkFDekQsS0FBSyxPQUFPLEdBQUc7d0JBQ2YsS0FBSyx1QkFBdUIsWUFBWTs7b0JBRTVDLGVBQWUsVUFBVSxTQUFTLFlBQVk7d0JBQzFDLEtBQUssbUJBQW1CO3dCQUN4QixLQUFLLHVCQUF1QixZQUFZOztvQkFFNUMsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsa0JBQWtCO2VBQ25DLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjtnQkFDQSxJQUFJLFVBQVUsS0FBSyxPQUFPOztrR0FDMUIsSUFBSSx5QkFBeUIsWUFBWTtvQkFDckMsU0FBUyxzQkFBc0IsZ0JBQWdCLFFBQVE7d0JBQ25ELElBQUksUUFBUTt3QkFDWixLQUFLLGlCQUFpQjt3QkFDdEIsS0FBSyxTQUFTO3dCQUNkLGVBQWUsTUFBTSxLQUFLLFVBQVUsYUFBYTs0QkFDN0MsTUFBTSxjQUFjOzs7b0JBRzVCLHNCQUFzQixVQUFVLGFBQWEsVUFBVSxJQUFJO3dCQUN2RCxPQUFPLFFBQVE7O29CQUVuQixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyx5QkFBeUI7ZUFDMUMsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFNBQVM7Z0JBQ2hCO2dCQUNBLFNBQVMsUUFBUTtvQkFDYixPQUFPLFVBQVUsT0FBTyxNQUFNLE1BQU07d0JBQ2hDLElBQUksTUFBTSxTQUFTLE1BQU07d0JBQ3pCLElBQUksTUFBTSxTQUFTLE1BQU07d0JBQ3pCLEtBQUssSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUs7NEJBQzVCLE1BQU0sS0FBSzs7d0JBRWYsT0FBTzs7O2dCQUdmLFFBQVEsT0FBTztxQkFDVixPQUFPLFlBQVk7ZUFDekIsVUFBVSxPQUFPLFlBQVksT0FBTyxVQUFVO1dBQ2xELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLGtCQUFrQjtvQkFDdkIsU0FBUyxtQkFBbUIsU0FBUyxLQUFLO3dCQUN0QyxRQUFRLEtBQUssU0FBUyw2QkFBNkIsTUFBTTs7b0JBRTdELFNBQVMsS0FBSyxPQUFPLFNBQVMsTUFBTTt3QkFDaEMsUUFBUSxTQUFTO3dCQUNqQixLQUFLLFNBQVMsYUFBYSxZQUFZOzRCQUNuQyxtQkFBbUIsU0FBUyxLQUFLOzs7b0JBR3pDLE9BQU87d0JBQ0gsTUFBTTs7O2dCQUdkLFFBQVEsT0FBTztxQkFDVixVQUFVLGFBQWE7ZUFDN0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZOztzRkFDbkIsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsbUJBQW1CO3dCQUN6QyxLQUFLLG9CQUFvQjs7b0JBRTdCLGlCQUFpQixVQUFVLFNBQVMsWUFBWTt3QkFDNUMsS0FBSyxrQkFBa0I7O29CQUUzQixpQkFBaUIsVUFBVSxTQUFTLFlBQVk7d0JBQzVDLEtBQUssa0JBQWtCOztvQkFFM0IsT0FBTzs7Z0JBRVgsU0FBUyxrQkFBa0I7b0JBQ3ZCLE9BQU87d0JBQ0gsVUFBVTt3QkFDVixPQUFPOzRCQUNILE9BQU87NEJBQ1AsU0FBUzs0QkFDVCxZQUFZOzRCQUNaLE1BQU07O3dCQUVWLGFBQWE7d0JBQ2IsWUFBWTt3QkFDWixjQUFjOzs7Z0JBR3RCLFFBQVEsT0FBTztxQkFDVixVQUFVLGFBQWE7ZUFDN0IsYUFBYSxLQUFLLGVBQWUsS0FBSyxhQUFhO1dBQ3ZELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLGtCQUFrQjtvQkFDdkIsSUFBSSxpQkFBaUI7b0JBQ3JCLFNBQVMsS0FBSyxPQUFPLFNBQVM7d0JBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLE9BQU8sS0FBSzs0QkFDbEMsUUFBUSxPQUFPLFFBQVEsUUFBUSxtQkFBbUIsaUJBQWlCLE1BQU0sVUFBVTs7d0JBRXZGLEtBQUssSUFBSSxJQUFJLE1BQU0sT0FBTyxJQUFJLE1BQU0sS0FBSyxLQUFLOzRCQUMxQyxRQUFRLE9BQU8sUUFBUSxRQUFRLG1CQUFtQixpQkFBaUIsTUFBTSxXQUFXOzs7b0JBRzVGLE9BQU87d0JBQ0gsT0FBTzs0QkFDSCxPQUFPOzRCQUNQLEtBQUs7NEJBQ0wsU0FBUzs0QkFDVCxVQUFVOzt3QkFFZCxNQUFNOzs7Z0JBR2QsUUFBUSxPQUFPO3FCQUNWLFVBQVUsYUFBYTtlQUM3QixhQUFhLEtBQUssZUFBZSxLQUFLLGFBQWE7V0FDdkQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7QUFDN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsWUFBWTs7dUZBQ25CLElBQUksb0JBQW9CLFlBQVk7b0JBQ2hDLFNBQVMsaUJBQWlCLFFBQVEsVUFBVTt3QkFDeEMsS0FBSyxTQUFTO3dCQUNkLEtBQUssV0FBVzt3QkFDaEIsS0FBSyxVQUFVOzRCQUNYLGFBQWE7O3dCQUVqQixLQUFLLFlBQVk7NEJBQ2IsT0FBTzs7O29CQUdmLGlCQUFpQixVQUFVLFlBQVksWUFBWTt3QkFDL0MsSUFBSSxLQUFLLE9BQU8sVUFBVTs0QkFDdEI7O3dCQUVKLEtBQUssU0FBUyxLQUFLLEtBQUssVUFBVSxPQUFPLFNBQVMsS0FBSyxRQUFROztvQkFFbkUsaUJBQWlCLFVBQVUsYUFBYSxZQUFZO3dCQUNoRCxLQUFLLFNBQVMsS0FBSyxLQUFLLFVBQVUsT0FBTyxZQUFZLEtBQUssUUFBUTs7b0JBRXRFLGlCQUFpQixVQUFVLGtCQUFrQixVQUFVLFFBQVE7d0JBQzNELElBQUksS0FBSyxPQUFPLFVBQVU7NEJBQ3RCOzt3QkFFSixLQUFLLE9BQU8sUUFBUTt3QkFDcEIsS0FBSzs7b0JBRVQsaUJBQWlCLFVBQVUsaUJBQWlCLFlBQVk7d0JBQ3BELElBQUksS0FBSyxPQUFPLFVBQVU7NEJBQ3RCOzt3QkFFSixLQUFLLGdCQUFnQjs7b0JBRXpCLE9BQU87O2dCQUVYLFNBQVMsa0JBQWtCO29CQUN2QixPQUFPO3dCQUNILFVBQVU7d0JBQ1YsT0FBTzs0QkFDSCxPQUFPOzRCQUNQLGFBQWE7NEJBQ2IsZUFBZTs0QkFDZixVQUFVOzRCQUNWLE1BQU07NEJBQ04sVUFBVTs0QkFDVixTQUFTOzt3QkFFYixhQUFhO3dCQUNiLFlBQVk7d0JBQ1osY0FBYzs7O2dCQUd0QixRQUFRLE9BQU87cUJBQ1YsVUFBVSxhQUFhO2VBQzdCLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxZQUFZO2dCQUNuQixTQUFTLHVCQUF1QjtvQkFDNUIsT0FBTzt3QkFDSCxPQUFPO3dCQUNQLFVBQVU7d0JBQ1YsYUFBYTt3QkFDYixZQUFZO3dCQUNaLGNBQWM7OztnQkFHdEIsUUFBUSxPQUFPO3FCQUNWLFVBQVUsa0JBQWtCO2VBQ2xDLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7O3NFQUNBLElBQUksaUJBQWlCLFlBQVk7b0JBQzdCLFNBQVMsY0FBYyxNQUFNO3dCQUN6QixLQUFLLFVBQVU7NEJBQ1gsaUJBQWlCOzRCQUNqQixhQUFhO2dDQUNULFVBQVU7Z0NBQ1YsV0FBVyxDQUFDOzs7d0JBR3BCLEtBQUssTUFBTTs0QkFDUCxLQUFLOzRCQUNMLE1BQU07O3dCQUVWLEtBQUssaUJBQWlCOzRCQUNsQixXQUFXOzRCQUNYLFVBQVU7NEJBQ1YsY0FBYzs0QkFDZCxPQUFPOzt3QkFFWCxLQUFLLEtBQUs7d0JBQ1YsSUFBSSxNQUFNLFNBQVMsYUFBYTs0QkFDNUIsS0FBSyxLQUFLOzRCQUNWLEtBQUssSUFBSSxNQUFNOzs2QkFFZDs0QkFDRCxLQUFLLEtBQUs7OztvQkFHbEIsT0FBTzs7Z0JBRVgsU0FBUyxnQkFBZ0I7Z0JBQ3pCLFFBQVEsT0FBTztxQkFDVixRQUFRLGlCQUFpQjtlQUMvQixXQUFXLEtBQUssYUFBYSxLQUFLLFdBQVc7V0FDakQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLElBQUksUUFBUTs7MEZBQ1osSUFBSSxjQUFjLFlBQVk7b0JBQzFCLFNBQVMsV0FBVyxJQUFJLGVBQWUsTUFBTTt3QkFDekMsS0FBSyxLQUFLO3dCQUNWLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLE9BQU87O29CQUVoQixXQUFXLFVBQVUsMEJBQTBCLFlBQVk7d0JBQ3ZELFFBQVEsVUFBVSxlQUFlLFVBQVUsWUFBWTs7b0JBRTNELFdBQVcsVUFBVSxjQUFjLFlBQVk7d0JBQzNDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxLQUFLLEtBQUs7NEJBQ2hCLElBQUksTUFBTSxjQUFjLFFBQVEsaUJBQWlCO2dDQUM3QyxNQUFNLEtBQUssS0FBSztnQ0FDaEIsUUFBUSxNQUFNLGNBQWMsUUFBUTs7aUNBRW5DLElBQUksTUFBTSwyQkFBMkI7Z0NBQ3RDLFVBQVUsWUFBWSxtQkFBbUIsVUFBVSxRQUFRO29DQUN2RCxRQUFRO3dDQUNKLFVBQVUsT0FBTyxPQUFPO3dDQUN4QixXQUFXLE9BQU8sT0FBTzs7bUNBRTlCLFlBQVk7b0NBQ1g7OztpQ0FHSDtnQ0FDRCxNQUFNLEtBQUssS0FBSztnQ0FDaEI7Ozs7b0JBSVosV0FBVyxVQUFVLHFCQUFxQixVQUFVLEdBQUcsR0FBRzt3QkFDdEQsSUFBSSxJQUFJO3dCQUNSLElBQUksSUFBSSxLQUFLO3dCQUNiLElBQUksSUFBSSxNQUFNLEVBQUUsQ0FBQyxFQUFFLFdBQVcsRUFBRSxZQUFZLEtBQUssSUFBSSxFQUFFLEVBQUUsV0FBVzs0QkFDaEUsRUFBRSxFQUFFLFdBQVcsTUFBTSxJQUFJLEVBQUUsQ0FBQyxFQUFFLFlBQVksRUFBRSxhQUFhLE1BQU07d0JBQ25FLElBQUksVUFBVSxRQUFRLEtBQUssS0FBSyxLQUFLLEtBQUssTUFBTTt3QkFDaEQsT0FBTyxLQUFLLE1BQU0sU0FBUyxPQUFPOztvQkFFdEMsT0FBTzs7Z0JBRVgsU0FBUyxhQUFhO2dCQUN0QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxjQUFjO2VBQzVCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OzZGQUNBLElBQUkscUJBQXFCLFlBQVk7b0JBQ2pDLFNBQVMsa0JBQWtCLFFBQVEsZUFBZTt3QkFDOUMsS0FBSyxTQUFTO3dCQUNkLEtBQUssZ0JBQWdCOztvQkFFekIsa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxLQUFLLGNBQWMsZ0JBQWdCLEVBQUUsYUFBYSxNQUFNLGFBQWE7d0JBQ3JFLEtBQUssT0FBTyxHQUFHOztvQkFFbkIsa0JBQWtCLFVBQVUsU0FBUyxZQUFZO3dCQUM3QyxJQUFJLE1BQU0sU0FBUyxNQUFNLFlBQVk7NEJBQ2pDLE9BQU8sUUFBUTs7NkJBRWQ7NEJBQ0QsS0FBSyxjQUFjOzs7b0JBRzNCLE9BQU87O2dCQUVYLFNBQVMsb0JBQW9CO2dCQUM3QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxxQkFBcUI7ZUFDbkMsV0FBVyxLQUFLLGFBQWEsS0FBSyxXQUFXO1dBQ2pELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7K0ZBQ0EsSUFBSSxrQkFBa0IsWUFBWTtvQkFDOUIsU0FBUyxlQUFlLElBQUksT0FBTyxlQUFlO3dCQUM5QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCOztvQkFFekIsZUFBZSxVQUFVLE1BQU0sWUFBWTt3QkFDdkMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxVQUFVLFNBQVM7NEJBQy9DLE9BQU8sUUFBUTs7O29CQUd2QixPQUFPOztnQkFFWCxTQUFTLGlCQUFpQjtnQkFDMUIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsa0JBQWtCO2VBQ2hDLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7Z0JBQ0EsSUFBSSxlQUFlLE9BQU8sT0FBTzs7d0dBQ2pDLElBQUksMEJBQTBCLFlBQVk7b0JBQ3RDLFNBQVMsdUJBQXVCLGNBQWMsZUFBZTt3QkFDekQsSUFBSSxRQUFRO3dCQUNaLEtBQUssZUFBZTt3QkFDcEIsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUssa0JBQWtCO3dCQUN2QixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxVQUFVO3dCQUNmLElBQUksS0FBSyxhQUFhO3dCQUN0QixJQUFJLENBQUMsYUFBYSxlQUFlOzRCQUM3QixLQUFLLGNBQWMsVUFBVSxJQUFJLEtBQUssVUFBVSxZQUFZO2dDQUN4RCxNQUFNLGFBQWE7Z0NBQ25CLE1BQU07Ozs2QkFHVDs0QkFDRCxLQUFLLGFBQWEsYUFBYTs0QkFDL0IsS0FBSzs7O29CQUdiLHVCQUF1QixVQUFVLHNCQUFzQixZQUFZO3dCQUMvRCxJQUFJLFFBQVE7d0JBQ1osS0FBSyxjQUFjLG1CQUFtQixLQUFLLFdBQVc7NkJBQ2pELEtBQUssVUFBVSxhQUFhOzRCQUM3QixNQUFNLGtCQUFrQjs0QkFDeEIsTUFBTSxVQUFVOzs7b0JBR3hCLHVCQUF1QixVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUN0RCxPQUFPLEtBQUssY0FBYyxTQUFTOztvQkFFdkMsdUJBQXVCLFVBQVUsa0JBQWtCLFVBQVUsSUFBSTt3QkFDN0QsT0FBTyxhQUFhOztvQkFFeEIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsMEJBQTBCO2VBQzNDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjtnQkFDQSxJQUFJLGVBQWUsT0FBTyxPQUFPOztrRkFDakMsSUFBSSxvQkFBb0IsWUFBWTtvQkFDaEMsU0FBUyxpQkFBaUIsZUFBZTt3QkFDckMsS0FBSyxnQkFBZ0I7d0JBQ3JCLEtBQUs7d0JBQ0wsS0FBSzt3QkFDTCxLQUFLLFVBQVU7O29CQUVuQixpQkFBaUIsVUFBVSxpQkFBaUIsWUFBWTt3QkFDcEQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixLQUFLLGNBQWM7NkJBQ2QsS0FBSyxVQUFVLGFBQWE7NEJBQzdCLE1BQU0sY0FBYzs7NkJBRW5CLFFBQVEsWUFBWTs0QkFDckIsTUFBTSxVQUFVOzs7b0JBR3hCLGlCQUFpQixVQUFVLGNBQWMsWUFBWTt3QkFDakQsS0FBSyxVQUFVLEtBQUssY0FBYzs7b0JBRXRDLGlCQUFpQixVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUNoRCxPQUFPLEtBQUssY0FBYyxTQUFTOztvQkFFdkMsaUJBQWlCLFVBQVUsa0JBQWtCLFVBQVUsSUFBSTt3QkFDdkQsT0FBTyxhQUFhOztvQkFFeEIsT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsb0JBQW9CO2VBQ3JDLGNBQWMsT0FBTyxnQkFBZ0IsT0FBTyxjQUFjO1dBQzlELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7MEZBQ0EsSUFBSSxhQUFhLFlBQVk7b0JBQ3pCLFNBQVMsVUFBVSxJQUFJLE9BQU8sZUFBZTt3QkFDekMsS0FBSyxLQUFLO3dCQUNWLEtBQUssUUFBUTt3QkFDYixLQUFLLGdCQUFnQjs7b0JBRXpCLFVBQVUsVUFBVSxTQUFTLFlBQVk7d0JBQ3JDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFROzRCQUNsRSxRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFdBQVc7d0JBQ3pELElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7aUNBQzlELGVBQWU7aUNBQ2YsZ0JBQWdCOzRCQUNyQixRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLHFCQUFxQixVQUFVLFlBQVk7d0JBQzNELElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLGlDQUFpQzs0QkFDbkcsUUFBUTs7d0JBRVosT0FBTyxLQUFLLE1BQU0sU0FBUyxLQUFLLFVBQVUsU0FBUzs0QkFDL0MsT0FBTyxRQUFROzs7b0JBR3ZCLFVBQVUsVUFBVSxZQUFZLFVBQVUsSUFBSTt3QkFDMUMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVEsaUJBQWlCOzRCQUNuRixRQUFROzt3QkFFWixPQUFPLEtBQUssTUFBTSxTQUFTLEtBQUssVUFBVSxTQUFTOzRCQUMvQyxPQUFPLFFBQVE7OztvQkFHdkIsVUFBVSxVQUFVLFdBQVcsVUFBVSxJQUFJO3dCQUN6QyxPQUFPLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLHVCQUF1Qjs7b0JBRS9GLE9BQU87O2dCQUVYLFNBQVMsWUFBWTtnQkFDckIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsYUFBYTtlQUMzQixXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzsrRkFDQSxJQUFJLGlCQUFpQixZQUFZO29CQUM3QixTQUFTLGNBQWMsSUFBSSxXQUFXLFlBQVk7d0JBQzlDLEtBQUssS0FBSzt3QkFDVixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssYUFBYTt3QkFDbEIsS0FBSyxXQUFXO3dCQUNoQixLQUFLLFlBQVk7O29CQUVyQixjQUFjLFVBQVUsY0FBYyxVQUFVLFVBQVUsV0FBVzt3QkFDakUsT0FBTyxLQUFLLFdBQVcsbUJBQW1CLEVBQUUsVUFBVSxVQUFVLFdBQVcsYUFBYSxFQUFFLFVBQVUsS0FBSyxVQUFVLFdBQVcsS0FBSzs7b0JBRXZJLGNBQWMsVUFBVSxxQkFBcUIsVUFBVSxhQUFhO3dCQUNoRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLElBQUksR0FBRyxLQUFLOzRCQUNoRCxZQUFZLEdBQUcsV0FBVyxLQUFLLFlBQVksWUFBWSxHQUFHLFVBQVUsWUFBWSxHQUFHOzt3QkFFdkYsT0FBTzs7b0JBRVgsY0FBYyxVQUFVLFNBQVMsWUFBWTt3QkFDekMsT0FBTyxLQUFLLFVBQVU7O29CQUUxQixjQUFjLFVBQVUsVUFBVSxZQUFZO3dCQUMxQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTOzRCQUM5QixPQUFPLE1BQU0sV0FBVztpQ0FDbkIsS0FBSyxVQUFVLFFBQVE7Z0NBQ3hCLE1BQU0sV0FBVyxPQUFPO2dDQUN4QixNQUFNLFlBQVksT0FBTztnQ0FDekIsT0FBTyxNQUFNLFVBQVUsUUFBUSxNQUFNLFVBQVUsTUFBTSxXQUFXLEtBQUssVUFBVSxhQUFhO29DQUN4RixPQUFPLFFBQVEsTUFBTSxtQkFBbUI7Ozs7O29CQUt4RCxjQUFjLFVBQVUscUJBQXFCLFVBQVUsYUFBYTt3QkFDaEUsSUFBSSxRQUFRO3dCQUNaLElBQUkscUJBQXFCLFlBQVksTUFBTTt3QkFDM0MsSUFBSSxhQUFhLG1CQUFtQixtQkFBbUIsU0FBUzt3QkFDaEUsT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTOzRCQUM5QixPQUFPLE1BQU0sVUFBVSxtQkFBbUIsWUFBWSxLQUFLLFVBQVUsS0FBSztnQ0FDdEUsSUFBSSxjQUFjO2dDQUNsQixJQUFJLFdBQVc7Z0NBQ2YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxJQUFJLEdBQUcsS0FBSztvQ0FDeEMsU0FBUyxLQUFLLENBQUMsWUFBWTt3Q0FDdkIsT0FBTyxNQUFNLFVBQVUsSUFBSSxJQUFJLEtBQUssVUFBVSxZQUFZOzRDQUN0RCxZQUFZLEtBQUs7Ozs7Z0NBSTdCLE1BQU0sR0FBRyxJQUFJLFVBQVUsS0FBSyxZQUFZO29DQUNwQyxRQUFROzs7OztvQkFLeEIsY0FBYyxVQUFVLFlBQVksVUFBVSxJQUFJO3dCQUM5QyxPQUFPLEtBQUssVUFBVSxVQUFVOztvQkFFcEMsY0FBYyxVQUFVLGFBQWEsWUFBWTt3QkFDN0MsT0FBTzs0QkFDSCxFQUFFLElBQUksV0FBVyxPQUFPOzRCQUN4QixFQUFFLElBQUksZ0JBQWdCLE9BQU87NEJBQzdCLEVBQUUsSUFBSSxjQUFjLE9BQU87NEJBQzNCLEVBQUUsSUFBSSxZQUFZLE9BQU87NEJBQ3pCLEVBQUUsSUFBSSxtQkFBbUIsT0FBTzs7O29CQUd4QyxjQUFjLFVBQVUsV0FBVyxVQUFVLElBQUk7d0JBQzdDLE9BQU8sS0FBSyxVQUFVLFNBQVM7O29CQUVuQyxPQUFPOztnQkFFWCxTQUFTLGdCQUFnQjtnQkFDekIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsaUJBQWlCO2VBQy9CLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiOztvR0FDQSxJQUFJLGtCQUFrQixZQUFZO2dCQUM5QixTQUFTLGVBQWUsUUFBUSxhQUFhLGtCQUFrQjtvQkFDM0QsS0FBSyxTQUFTO29CQUNkLEtBQUssY0FBYztvQkFDbkIsS0FBSyxtQkFBbUI7O2dCQUU1QixlQUFlLFVBQVUsV0FBVyxVQUFVLElBQUk7b0JBQzlDLE9BQU8sS0FBSyxpQkFBaUIsSUFBSTs7Z0JBRXJDLE9BQU87O1lBRVgsUUFBUSxPQUFPO2lCQUNWLFdBQVcsa0JBQWtCO1dBQ25DLE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZO0FBQzdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFlBQVk7Z0JBQ25CLFNBQVMsb0JBQW9CO29CQUN6QixPQUFPO3dCQUNILFVBQVU7d0JBQ1YsYUFBYTs7O2dCQUdyQixRQUFRLE9BQU87cUJBQ1YsVUFBVSxlQUFlO2VBQy9CLGFBQWEsS0FBSyxlQUFlLEtBQUssYUFBYTtXQUN2RCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O2tJQUNBLElBQUksOEJBQThCLFlBQVk7b0JBQzFDLFNBQVMsMkJBQTJCLGFBQWEsY0FBYyxZQUFZLFFBQVE7d0JBQy9FLElBQUksUUFBUTt3QkFDWixLQUFLLGNBQWM7d0JBQ25CLEtBQUssZUFBZTt3QkFDcEIsS0FBSyxhQUFhO3dCQUNsQixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxVQUFVO3dCQUNmLEtBQUssa0JBQWtCO3dCQUN2QixLQUFLLFdBQVc7d0JBQ2hCLEtBQUs7d0JBQ0wsT0FBTyxPQUFPLFlBQVk7NEJBQ3RCLE1BQU07OztvQkFHZCwyQkFBMkIsVUFBVSxVQUFVLFlBQVk7d0JBQ3ZELElBQUksUUFBUTt3QkFDWixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxZQUFZLElBQUksS0FBSyxhQUFhOzZCQUNsQyxLQUFLLFVBQVUsTUFBTTs0QkFDdEIsTUFBTSxPQUFPOzs2QkFFWixNQUFNLFlBQVk7Ozs2QkFHbEIsUUFBUSxZQUFZOzRCQUNyQixNQUFNLFVBQVU7OztvQkFHeEIsMkJBQTJCLFVBQVUsY0FBYyxZQUFZO3dCQUMzRCxJQUFJLFFBQVE7d0JBQ1osSUFBSSxLQUFLLGlCQUFpQjs0QkFDdEIsS0FBSzs7NkJBRUo7NEJBQ0QsS0FBSyxXQUFXO2lDQUNYLEtBQUssVUFBVSxNQUFNO2dDQUN0QixNQUFNLGtCQUFrQjtnQ0FDeEIsTUFBTTs7OztvQkFJbEIsMkJBQTJCLFVBQVUsZUFBZSxZQUFZO3dCQUM1RCxJQUFJLEtBQUssTUFBTTs0QkFDWCxLQUFLLFdBQVcsS0FBSyxXQUFXLG1CQUFtQixLQUFLLGlCQUFpQixFQUFFLFVBQVUsS0FBSyxLQUFLLFVBQVUsV0FBVyxLQUFLLEtBQUs7OztvQkFHdEksT0FBTzs7Z0JBRVgsUUFBUSxPQUFPO3FCQUNWLFdBQVcsOEJBQThCO2VBQy9DLGNBQWMsS0FBSyxnQkFBZ0IsS0FBSyxjQUFjO1dBQzFELE9BQU8sSUFBSSxTQUFTLElBQUksT0FBTztPQUNuQyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxNQUFNO1lBQ2IsSUFBSTtZQUNKLENBQUMsVUFBVSxhQUFhO2dCQUNwQjs7d0ZBQ0EsSUFBSSw0QkFBNEIsWUFBWTtvQkFDeEMsU0FBUyx5QkFBeUIsYUFBYTt3QkFDM0MsS0FBSyxjQUFjO3dCQUNuQixLQUFLOztvQkFFVCx5QkFBeUIsVUFBVSxXQUFXLFlBQVk7d0JBQ3RELElBQUksUUFBUTt3QkFDWixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxZQUFZOzZCQUNaLEtBQUssVUFBVSxNQUFNOzRCQUN0QixNQUFNLFlBQVk7OzZCQUVqQixRQUFRLFlBQVk7NEJBQ3JCLE1BQU0sVUFBVTs7O29CQUd4Qix5QkFBeUIsVUFBVSxjQUFjLFVBQVUsT0FBTzt3QkFDOUQsSUFBSSxRQUFRO3dCQUNaLEtBQUssWUFBWTt3QkFDakIsS0FBSyxjQUFjO3dCQUNuQixNQUFNLFFBQVEsVUFBVSxNQUFNOzRCQUMxQixJQUFJLEtBQUssV0FBVyxLQUFLLE9BQU8sV0FBVyxNQUFNO2dDQUM3QyxNQUFNLFVBQVUsS0FBSzs7aUNBRXBCLElBQUksS0FBSyxXQUFXLEtBQUssT0FBTyxXQUFXLFFBQVE7Z0NBQ3BELE1BQU0sWUFBWSxLQUFLOzs7O29CQUluQyxPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyw0QkFBNEI7ZUFDN0MsY0FBYyxLQUFLLGdCQUFnQixLQUFLLGNBQWM7V0FDMUQsT0FBTyxJQUFJLFNBQVMsSUFBSSxPQUFPO09BQ25DLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLE1BQU07WUFDYixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCOzt3RkFDQSxJQUFJLFdBQVcsWUFBWTtvQkFDdkIsU0FBUyxRQUFRLElBQUksT0FBTyxlQUFlO3dCQUN2QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxRQUFRO3dCQUNiLEtBQUssZ0JBQWdCOztvQkFFekIsUUFBUSxVQUFVLFNBQVMsWUFBWTt3QkFDbkMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxJQUFJLFVBQVU7Z0NBQ1YsS0FBSyxDQUFDLE1BQU0sY0FBYyxJQUFJLE1BQU0sTUFBTSxjQUFjLElBQUksUUFBUTtnQ0FDcEUsUUFBUTs7NEJBRVosTUFBTSxNQUFNO2lDQUNQLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFROzs7O29CQUlwQixRQUFRLFVBQVUsVUFBVSxVQUFVLFVBQVUsV0FBVzt3QkFDdkQsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxJQUFJLFVBQVU7Z0NBQ1YsS0FBSyxDQUFDLENBQUMsTUFBTSxjQUFjLElBQUksTUFBTSxNQUFNLGNBQWMsSUFBSSxRQUFRO3FDQUNoRSxlQUFlO3FDQUNmLGdCQUFnQjtnQ0FDckIsUUFBUTs7NEJBRVosTUFBTSxNQUFNO2lDQUNQLEtBQUssU0FBUzs7O29CQUczQixRQUFRLFVBQVUsTUFBTSxVQUFVLElBQUk7d0JBQ2xDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLFdBQVc7NEJBQzdFLFFBQVE7O3dCQUVaLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsT0FBTzs7Z0JBRVgsU0FBUyxVQUFVO2dCQUNuQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxXQUFXO2VBQ3pCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsTUFBTTtZQUNiLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OzJGQUNBLElBQUksZUFBZSxZQUFZO29CQUMzQixTQUFTLFlBQVksSUFBSSxTQUFTLFlBQVk7d0JBQzFDLEtBQUssS0FBSzt3QkFDVixLQUFLLFVBQVU7d0JBQ2YsS0FBSyxhQUFhOztvQkFFdEIsWUFBWSxVQUFVLFNBQVMsWUFBWTt3QkFDdkMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFFBQVE7aUNBQ1QsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVEsU0FBUyxLQUFLLElBQUksVUFBVSxNQUFNO29DQUN0QyxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sVUFBVTs7Ozs7b0JBS3hELFlBQVksVUFBVSxVQUFVLFlBQVk7d0JBQ3hDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxXQUFXO2lDQUNaLEtBQUssVUFBVSxRQUFRO2dDQUN4QixPQUFPLE1BQU0sUUFBUSxRQUFRLE9BQU8sVUFBVSxPQUFPOztpQ0FFcEQsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVEsU0FBUyxLQUFLLElBQUksVUFBVSxNQUFNO29DQUN0QyxPQUFPLElBQUksS0FBSyxPQUFPLE9BQU8sVUFBVTs7O2lDQUczQyxNQUFNOzs7b0JBR25CLFlBQVksVUFBVSxNQUFNLFVBQVUsSUFBSTt3QkFDdEMsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFFBQVEsSUFBSTtpQ0FDYixLQUFLLFVBQVUsUUFBUTtnQ0FDeEIsUUFBUSxJQUFJLEtBQUssT0FBTyxPQUFPLFVBQVUsT0FBTzs7aUNBRS9DLE1BQU07OztvQkFHbkIsT0FBTzs7Z0JBRVgsU0FBUyxjQUFjO2dCQUN2QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxlQUFlO2VBQzdCLFdBQVcsS0FBSyxhQUFhLEtBQUssV0FBVztXQUNqRCxPQUFPLElBQUksU0FBUyxJQUFJLE9BQU87T0FDbkMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsYUFBYTtnQkFDcEI7O3FQQUNBLElBQUksNEJBQTRCLFlBQVk7b0JBQ3hDLFNBQVMseUJBQXlCLFFBQVEsZUFBZSxrQkFBa0Isa0JBQWtCLGFBQWEsV0FBVyxVQUFVLFdBQVcsY0FBYyxhQUFhLG1CQUFtQjt3QkFDcEwsSUFBSSxRQUFRO3dCQUNaLEtBQUssU0FBUzt3QkFDZCxLQUFLLGdCQUFnQjt3QkFDckIsS0FBSyxtQkFBbUI7d0JBQ3hCLEtBQUssbUJBQW1CO3dCQUN4QixLQUFLLGNBQWM7d0JBQ25CLEtBQUssWUFBWTt3QkFDakIsS0FBSyxXQUFXO3dCQUNoQixLQUFLLFlBQVk7d0JBQ2pCLEtBQUssZUFBZTt3QkFDcEIsS0FBSyxjQUFjO3dCQUNuQixLQUFLLG9CQUFvQjt3QkFDekIsS0FBSyxVQUFVO3dCQUNmLEtBQUssa0JBQWtCOzt3QkFFdkIsS0FBSyxTQUFTLElBQUksT0FBTyxPQUFPO3dCQUNoQyxLQUFLLFlBQVk7O3dCQUVqQixJQUFJLGFBQWEsVUFBVTs0QkFDdkIsS0FBSzs7NkJBRUo7NEJBQ0QsS0FBSzs7O3dCQUdULE9BQU8sWUFBWSxJQUFJO3dCQUN2QixPQUFPLFVBQVUsU0FBUzt3QkFDMUIsT0FBTyxVQUFVLFdBQVc7d0JBQzVCLE9BQU8sVUFBVSxXQUFXOzs7Ozs7d0JBTTVCLE9BQU8sWUFBWTs0QkFDZixLQUFLOzRCQUNMLE1BQU07Ozs7Ozt3QkFNVixPQUFPLGFBQWE7NEJBQ2hCLFVBQVU7NEJBQ1YsVUFBVTs0QkFDVixVQUFVOzRCQUNWLFNBQVM7Ozt3QkFHYixPQUFPLGlCQUFpQixhQUFhLFlBQVk7NEJBQzdDLElBQUksQ0FBQyxPQUFPLFVBQVUsS0FBSztnQ0FDdkI7OzRCQUVKLE1BQU0sT0FBTyxZQUFZLFFBQVEsS0FBSyxPQUFPLFVBQVU7NEJBQ3ZELElBQUksT0FBTyxVQUFVLE1BQU07Z0NBQ3ZCLE1BQU0sT0FBTyxVQUFVLFNBQVMsT0FBTyxVQUFVLEtBQUs7Z0NBQ3RELE1BQU0sT0FBTyxVQUFVLFdBQVcsT0FBTyxVQUFVLEtBQUs7OzRCQUU1RCxNQUFNOzs7d0JBR1YsT0FBTyxpQkFBaUIsY0FBYyxZQUFZOzRCQUM5QyxNQUFNLE9BQU8sV0FBVyxPQUFPLFdBQVcsV0FBVyxPQUFPLFdBQVcsU0FBUyxLQUFLOzRCQUNyRixNQUFNLE9BQU8sV0FBVyxPQUFPLFdBQVcsV0FBVyxPQUFPLFdBQVcsU0FBUyxLQUFLOzRCQUNyRixNQUFNLE9BQU8sV0FBVyxPQUFPLFdBQVcsV0FBVyxPQUFPLFdBQVcsU0FBUyxLQUFLOzRCQUNyRixNQUFNLE9BQU8sVUFBVSxPQUFPLFdBQVcsVUFBVSxPQUFPLFdBQVcsUUFBUSxLQUFLOzs7b0JBRzFGLHlCQUF5QixVQUFVLFlBQVksWUFBWTt3QkFDdkQsSUFBSSxRQUFRO3dCQUNaLEtBQUssVUFBVTt3QkFDZixLQUFLLGNBQWMsSUFBSSxLQUFLLGFBQWE7NkJBQ3BDLEtBQUssVUFBVSxRQUFROzRCQUN4QixNQUFNLFNBQVM7NEJBQ2YsTUFBTTs0QkFDTixNQUFNLFVBQVU7Ozs7Ozs7b0JBT3hCLHlCQUF5QixVQUFVLGlCQUFpQixZQUFZO3dCQUM1RCxJQUFJLFFBQVEsS0FBSyxPQUFPLFVBQVU7d0JBQ2xDLElBQUksVUFBVSxLQUFLLE9BQU8sVUFBVTt3QkFDcEMsS0FBSyxPQUFPLFlBQVk7NEJBQ3BCLEtBQUssS0FBSyxPQUFPOzRCQUNqQixNQUFNLEtBQUssWUFBWSxRQUFRLENBQUMsUUFBUSxNQUFNOzt3QkFFbEQsS0FBSyxPQUFPLGFBQWE7NEJBQ3JCLFVBQVUsS0FBSyxpQkFBaUIsUUFBUSxLQUFLLE9BQU87NEJBQ3BELFVBQVUsS0FBSyxpQkFBaUIsUUFBUSxLQUFLLE9BQU87NEJBQ3BELFVBQVUsS0FBSyxVQUFVLFFBQVEsS0FBSyxPQUFPOzRCQUM3QyxTQUFTLEtBQUssU0FBUyxRQUFRLEtBQUssT0FBTzs7Ozs7OztvQkFPbkQseUJBQXlCLFVBQVUsY0FBYyxZQUFZO3dCQUN6RCxLQUFLLFNBQVMsSUFBSSxPQUFPLE9BQU87d0JBQ2hDLEtBQUssSUFBSSxLQUFLLEtBQUssT0FBTyxXQUFXOzRCQUNqQyxJQUFJLEtBQUssT0FBTyxVQUFVLGVBQWUsSUFBSTtnQ0FDekMsS0FBSyxPQUFPLFVBQVUsS0FBSzs7O3dCQUduQyxLQUFLLElBQUksS0FBSyxLQUFLLE9BQU8sWUFBWTs0QkFDbEMsSUFBSSxLQUFLLE9BQU8sV0FBVyxlQUFlLElBQUk7Z0NBQzFDLEtBQUssT0FBTyxXQUFXLEtBQUs7Ozs7b0JBSXhDLHlCQUF5QixVQUFVLFdBQVcsWUFBWTt3QkFDdEQsS0FBSyxPQUFPLE1BQU07O29CQUV0Qix5QkFBeUIsVUFBVSxvQkFBb0IsWUFBWTt3QkFDL0QsSUFBSSxRQUFRO3dCQUNaLElBQUksS0FBSyxXQUFXLFFBQVE7NEJBQ3hCLEtBQUssVUFBVTs0QkFDZixJQUFJLGdCQUFnQjs0QkFDcEIsSUFBSSxLQUFLLGFBQWEsVUFBVTtnQ0FDNUIsZ0JBQWdCLEtBQUs7O2lDQUVwQjtnQ0FDRCxnQkFBZ0IsS0FBSzs7NEJBRXpCO2lDQUNLLFFBQVEsWUFBWTtnQ0FDckIsTUFBTSxVQUFVOzs7O29CQUk1Qix5QkFBeUIsVUFBVSxpQkFBaUIsWUFBWTt3QkFDNUQsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxjQUFjLElBQUksS0FBSzs2QkFDOUIsS0FBSyxZQUFZOzRCQUNsQixNQUFNOzRCQUNOLE1BQU0sV0FBVzs0QkFDakIsTUFBTSxXQUFXOzRCQUNqQixNQUFNOzs7b0JBR2QseUJBQXlCLFVBQVUsa0JBQWtCLFlBQVk7d0JBQzdELElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssY0FBYyxLQUFLLEtBQUs7NkJBQy9CLEtBQUssWUFBWTs0QkFDbEIsTUFBTSxrQkFBa0I7OztvQkFHaEMseUJBQXlCLFVBQVUsa0JBQWtCLFlBQVk7d0JBQzdELElBQUksUUFBUTt3QkFDWixLQUFLLGNBQWMsZ0JBQWdCLEtBQUssT0FBTzs2QkFDMUMsS0FBSyxVQUFVLFFBQVE7NEJBQ3hCLE1BQU0sa0JBQWtCOzs2QkFFdkIsTUFBTSxZQUFZOzs7O29CQUkzQix5QkFBeUIsVUFBVSxvQkFBb0IsWUFBWTt3QkFDL0QsS0FBSyxPQUFPLFlBQVk7d0JBQ3hCLElBQUksS0FBSyxPQUFPLGFBQWEsS0FBSyxPQUFPLFNBQVM7NEJBQzlDLEtBQUssT0FBTyxZQUFZOzRCQUN4QixJQUFJLE9BQU8sS0FBSyxNQUFNLENBQUMsS0FBSyxPQUFPLFFBQVEsWUFBWSxLQUFLLE9BQU8sVUFBVSxhQUFhLE9BQU8sS0FBSyxLQUFLOzRCQUMzRyxLQUFLLE9BQU8sWUFBWSxLQUFLLE9BQU8sYUFBYSxPQUFPOzt3QkFFNUQsT0FBTyxLQUFLLE9BQU87O29CQUV2QixPQUFPOztnQkFFWCxRQUFRLE9BQU87cUJBQ1YsV0FBVyw0QkFBNEI7ZUFDN0MsY0FBYyxPQUFPLGdCQUFnQixPQUFPLGNBQWM7V0FDOUQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCOztrSEFDQSxJQUFJLHFCQUFxQixZQUFZO29CQUNqQyxTQUFTLGtCQUFrQixvQkFBb0IsUUFBUSxjQUFjO3dCQUNqRSxLQUFLLHFCQUFxQjt3QkFDMUIsS0FBSyxTQUFTO3dCQUNkLEtBQUssZUFBZTt3QkFDcEIsT0FBTyxJQUFJLGdCQUFnQixZQUFZOzRCQUNuQyxtQkFBbUIsYUFBYSxnQkFBZ0IsT0FBTzs0QkFDdkQsT0FBTyxXQUFXOzs7b0JBRzFCLE9BQU87O2dCQUVYLFlBQVksb0JBQW9CO2dCQUNoQyxRQUFRLE9BQU87cUJBQ1YsV0FBVyxxQkFBcUI7ZUFDdEMsY0FBYyxPQUFPLGdCQUFnQixPQUFPLGNBQWM7V0FDOUQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLGFBQWE7Z0JBQ3BCOzsySEFDQSxJQUFJLDZCQUE2QixZQUFZO29CQUN6QyxTQUFTLDBCQUEwQixRQUFRLGVBQWUsUUFBUSxVQUFVO3dCQUN4RSxJQUFJLFFBQVE7d0JBQ1osS0FBSyxTQUFTO3dCQUNkLEtBQUssZ0JBQWdCO3dCQUNyQixLQUFLLFNBQVM7d0JBQ2QsS0FBSyxXQUFXO3dCQUNoQixLQUFLLGNBQWM7d0JBQ25CLEtBQUs7d0JBQ0wsT0FBTyxJQUFJLDJCQUEyQixZQUFZOzRCQUM5QyxNQUFNO2lDQUNELFFBQVEsWUFBWTtnQ0FDckIsTUFBTSxjQUFjOzs7O29CQUloQywwQkFBMEIsVUFBVSxhQUFhLFlBQVk7d0JBQ3pELElBQUksUUFBUTt3QkFDWixLQUFLLFVBQVU7d0JBQ2YsT0FBTyxLQUFLLGNBQWM7NkJBQ3JCLEtBQUssVUFBVSxNQUFNOzRCQUN0QixNQUFNLFVBQVU7OzZCQUVmLFFBQVEsWUFBWTs0QkFDckIsTUFBTSxVQUFVOzs7b0JBR3hCLDBCQUEwQixVQUFVLG1CQUFtQixVQUFVLFFBQVE7d0JBQ3JFLElBQUksUUFBUTt3QkFDWixLQUFLLG1CQUFtQjt3QkFDeEIsS0FBSyxTQUFTLFlBQVk7NEJBQ3RCLE1BQU0sT0FBTyxHQUFHLHFCQUFxQixFQUFFLFVBQVUsT0FBTzsyQkFDekQ7O29CQUVQLE9BQU87O2dCQUVYLFFBQVEsT0FBTztxQkFDVixXQUFXLDZCQUE2QjtlQUM5QyxjQUFjLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztXQUM5RCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsU0FBUztnQkFDaEI7Z0JBQ0EsU0FBUyx1QkFBdUI7b0JBQzVCLE9BQU8sVUFBVSxPQUFPO3dCQUNwQixPQUFPLE9BQU8sT0FBTyxlQUFlOzs7Z0JBRzVDLFFBQVEsT0FBTztxQkFDVixPQUFPLHFCQUFxQjtlQUNsQyxVQUFVLE9BQU8sWUFBWSxPQUFPLFVBQVU7V0FDbEQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFNBQVM7Z0JBQ2hCO2dCQUNBLFNBQVMsdUJBQXVCO29CQUM1QixPQUFPLFVBQVUsT0FBTzt3QkFDcEIsT0FBTyxPQUFPLE9BQU8sZUFBZTs7O2dCQUc1QyxRQUFRLE9BQU87cUJBQ1YsT0FBTyxxQkFBcUI7ZUFDbEMsVUFBVSxPQUFPLFlBQVksT0FBTyxVQUFVO1dBQ2xELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxJQUFJLGVBQWUsWUFBWTtvQkFDM0IsU0FBUyxjQUFjO3dCQUNuQixLQUFLLE1BQU07O29CQUVmLFlBQVksVUFBVSxVQUFVLFVBQVUsR0FBRzt3QkFDekMsSUFBSSxTQUFTLEtBQUssTUFBTSxJQUFJO3dCQUM1QixJQUFJLFdBQVcsS0FBSyxTQUFTO3dCQUM3QixJQUFJLFFBQVE7d0JBQ1osSUFBSSxVQUFVO3dCQUNkLElBQUksTUFBTTt3QkFDVixJQUFJLFFBQVEsSUFBSTs0QkFDWixRQUFRLFFBQVE7NEJBQ2hCLE1BQU07O3dCQUVWLElBQUksWUFBWSxNQUFNO3dCQUN0QixJQUFJLGNBQWMsUUFBUTt3QkFDMUIsSUFBSSxVQUFVLFdBQVcsR0FBRzs0QkFDeEIsWUFBWSxNQUFNOzt3QkFFdEIsSUFBSSxZQUFZLFdBQVcsR0FBRzs0QkFDMUIsY0FBYyxNQUFNOzt3QkFFeEIsT0FBTzs0QkFDSCxJQUFJOzRCQUNKLE9BQU8sWUFBWSxNQUFNLGNBQWMsTUFBTTs0QkFDN0MsT0FBTzs0QkFDUCxTQUFTOzs7b0JBR2pCLFlBQVksVUFBVSxjQUFjLFlBQVk7d0JBQzVDLElBQUksU0FBUzt3QkFDYixJQUFJLGFBQWE7d0JBQ2pCLElBQUksYUFBYTt3QkFDakIsSUFBSSxRQUFRO3dCQUNaLEtBQUssSUFBSSxJQUFJLFlBQVksS0FBSyxZQUFZLElBQUksSUFBSSxPQUFPOzRCQUNyRCxPQUFPLEtBQUssS0FBSyxRQUFROzt3QkFFN0IsS0FBSyxNQUFNOztvQkFFZixPQUFPOztnQkFFWCxTQUFTLGNBQWM7Z0JBQ3ZCLFFBQVEsT0FBTztxQkFDVixRQUFRLGVBQWU7ZUFDN0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLFlBQVk7b0JBQ2pCLElBQUksU0FBUztvQkFDYixLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLO3dCQUMzQixPQUFPLEtBQUs7NEJBQ1IsSUFBSTs0QkFDSixPQUFPLElBQUk7OztvQkFHbkI7b0JBQ0EsT0FBTzt3QkFDSCxTQUFTLFVBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksT0FBTyxLQUFLO3dCQUN2RCxLQUFLOzs7Z0JBR2IsU0FBUyxZQUFZO2dCQUNyQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxhQUFhO2VBQzNCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxtQkFBbUI7b0JBQ3hCLE9BQU87d0JBQ0gsU0FBUyxVQUFVLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxJQUFJLE9BQU8sT0FBTyxPQUFPLGVBQWU7d0JBQy9FLEtBQUssT0FBTyxLQUFLLE9BQU8sT0FBTzs2QkFDMUIsSUFBSSxVQUFVLEdBQUcsRUFBRSxPQUFPLFNBQVMsR0FBRzs2QkFDdEMsT0FBTyxVQUFVLEdBQUcsRUFBRSxPQUFPLENBQUMsTUFBTTs2QkFDcEMsSUFBSSxVQUFVLEdBQUcsRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLE9BQU8sT0FBTyxPQUFPLGVBQWU7OztnQkFHckYsU0FBUyxtQkFBbUI7Z0JBQzVCLFFBQVEsT0FBTztxQkFDVixRQUFRLG9CQUFvQjtlQUNsQyxXQUFXLE9BQU8sYUFBYSxPQUFPLFdBQVc7V0FDckQsU0FBUyxJQUFJLFdBQVcsSUFBSSxTQUFTO09BQ3pDLE1BQU0sVUFBVSxRQUFRLFVBQVUsTUFBTTtHQUM1QyxjQUFjLFlBQVk7O0FBRTdCLElBQUk7QUFDSixDQUFDLFVBQVUsV0FBVztJQUNsQixJQUFJO0lBQ0osQ0FBQyxVQUFVLEtBQUs7UUFDWixJQUFJO1FBQ0osQ0FBQyxVQUFVLFFBQVE7WUFDZixJQUFJO1lBQ0osQ0FBQyxVQUFVLFVBQVU7Z0JBQ2pCO2dCQUNBLFNBQVMsbUJBQW1CO29CQUN4QixPQUFPO3dCQUNILFNBQVMsVUFBVSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksSUFBSSxPQUFPLE9BQU8sT0FBTyxlQUFlO3dCQUMvRSxLQUFLLE9BQU8sS0FBSyxPQUFPLE9BQU87NkJBQzFCLElBQUksVUFBVSxHQUFHLEVBQUUsT0FBTyxTQUFTLEdBQUc7NkJBQ3RDLE9BQU8sVUFBVSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU0sTUFBTSxNQUFNOzZCQUNoRCxJQUFJLFVBQVUsR0FBRyxFQUFFLFFBQVEsRUFBRSxJQUFJLEdBQUcsT0FBTyxPQUFPLE9BQU8sZUFBZTs7O2dCQUdyRixTQUFTLG1CQUFtQjtnQkFDNUIsUUFBUSxPQUFPO3FCQUNWLFFBQVEsb0JBQW9CO2VBQ2xDLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7Z0JBQ0EsU0FBUyxjQUFjO29CQUNuQixPQUFPLE9BQU8sS0FBSyxPQUFPLE9BQU87eUJBQzVCLElBQUksVUFBVSxHQUFHLEVBQUUsT0FBTyxTQUFTLEdBQUc7eUJBQ3RDLE9BQU8sVUFBVSxHQUFHLEVBQUUsT0FBTyxDQUFDLE1BQU07eUJBQ3BDLElBQUksVUFBVSxHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksR0FBRyxPQUFPLE9BQU8sT0FBTyxXQUFXOztnQkFFN0UsU0FBUyxjQUFjO2dCQUN2QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxlQUFlO2VBQzdCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTs7QUFFN0IsSUFBSTtBQUNKLENBQUMsVUFBVSxXQUFXO0lBQ2xCLElBQUk7SUFDSixDQUFDLFVBQVUsS0FBSztRQUNaLElBQUk7UUFDSixDQUFDLFVBQVUsUUFBUTtZQUNmLElBQUk7WUFDSixDQUFDLFVBQVUsVUFBVTtnQkFDakI7OzBGQUNBLElBQUksYUFBYSxZQUFZO29CQUN6QixTQUFTLFVBQVUsSUFBSSxPQUFPLGVBQWU7d0JBQ3pDLEtBQUssS0FBSzt3QkFDVixLQUFLLFFBQVE7d0JBQ2IsS0FBSyxnQkFBZ0I7O29CQUV6QixVQUFVLFVBQVUsTUFBTSxVQUFVLFVBQVU7d0JBQzFDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsSUFBSSxVQUFVO2dDQUNWLEtBQUssQ0FBQyxNQUFNLGNBQWMsSUFBSSxNQUFNLE1BQU0sY0FBYyxJQUFJLFFBQVEsYUFBYTtnQ0FDakYsUUFBUTs7NEJBRVosTUFBTSxNQUFNO2lDQUNQLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFROzs7O29CQUlwQixVQUFVLFVBQVUsU0FBUyxZQUFZO3dCQUNyQyxJQUFJLFFBQVE7d0JBQ1osT0FBTyxLQUFLLEdBQUcsVUFBVSxTQUFTLFFBQVE7NEJBQ3RDLElBQUksVUFBVTtnQ0FDVixLQUFLLENBQUMsTUFBTSxjQUFjLElBQUksTUFBTSxNQUFNLGNBQWMsSUFBSSxRQUFRO2dDQUNwRSxRQUFROzs0QkFFWixNQUFNLE1BQU07aUNBQ1AsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVE7Ozs7b0JBSXBCLFVBQVUsVUFBVSxNQUFNLFVBQVUsUUFBUTt3QkFDeEMsSUFBSSxVQUFVOzRCQUNWLEtBQUssQ0FBQyxLQUFLLGNBQWMsSUFBSSxNQUFNLEtBQUssY0FBYyxJQUFJLFFBQVE7NEJBQ2xFLFFBQVE7NEJBQ1IsTUFBTTs7d0JBRVYsT0FBTyxLQUFLLE1BQU07O29CQUV0QixVQUFVLFVBQVUsT0FBTyxVQUFVLFFBQVE7d0JBQ3pDLElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFROzRCQUNsRSxRQUFROzRCQUNSLE1BQU07O3dCQUVWLE9BQU8sS0FBSyxNQUFNOztvQkFFdEIsVUFBVSxVQUFVLGtCQUFrQixVQUFVLE1BQU07d0JBQ2xELElBQUksVUFBVTs0QkFDVixLQUFLLENBQUMsS0FBSyxjQUFjLElBQUksTUFBTSxLQUFLLGNBQWMsSUFBSSxRQUFRLG9DQUFvQzs0QkFDdEcsUUFBUTs7d0JBRVosT0FBTyxLQUFLLE1BQU07O29CQUV0QixPQUFPOztnQkFFWCxTQUFTLFlBQVk7Z0JBQ3JCLFFBQVEsT0FBTztxQkFDVixRQUFRLGFBQWE7ZUFDM0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjs7K0ZBQ0EsSUFBSSxpQkFBaUIsWUFBWTtvQkFDN0IsU0FBUyxjQUFjLElBQUksV0FBVyxZQUFZO3dCQUM5QyxLQUFLLEtBQUs7d0JBQ1YsS0FBSyxZQUFZO3dCQUNqQixLQUFLLGFBQWE7O29CQUV0QixjQUFjLFVBQVUsTUFBTSxVQUFVLFVBQVU7d0JBQzlDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxVQUFVLElBQUk7aUNBQ2YsS0FBSyxVQUFVLFVBQVU7Z0NBQzFCLFFBQVEsSUFBSSxPQUFPLE9BQU8sU0FBUyxVQUFVLFNBQVM7Ozs7b0JBSWxFLGNBQWMsVUFBVSxTQUFTLFlBQVk7d0JBQ3pDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxVQUFVO2lDQUNYLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFRLFNBQVMsS0FBSyxJQUFJLFVBQVUsTUFBTTtvQ0FDdEMsT0FBTyxJQUFJLE9BQU8sT0FBTyxTQUFTLFVBQVU7Ozs7O29CQUs1RCxjQUFjLFVBQVUsTUFBTSxVQUFVLFFBQVE7d0JBQzVDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxVQUFVLElBQUksT0FBTztpQ0FDdEIsS0FBSyxZQUFZO2dDQUNsQjs7aUNBRUMsTUFBTSxZQUFZO2dDQUNuQjs7OztvQkFJWixjQUFjLFVBQVUsT0FBTyxVQUFVLFFBQVE7d0JBQzdDLElBQUksUUFBUTt3QkFDWixPQUFPLEtBQUssR0FBRyxVQUFVLFNBQVMsUUFBUTs0QkFDdEMsTUFBTSxVQUFVLEtBQUssT0FBTztpQ0FDdkIsS0FBSyxZQUFZO2dDQUNsQjs7aUNBRUMsTUFBTSxZQUFZO2dDQUNuQjs7OztvQkFJWixjQUFjLFVBQVUsa0JBQWtCLFVBQVUsTUFBTTt3QkFDdEQsSUFBSSxRQUFRO3dCQUNaLE9BQU8sS0FBSyxHQUFHLFVBQVUsU0FBUyxRQUFROzRCQUN0QyxNQUFNLFVBQVUsZ0JBQWdCLEtBQUs7aUNBQ2hDLEtBQUssVUFBVSxVQUFVO2dDQUMxQixRQUFRLFNBQVM7O2lDQUVoQixNQUFNLFlBQVk7Z0NBQ25COzs7O29CQUlaLE9BQU87O2dCQUVYLFNBQVMsZ0JBQWdCO2dCQUN6QixRQUFRLE9BQU87cUJBQ1YsUUFBUSxpQkFBaUI7ZUFDL0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLFlBQVk7b0JBQ2pCLE9BQU8sQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxJQUFJO3dCQUNqRSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLE1BQU0sSUFBSSxNQUFNLElBQUk7O2dCQUU5RCxTQUFTLFlBQVk7Z0JBQ3JCLFFBQVEsT0FBTztxQkFDVixRQUFRLGFBQWE7ZUFDM0IsV0FBVyxPQUFPLGFBQWEsT0FBTyxXQUFXO1dBQ3JELFNBQVMsSUFBSSxXQUFXLElBQUksU0FBUztPQUN6QyxNQUFNLFVBQVUsUUFBUSxVQUFVLE1BQU07R0FDNUMsY0FBYyxZQUFZOztBQUU3QixJQUFJO0FBQ0osQ0FBQyxVQUFVLFdBQVc7SUFDbEIsSUFBSTtJQUNKLENBQUMsVUFBVSxLQUFLO1FBQ1osSUFBSTtRQUNKLENBQUMsVUFBVSxRQUFRO1lBQ2YsSUFBSTtZQUNKLENBQUMsVUFBVSxVQUFVO2dCQUNqQjtnQkFDQSxTQUFTLFdBQVc7b0JBQ2hCLElBQUksU0FBUztvQkFDYixLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLO3dCQUM3QixPQUFPLEtBQUs7NEJBQ1IsSUFBSTs0QkFDSixPQUFPLElBQUk7OztvQkFHbkI7b0JBQ0EsT0FBTzt3QkFDSCxTQUFTLFVBQVUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLElBQUksT0FBTyxLQUFLO3dCQUN2RCxLQUFLOzs7Z0JBR2IsU0FBUyxXQUFXO2dCQUNwQixRQUFRLE9BQU87cUJBQ1YsUUFBUSxZQUFZO2VBQzFCLFdBQVcsT0FBTyxhQUFhLE9BQU8sV0FBVztXQUNyRCxTQUFTLElBQUksV0FBVyxJQUFJLFNBQVM7T0FDekMsTUFBTSxVQUFVLFFBQVEsVUFBVSxNQUFNO0dBQzVDLGNBQWMsWUFBWTtBQUM3QiIsImZpbGUiOiIuLi8uLi93d3dyb290L2pzL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICAndXNlIHN0cmljdCc7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwJywgW1xuICAgICAgICAgICAgJ2lvbmljJyxcbiAgICAgICAgICAgICdhcHAuY29yZScsXG4gICAgICAgICAgICAnYXBwLmF1dGgnLFxuICAgICAgICAgICAgJ2FwcC5ob21lJyxcbiAgICAgICAgICAgICdhcHAubGlmdCcsXG4gICAgICAgICAgICAnYXBwLmRpbmluZycsXG4gICAgICAgICAgICAnYXBwLnJlbnRhbCdcbiAgICAgICAgXSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgIGZ1bmN0aW9uIHJ1bigkaW9uaWNQbGF0Zm9ybSwgJGxvZykge1xuICAgICAgICAgICAgJGlvbmljUGxhdGZvcm0ucmVhZHkoZGV2aWNlUmVhZHkuY2FsbCh0aGlzLCAkbG9nKSk7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gZGV2aWNlUmVhZHkoJGxvZykge1xuICAgICAgICAgICAgJGxvZy5pbmZvKCdEZXZpY2UgUmVhZHknKTtcbiAgICAgICAgfVxuICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwJylcbiAgICAgICAgICAgIC5ydW4ocnVuKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJywgW10pO1xuICAgICAgICB9KShBdXRoID0gQXBwLkF1dGggfHwgKEFwcC5BdXRoID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJywgW10pO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJywgW10pO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIEhvbWU7XG4gICAgICAgIChmdW5jdGlvbiAoSG9tZSkge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5ob21lJywgW10pO1xuICAgICAgICB9KShIb21lID0gQXBwLkhvbWUgfHwgKEFwcC5Ib21lID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5saWZ0JywgW10pO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJywgW10pO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIGZ1bmN0aW9uIHJvdXRpbmdDb25maWd1cmF0aW9uKCRzdGF0ZVByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAubG9naW4nLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9sb2dpbicsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnTG9naW5Db250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdhdXRoL3RlbXBsYXRlcy9sb2dpbi50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJylcbiAgICAgICAgICAgICAgICAuY29uZmlnKHJvdXRpbmdDb25maWd1cmF0aW9uKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRzdGF0ZVByb3ZpZGVyXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwJywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcnLFxuICAgICAgICAgICAgICAgICAgICBhYnN0cmFjdDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ01lbnVDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnLFxuICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2NvcmUvdGVtcGxhdGVzL21lbnUudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIGlvbmljQ29uZmlndXJhdGlvbigkaW9uaWNDb25maWdQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRpb25pY0NvbmZpZ1Byb3ZpZGVyLnNjcm9sbGluZy5qc1Njcm9sbGluZyhmYWxzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhpb25pY0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRzdGF0ZVByb3ZpZGVyXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmRpbmluZy1saXN0Jywge1xuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvZGluaW5nL2xpc3QnLFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0RpbmluZ0NvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2RpbmluZy90ZW1wbGF0ZXMvZGluaW5nLWxpc3QudGVtcGxhdGUuaHRtbCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmRpbmluZy1kZXRhaWwnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9kaW5pbmcvZGV0YWlsLzppZCcsXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzdGF1cmFudDogbnVsbFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0RpbmluZ0RldGFpbENvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2RpbmluZy90ZW1wbGF0ZXMvZGluaW5nLWRldGFpbC50ZW1wbGF0ZS5odG1sJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEhvbWU7XG4gICAgICAgIChmdW5jdGlvbiAoSG9tZSkge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgZnVuY3Rpb24gcm91dGluZ0NvbmZpZ3VyYXRpb24oJHN0YXRlUHJvdmlkZXIsICR1cmxSb3V0ZXJQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRzdGF0ZVByb3ZpZGVyXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmhvbWUnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9ob21lJyxcbiAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgYmFyQ29sb3I6ICdkYXJrJ1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICB2aWV3czoge1xuICAgICAgICAgICAgICAgICAgICAgICAgJ2NvbnRlbnQnOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ0hvbWVDb250cm9sbGVyJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyQXM6ICckY3RybCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdob21lL3RlbXBsYXRlcy9ob21lLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgJHVybFJvdXRlclByb3ZpZGVyLm90aGVyd2lzZSgnL2hvbWUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuaG9tZScpXG4gICAgICAgICAgICAgICAgLmNvbmZpZyhyb3V0aW5nQ29uZmlndXJhdGlvbik7XG4gICAgICAgIH0pKEhvbWUgPSBBcHAuSG9tZSB8fCAoQXBwLkhvbWUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgZnVuY3Rpb24gcm91dGluZ0NvbmZpZ3VyYXRpb24oJHN0YXRlUHJvdmlkZXIsICR1cmxSb3V0ZXJQcm92aWRlcikge1xuICAgICAgICAgICAgICAgICRzdGF0ZVByb3ZpZGVyXG4gICAgICAgICAgICAgICAgICAgIC5zdGF0ZSgnYXBwLmxpZnQtc3RhdHVzLWxpc3QnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9saWZ0L3N0YXR1cy9saXN0JyxcbiAgICAgICAgICAgICAgICAgICAgdmlld3M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICdjb250ZW50Jzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2xpZnQvdGVtcGxhdGVzL2xpZnQtc3RhdHVzLWxpc3QudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAuc3RhdGUoJ2FwcC5saWZ0LXN0YXR1cy1kZXRhaWwnLCB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogJy9saWZ0L3N0YXR1cy9kZXRhaWwvOmxpZnRJZCcsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2xpZnQvdGVtcGxhdGVzL2xpZnQtc3RhdHVzLWRldGFpbC50ZW1wbGF0ZS5odG1sJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICBmdW5jdGlvbiByb3V0aW5nQ29uZmlndXJhdGlvbigkc3RhdGVQcm92aWRlciwgJHVybFJvdXRlclByb3ZpZGVyKSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlUHJvdmlkZXJcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAucmVudGFscycsIHtcbiAgICAgICAgICAgICAgICAgICAgY2FjaGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcmVudGFscycsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3JlbnRhbC90ZW1wbGF0ZXMvcmVudGFscy50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiAnUmVudGFsc0NvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgLnN0YXRlKCdhcHAucmVudGFsLWRldGFpbCcsIHtcbiAgICAgICAgICAgICAgICAgICAgY2FjaGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgICB1cmw6ICcvcmVudGFsLzpyZW50YWxJZCcsXG4gICAgICAgICAgICAgICAgICAgIHZpZXdzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAnY29udGVudCc6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3JlbnRhbC90ZW1wbGF0ZXMvbmV3LXJlc2VydmF0aW9uLXdyYXBwZXIudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogJ05ld1Jlc2VydmF0aW9uQ29udHJvbGxlcicsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAndGFiQ3RybCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgIC5jb25maWcocm91dGluZ0NvbmZpZ3VyYXRpb24pO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gQXV0aC5Nb2RlbHMgfHwgKEF1dGguTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoQXV0aCA9IEFwcC5BdXRoIHx8IChBcHAuQXV0aCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgU3VtbWFyeUluZm8gPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBTdW1tYXJ5SW5mbygpIHtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3VtbWFyeUluZm87XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBNb2RlbHMuU3VtbWFyeUluZm8gPSBTdW1tYXJ5SW5mbztcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IENvcmUuTW9kZWxzIHx8IChDb3JlLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChXZWF0aGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIFdlYXRoZXJbV2VhdGhlcltcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBXZWF0aGVyW1dlYXRoZXJbXCJTbm93aW5nXCJdID0gMV0gPSBcIlNub3dpbmdcIjtcbiAgICAgICAgICAgICAgICAgICAgV2VhdGhlcltXZWF0aGVyW1wiUmFpbnlcIl0gPSAyXSA9IFwiUmFpbnlcIjtcbiAgICAgICAgICAgICAgICAgICAgV2VhdGhlcltXZWF0aGVyW1wiQ2xvdWR5XCJdID0gM10gPSBcIkNsb3VkeVwiO1xuICAgICAgICAgICAgICAgICAgICBXZWF0aGVyW1dlYXRoZXJbXCJTdW5ueVwiXSA9IDRdID0gXCJTdW5ueVwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5XZWF0aGVyIHx8IChNb2RlbHMuV2VhdGhlciA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIFdlYXRoZXIgPSBNb2RlbHMuV2VhdGhlcjtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IENvcmUuTW9kZWxzIHx8IChDb3JlLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoTGV2ZWxPZk5vaXNlKSB7XG4gICAgICAgICAgICAgICAgICAgIExldmVsT2ZOb2lzZVtMZXZlbE9mTm9pc2VbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgTGV2ZWxPZk5vaXNlW0xldmVsT2ZOb2lzZVtcIkxvd1wiXSA9IDFdID0gXCJMb3dcIjtcbiAgICAgICAgICAgICAgICAgICAgTGV2ZWxPZk5vaXNlW0xldmVsT2ZOb2lzZVtcIk1lZGl1bVwiXSA9IDJdID0gXCJNZWRpdW1cIjtcbiAgICAgICAgICAgICAgICAgICAgTGV2ZWxPZk5vaXNlW0xldmVsT2ZOb2lzZVtcIkxvdWRcIl0gPSAzXSA9IFwiTG91ZFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5MZXZlbE9mTm9pc2UgfHwgKE1vZGVscy5MZXZlbE9mTm9pc2UgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBMZXZlbE9mTm9pc2UgPSBNb2RlbHMuTGV2ZWxPZk5vaXNlO1xuICAgICAgICAgICAgfSkoTW9kZWxzID0gRGluaW5nLk1vZGVscyB8fCAoRGluaW5nLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKERpbmluZyA9IEFwcC5EaW5pbmcgfHwgKEFwcC5EaW5pbmcgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZXN0YXVyYW50ID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVzdGF1cmFudCgpIHtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVzdGF1cmFudDtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIE1vZGVscy5SZXN0YXVyYW50ID0gUmVzdGF1cmFudDtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IERpbmluZy5Nb2RlbHMgfHwgKERpbmluZy5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdF8xKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExpZnQgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMaWZ0KCkge1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIExpZnQucHJvdG90eXBlLnNlcmlhbGl6ZSA9IGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxpZnRJZCA9IGRhdGEubGlmdElkO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYW1lID0gZGF0YS5uYW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yYXRpbmcgPSBkYXRhLnJhdGluZztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc3RhdHVzID0gZGF0YS5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxhdGl0dWRlID0gZGF0YS5sYXRpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9uZ2l0dWRlID0gZGF0YS5sb25naXR1ZGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN0YXlBd2F5ID0gZGF0YS5zdGF5QXdheTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud2FpdGluZ1RpbWUgPSBkYXRhLndhaXRpbmdUaW1lO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZWRSZWFzb24gPSBkYXRhLmNsb3NlZFJlYXNvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0LnByb3RvdHlwZS5kZXNlcmlhbGl6ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGlmdElkOiB0aGlzLmxpZnRJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiB0aGlzLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmF0aW5nOiB0aGlzLnJhdGluZyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0dXM6IHRoaXMuc3RhdHVzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiB0aGlzLmxhdGl0dWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvbmdpdHVkZTogdGhpcy5sb25naXR1ZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RheUF3YXk6IHRoaXMuc3RheUF3YXksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgd2FpdGluZ1RpbWU6IHRoaXMud2FpdGluZ1RpbWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xvc2VkUmVhc29uOiB0aGlzLmNsb3NlZFJlYXNvblxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExpZnQ7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBNb2RlbHMuTGlmdCA9IExpZnQ7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBMaWZ0XzEuTW9kZWxzIHx8IChMaWZ0XzEuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBMaWZ0O1xuICAgICAgICAoZnVuY3Rpb24gKExpZnQpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKExpZnRSYXRpbmcpIHtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFJhdGluZ1tMaWZ0UmF0aW5nW1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIExpZnRSYXRpbmdbTGlmdFJhdGluZ1tcIkJlZ2lubmVyXCJdID0gMV0gPSBcIkJlZ2lubmVyXCI7XG4gICAgICAgICAgICAgICAgICAgIExpZnRSYXRpbmdbTGlmdFJhdGluZ1tcIkludGVybWVkaWF0ZVwiXSA9IDJdID0gXCJJbnRlcm1lZGlhdGVcIjtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFJhdGluZ1tMaWZ0UmF0aW5nW1wiQWR2YW5jZWRcIl0gPSAzXSA9IFwiQWR2YW5jZWRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuTGlmdFJhdGluZyB8fCAoTW9kZWxzLkxpZnRSYXRpbmcgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBMaWZ0UmF0aW5nID0gTW9kZWxzLkxpZnRSYXRpbmc7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBMaWZ0Lk1vZGVscyB8fCAoTGlmdC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoTGlmdFN0YXR1cykge1xuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzW0xpZnRTdGF0dXNbXCJVbmtub3duXCJdID0gMF0gPSBcIlVua25vd25cIjtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c1tMaWZ0U3RhdHVzW1wiT3BlblwiXSA9IDFdID0gXCJPcGVuXCI7XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNbTGlmdFN0YXR1c1tcIkNsb3NlZFwiXSA9IDJdID0gXCJDbG9zZWRcIjtcbiAgICAgICAgICAgICAgICB9KShNb2RlbHMuTGlmdFN0YXR1cyB8fCAoTW9kZWxzLkxpZnRTdGF0dXMgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBMaWZ0U3RhdHVzID0gTW9kZWxzLkxpZnRTdGF0dXM7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBMaWZ0Lk1vZGVscyB8fCAoTGlmdC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IFJlbnRhbC5Nb2RlbHMgfHwgKFJlbnRhbC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWxfMSkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWwgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWwoKSB7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgUmVudGFsLnByb3RvdHlwZS5zZXJpYWxpemUgPSBmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxJZCA9IGRhdGEucmVudGFsSWQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnVzZXJFbWFpbCA9IGRhdGEudXNlckVtYWlsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zdGFydERhdGUgPSBuZXcgRGF0ZShkYXRhLnN0YXJ0RGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmVuZERhdGUgPSBuZXcgRGF0ZShkYXRhLmVuZERhdGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waWNrdXBIb3VyID0gZGF0YS5waWNrdXBIb3VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hY3Rpdml0eSA9IGRhdGEuYWN0aXZpdHk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNhdGVnb3J5ID0gZGF0YS5jYXRlZ29yeTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ29hbCA9IGRhdGEuZ29hbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvZVNpemUgPSBkYXRhLnNob2VTaXplO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5za2lTaXplID0gZGF0YS5za2lTaXplO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5wb2xlU2l6ZSA9IGRhdGEucG9sZVNpemU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnRvdGFsQ29zdCA9IGRhdGEudG90YWxDb3N0O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbC5wcm90b3R5cGUuZGVzZXJpYWxpemUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbnRhbElkOiB0aGlzLnJlbnRhbElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJFbWFpbDogdGhpcy51c2VyRW1haWwsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnREYXRlOiB0aGlzLnN0YXJ0RGF0ZS50b0pTT04oKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmREYXRlOiB0aGlzLmVuZERhdGUudG9KU09OKCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGlja3VwSG91cjogdGhpcy5waWNrdXBIb3VyLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2aXR5OiB0aGlzLmFjdGl2aXR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB0aGlzLmNhdGVnb3J5LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdvYWw6IHRoaXMuZ29hbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG9lU2l6ZTogdGhpcy5zaG9lU2l6ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBza2lTaXplOiB0aGlzLnNraVNpemUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9sZVNpemU6IHRoaXMucG9sZVNpemUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG90YWxDb3N0OiB0aGlzLnRvdGFsQ29zdFxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbDtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIE1vZGVscy5SZW50YWwgPSBSZW50YWw7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBSZW50YWxfMS5Nb2RlbHMgfHwgKFJlbnRhbF8xLk1vZGVscyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIE1vZGVscztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoTW9kZWxzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIChmdW5jdGlvbiAoUmVudGFsQWN0aXZpdHkpIHtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQWN0aXZpdHlbUmVudGFsQWN0aXZpdHlbXCJTa2lcIl0gPSAwXSA9IFwiU2tpXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFjdGl2aXR5W1JlbnRhbEFjdGl2aXR5W1wiU25vd2JvYXJkXCJdID0gMV0gPSBcIlNub3dib2FyZFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5SZW50YWxBY3Rpdml0eSB8fCAoTW9kZWxzLlJlbnRhbEFjdGl2aXR5ID0ge30pKTtcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsQWN0aXZpdHkgPSBNb2RlbHMuUmVudGFsQWN0aXZpdHk7XG4gICAgICAgICAgICB9KShNb2RlbHMgPSBSZW50YWwuTW9kZWxzIHx8IChSZW50YWwuTW9kZWxzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgTW9kZWxzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChNb2RlbHMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgKGZ1bmN0aW9uIChSZW50YWxDYXRlZ29yeSkge1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxDYXRlZ29yeVtSZW50YWxDYXRlZ29yeVtcIlVua25vd25cIl0gPSAwXSA9IFwiVW5rbm93blwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxDYXRlZ29yeVtSZW50YWxDYXRlZ29yeVtcIkJlZ2lubmVyXCJdID0gMV0gPSBcIkJlZ2lubmVyXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbENhdGVnb3J5W1JlbnRhbENhdGVnb3J5W1wiSW50ZXJtZWRpYXRlXCJdID0gMl0gPSBcIkludGVybWVkaWF0ZVwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxDYXRlZ29yeVtSZW50YWxDYXRlZ29yeVtcIkFkdmFuY2VkXCJdID0gM10gPSBcIkFkdmFuY2VkXCI7XG4gICAgICAgICAgICAgICAgfSkoTW9kZWxzLlJlbnRhbENhdGVnb3J5IHx8IChNb2RlbHMuUmVudGFsQ2F0ZWdvcnkgPSB7fSkpO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxDYXRlZ29yeSA9IE1vZGVscy5SZW50YWxDYXRlZ29yeTtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IFJlbnRhbC5Nb2RlbHMgfHwgKFJlbnRhbC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBNb2RlbHM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKE1vZGVscykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbEdvYWwpIHtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsR29hbFtSZW50YWxHb2FsW1wiVW5rbm93blwiXSA9IDBdID0gXCJVbmtub3duXCI7XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEdvYWxbUmVudGFsR29hbFtcIkRlbW9cIl0gPSAxXSA9IFwiRGVtb1wiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxHb2FsW1JlbnRhbEdvYWxbXCJQZXJmb3JtYW5jZVwiXSA9IDJdID0gXCJQZXJmb3JtYW5jZVwiO1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxHb2FsW1JlbnRhbEdvYWxbXCJTcG9ydFwiXSA9IDNdID0gXCJTcG9ydFwiO1xuICAgICAgICAgICAgICAgIH0pKE1vZGVscy5SZW50YWxHb2FsIHx8IChNb2RlbHMuUmVudGFsR29hbCA9IHt9KSk7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbEdvYWwgPSBNb2RlbHMuUmVudGFsR29hbDtcbiAgICAgICAgICAgIH0pKE1vZGVscyA9IFJlbnRhbC5Nb2RlbHMgfHwgKFJlbnRhbC5Nb2RlbHMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExvZ2luQ29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIExvZ2luQ29udHJvbGxlcihhdXRoU2VydmljZSwgJGlvbmljSGlzdG9yeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoU2VydmljZSA9IGF1dGhTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNIaXN0b3J5ID0gJGlvbmljSGlzdG9yeTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9naW5EYXRhID0ge307XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndyb25nUGFzc3dvcmQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIExvZ2luQ29udHJvbGxlci5wcm90b3R5cGUubG9naW4gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JvbmdQYXNzd29yZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMubG9naW5Gb3JtLiR2YWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuYXV0aFNlcnZpY2UubG9naW4odGhpcy5sb2dpbkRhdGEudXNlcm5hbWUsIHRoaXMubG9naW5EYXRhLnBhc3N3b3JkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRpb25pY0hpc3RvcnkuZ29CYWNrKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMud3JvbmdQYXNzd29yZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMb2dpbkNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgICAgICAuY29udHJvbGxlcignTG9naW5Db250cm9sbGVyJywgTG9naW5Db250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gQXV0aC5Db250cm9sbGVycyB8fCAoQXV0aC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQXV0aEltYWdlU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIEF1dGhJbWFnZVNlcnZpY2UoJHEsIGF1dGhBUEksIGN1cnJlbnRVc2VyU2VydmljZSwgY29uZmlnU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoQVBJID0gYXV0aEFQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXJTZXJ2aWNlID0gY3VycmVudFVzZXJTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBBdXRoSW1hZ2VTZXJ2aWNlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJ1c2Vycy9waG90by9cIiArIGlkO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQXV0aEltYWdlU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkF1dGhJbWFnZVNlcnZpY2UgPSBBdXRoSW1hZ2VTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdhdXRoSW1hZ2VTZXJ2aWNlJywgQXV0aEltYWdlU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IEF1dGguU2VydmljZXMgfHwgKEF1dGguU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShBdXRoID0gQXBwLkF1dGggfHwgKEFwcC5BdXRoID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBBdXRoO1xuICAgICAgICAoZnVuY3Rpb24gKEF1dGgpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIEF1dGhBUEkgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdXRoQVBJKCRodHRwLCBjb25maWdTZXJ2aWNlLCAkaHR0cFBhcmFtU2VyaWFsaXplckpRTGlrZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGh0dHBQYXJhbVNlcmlhbGl6ZXJKUUxpa2UgPSAkaHR0cFBhcmFtU2VyaWFsaXplckpRTGlrZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBBdXRoQVBJLnByb3RvdHlwZS5sb2dpbiA9IGZ1bmN0aW9uICh1c2VybmFtZSwgcGFzc3dvcmQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBcImNvbm5lY3QvdG9rZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiB0aGlzLiRodHRwUGFyYW1TZXJpYWxpemVySlFMaWtlKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3JhbnRfdHlwZTogdGhpcy5jb25maWdTZXJ2aWNlLkF1dGhlbnRpY2F0aW9uLkdyYW50VHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xpZW50X2lkOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQXV0aGVudGljYXRpb24uQ2xpZW50SUQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsaWVudF9zZWNyZXQ6IHRoaXMuY29uZmlnU2VydmljZS5BdXRoZW50aWNhdGlvbi5DbGllbnRTZWNyZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB0aGlzLmNvbmZpZ1NlcnZpY2UuQXV0aGVudGljYXRpb24uU2NvcGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VybmFtZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHBhc3N3b3JkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBdXRoQVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQXV0aEFQSSA9IEF1dGhBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5hdXRoJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2F1dGhBUEknLCBBdXRoQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQXV0aFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdXRoU2VydmljZSgkcSwgYXV0aEFQSSwgY3VycmVudFVzZXJTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhBUEkgPSBhdXRoQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlclNlcnZpY2UgPSBjdXJyZW50VXNlclNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgQXV0aFNlcnZpY2UucHJvdG90eXBlLmxvZ2luID0gZnVuY3Rpb24gKHVzZXJuYW1lLCBwYXNzd29yZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5hdXRoQVBJLmxvZ2luKHVzZXJuYW1lLCBwYXNzd29yZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmN1cnJlbnRVc2VyU2VydmljZS5hY2Nlc3NUb2tlbiA9IHJlc3BvbnNlLmRhdGEuYWNjZXNzX3Rva2VuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuY3VycmVudFVzZXJTZXJ2aWNlLmdldEluZm8oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlcnJvci5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gQXV0aFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5BdXRoU2VydmljZSA9IEF1dGhTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuYXV0aCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdhdXRoU2VydmljZScsIEF1dGhTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEF1dGg7XG4gICAgICAgIChmdW5jdGlvbiAoQXV0aCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgQ1VSUkVOVF9VU0VSX1NUT1JBR0VfS0VZID0gJ19jdXJyZW50VXNlckRhdGEnO1xuICAgICAgICAgICAgICAgIHZhciBDdXJyZW50VXNlclNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBDdXJyZW50VXNlclNlcnZpY2UoJHEsICRyb290U2NvcGUsICRodHRwLCBjb25maWdTZXJ2aWNlLCAkbG9nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRyb290U2NvcGUgPSAkcm9vdFNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZyA9ICRsb2c7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5hY2Nlc3NUb2tlbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0SW5mbygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIEN1cnJlbnRVc2VyU2VydmljZS5wcm90b3R5cGUuc2F2ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCdDdXJyZW50VXNlclNlcnZpY2Ugc2F2aW5nIHRvIExvY2FsU3RvcmFnZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGN1cnJlbnRVc2VyQ29weSA9IGFuZ3VsYXIuY29weSh0aGlzLmN1cnJlbnRVc2VyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRVc2VyQ29weS5waG90byA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShDVVJSRU5UX1VTRVJfU1RPUkFHRV9LRVksIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY2Nlc3NUb2tlbjogdGhpcy5hY2Nlc3NUb2tlbixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdXJyZW50VXNlcjogY3VycmVudFVzZXJDb3B5XG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRsb2cuaW5mbygnLSBTdWNjZXNzZnVsbHkgc2F2ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudFVzZXJTZXJ2aWNlLnByb3RvdHlwZS5sb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSBsb2FkaW5nIGZyb20gTG9jYWxTdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RvcmVkUmF3RGF0YSA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKENVUlJFTlRfVVNFUl9TVE9SQUdFX0tFWSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoc3RvcmVkUmF3RGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBzdG9yZWREYXRhID0gSlNPTi5wYXJzZShzdG9yZWRSYXdEYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gc3RvcmVkRGF0YS5hY2Nlc3NUb2tlbjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyID0gc3RvcmVkRGF0YS5jdXJyZW50VXNlcjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRyb290U2NvcGUuY3VycmVudFVzZXIgPSB0aGlzLmN1cnJlbnRVc2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIFN1Y2Nlc3NmdWxseSBsb2FkZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIExvY2FsU3RvcmFnZSBpcyBlbXB0eScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBDdXJyZW50VXNlclNlcnZpY2UucHJvdG90eXBlLnJlc2V0ID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kbG9nLmluZm8oJ0N1cnJlbnRVc2VyU2VydmljZSByZXNldHRpbmcgTG9jYWxTdG9yYWdlJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFjY2Vzc1Rva2VuID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY3VycmVudFVzZXIgPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcm9vdFNjb3BlLmN1cnJlbnRVc2VyID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKENVUlJFTlRfVVNFUl9TVE9SQUdFX0tFWSwgSlNPTi5zdHJpbmdpZnkoe30pKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCctIERvbmUnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgQ3VycmVudFVzZXJTZXJ2aWNlLnByb3RvdHlwZS5nZXRJbmZvID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZy5pbmZvKCdDdXJyZW50VXNlclNlcnZpY2UgZ2V0dGluZyBpbmZvcm1hdGlvbicpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJ1c2Vycy91c2VyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogXCJCZWFyZXIgXCIgKyB0aGlzLmFjY2Vzc1Rva2VuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy5pbmZvKCctIEluZm9ybWF0aW9uIGdldHRlZCBzdWNjZXNzZnVsbHknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5jdXJyZW50VXNlciA9IHJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJHJvb3RTY29wZS5jdXJyZW50VXNlciA9IF90aGlzLmN1cnJlbnRVc2VyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnNhdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRsb2cud2FybignLSBTb21ldGhpbmcgd2VudCB3cm9uZyB3aGlsZSBnZXR0aW5nIGluZm9ybWF0aW9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkN1cnJlbnRVc2VyU2VydmljZSA9IEN1cnJlbnRVc2VyU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmF1dGgnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnY3VycmVudFVzZXJTZXJ2aWNlJywgQ3VycmVudFVzZXJTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQXV0aC5TZXJ2aWNlcyB8fCAoQXV0aC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKEF1dGggPSBBcHAuQXV0aCB8fCAoQXBwLkF1dGggPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTWVudUNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBNZW51Q29udHJvbGxlcigkaW9uaWNTaWRlTWVudURlbGVnYXRlLCAkc3RhdGUsIGN1cnJlbnRVc2VyU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNTaWRlTWVudURlbGVnYXRlID0gJGlvbmljU2lkZU1lbnVEZWxlZ2F0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlID0gJHN0YXRlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50VXNlclNlcnZpY2UgPSBjdXJyZW50VXNlclNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTWVudUNvbnRyb2xsZXIucHJvdG90eXBlLm5hdmlnYXRlVG8gPSBmdW5jdGlvbiAodG9TdGF0ZU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlLmdvKHRvU3RhdGVOYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGlvbmljU2lkZU1lbnVEZWxlZ2F0ZS50b2dnbGVSaWdodChmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE1lbnVDb250cm9sbGVyLnByb3RvdHlwZS5sb2dvdXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRVc2VyU2VydmljZS5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaW9uaWNTaWRlTWVudURlbGVnYXRlLnRvZ2dsZVJpZ2h0KGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE1lbnVDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ01lbnVDb250cm9sbGVyJywgTWVudUNvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBDb3JlLkNvbnRyb2xsZXJzIHx8IChDb3JlLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBXZWF0aGVyID0gQ29yZS5Nb2RlbHMuV2VhdGhlcjtcbiAgICAgICAgICAgICAgICB2YXIgU3VtbWFyeUluZm9Db250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm9Db250cm9sbGVyKHN1bW1hcnlJbmZvQVBJLCAkc3RhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnN1bW1hcnlJbmZvQVBJID0gc3VtbWFyeUluZm9BUEk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZSA9ICRzdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHN1bW1hcnlJbmZvQVBJLmdldCgpLnRoZW4oZnVuY3Rpb24gKHN1bW1hcnlJbmZvKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc3VtbWFyeUluZm8gPSBzdW1tYXJ5SW5mbztcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFN1bW1hcnlJbmZvQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0V2VhdGhlciA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFdlYXRoZXJbaWRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3VtbWFyeUluZm9Db250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ1N1bW1hcnlJbmZvQ29udHJvbGxlcicsIFN1bW1hcnlJbmZvQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IENvcmUuQ29udHJvbGxlcnMgfHwgKENvcmUuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgRmlsdGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRmlsdGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSYW5nZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChpbnB1dCwgX21pbiwgX21heCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1pbiA9IHBhcnNlSW50KF9taW4sIDEwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtYXggPSBwYXJzZUludChfbWF4LCAxMCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpID0gbWluOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dC5wdXNoKGkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlucHV0O1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoJ3NraVJhbmdlJywgUmFuZ2UpO1xuICAgICAgICAgICAgfSkoRmlsdGVycyA9IFJlbnRhbC5GaWx0ZXJzIHx8IChSZW50YWwuRmlsdGVycyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBBdmF0YXJEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHNldEJhY2tncm91bmRJbWFnZShlbGVtZW50LCB1cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignc3R5bGUnLCAnYmFja2dyb3VuZC1pbWFnZTogdXJsKFxcJycgKyB1cmwgKyAnXFwnKTsnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBsaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdza2ktYXZhdGFyJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyLiRvYnNlcnZlKCdza2lBdmF0YXInLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0QmFja2dyb3VuZEltYWdlKGVsZW1lbnQsIGF0dHIuc2tpQXZhdGFyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5rOiBsaW5rXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraUF2YXRhcicsIEF2YXRhckRpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBEaXJlY3RpdmVzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChEaXJlY3RpdmVzKSB7XG4gICAgICAgICAgICAgICAgdmFyIE5hdkJhckNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBOYXZCYXJDb250cm9sbGVyKG5hdmlnYXRpb25TZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpb25TZXJ2aWNlID0gbmF2aWdhdGlvblNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTmF2QmFyQ29udHJvbGxlci5wcm90b3R5cGUuZ29Ib21lID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5nb0hvbWUoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmF2QmFyQ29udHJvbGxlci5wcm90b3R5cGUuZ29CYWNrID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5hdkJhckNvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBOYXZCYXJEaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0EnLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvZ29CaWc6ICc9JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoYW1idXJndWVyOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmFjazogJz0nXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9uYXYtYmFyLnRlbXBsYXRlLmh0bWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlcjogTmF2QmFyQ29udHJvbGxlcixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJyRjdHJsJ1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lOYXZCYXInLCBOYXZCYXJEaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgRGlyZWN0aXZlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRGlyZWN0aXZlcykge1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJhdGluZ0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRlZmF1bHRDbGFzc2VzID0gJ2ljb24gJztcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gbGluayhzY29wZSwgZWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBzY29wZS52YWx1ZTsgaSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hcHBlbmQoYW5ndWxhci5lbGVtZW50KFwiPHNwYW4gY2xhc3M9XFxcIlwiICsgZGVmYXVsdENsYXNzZXMgKyBzY29wZS5jbGFzc09uICsgXCJcXFwiLz5cIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaiA9IHNjb3BlLnZhbHVlOyBqIDwgc2NvcGUubWF4OyBqKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZChhbmd1bGFyLmVsZW1lbnQoXCI8c3BhbiBjbGFzcz1cXFwiXCIgKyBkZWZhdWx0Q2xhc3NlcyArIHNjb3BlLmNsYXNzT2ZmICsgXCJcXFwiLz5cIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4OiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NPbjogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzT2ZmOiAnQCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5rOiBsaW5rXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVJhdGluZycsIFJhdGluZ0RpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICB2YXIgU2VsZWN0Q29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNlbGVjdENvbnRyb2xsZXIoJHNjb3BlLCAkZWxlbWVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUgPSAkc2NvcGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRlbGVtZW50ID0gJGVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNsYXNzZXMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kYWxPcGVuZWQ6ICdza2ktc2VsZWN0LW1vZGFsLS1vcGVuZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zZWxlY3RvcnMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kYWw6ICcuc2tpLXNlbGVjdC1tb2RhbCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0Q29udHJvbGxlci5wcm90b3R5cGUuc2hvd01vZGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMuJHNjb3BlLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kZWxlbWVudC5maW5kKHRoaXMuc2VsZWN0b3JzLm1vZGFsKS5hZGRDbGFzcyh0aGlzLmNsYXNzZXMubW9kYWxPcGVuZWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS5jbG9zZU1vZGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kZWxlbWVudC5maW5kKHRoaXMuc2VsZWN0b3JzLm1vZGFsKS5yZW1vdmVDbGFzcyh0aGlzLmNsYXNzZXMubW9kYWxPcGVuZWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS51cGRhdGVTZWxlY3Rpb24gPSBmdW5jdGlvbiAob3B0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUuZGlzYWJsZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5tb2RlbCA9IG9wdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2xvc2VNb2RhbCgpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBTZWxlY3RDb250cm9sbGVyLnByb3RvdHlwZS5yZXNldFNlbGVjdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLiRzY29wZS5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMudXBkYXRlU2VsZWN0aW9uKCcnKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFNlbGVjdENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTZWxlY3REaXJlY3RpdmUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb2RlbDogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyOiAnQCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0T3B0aW9uczogJz0nLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogJ0AnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkOiAnPScsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaGFzVGFiczogJ0AnXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdjb3JlL3RlbXBsYXRlcy9zZWxlY3QudGVtcGxhdGUuaHRtbCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sbGVyOiBTZWxlY3RDb250cm9sbGVyLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVNlbGVjdCcsIFNlbGVjdERpcmVjdGl2ZSk7XG4gICAgICAgICAgICB9KShEaXJlY3RpdmVzID0gQ29yZS5EaXJlY3RpdmVzIHx8IChDb3JlLkRpcmVjdGl2ZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBTdW1tYXJ5SW5mb0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlOiB7fSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2NvcmUvdGVtcGxhdGVzL3N1bW1hcnktaW5mby50ZW1wbGF0ZS5odG1sJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdTdW1tYXJ5SW5mb0NvbnRyb2xsZXInLFxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlckFzOiAnJGN0cmwnXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5kaXJlY3RpdmUoJ3NraVN1bW1hcnlJbmZvJywgU3VtbWFyeUluZm9EaXJlY3RpdmUpO1xuICAgICAgICAgICAgfSkoRGlyZWN0aXZlcyA9IENvcmUuRGlyZWN0aXZlcyB8fCAoQ29yZS5EaXJlY3RpdmVzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBDb25maWdTZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gQ29uZmlnU2VydmljZSgkbG9nKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkdlbmVyYWwgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRmFrZUdlb2xvY2F0aW9uOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdlb2xvY2F0aW9uOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiA0MC43MjI4NDYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvbmdpdHVkZTogLTc0LjAwNzMyNVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkFQSSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBVUkw6ICcvJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBQYXRoOiAnYXBpLydcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLkF1dGhlbnRpY2F0aW9uID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdyYW50VHlwZTogJ3Bhc3N3b3JkJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBDbGllbnRJRDogJ1NreVJlc29ydCcsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgQ2xpZW50U2VjcmV0OiAnc2VjcmV0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTY29wZTogJ2FwaSdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAkbG9nLmluZm8oJ0NvbmZpZ1NlcnZpY2UgaW5pdGlhbGl6ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpb25pYy5QbGF0Zm9ybS5pc1dlYlZpZXcoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRsb2cuaW5mbygnIC0gV2ViVmlldyBkZXRlY3RlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuQVBJLlVSTCA9ICdfX1lPVVJXRUJBUElVUkxfXyc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkbG9nLmluZm8oJy0gQnJvd3NlciBkZXRlY3RlZCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBDb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuQ29uZmlnU2VydmljZSA9IENvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5jb3JlJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2NvbmZpZ1NlcnZpY2UnLCBDb25maWdTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQ29yZS5TZXJ2aWNlcyB8fCAoQ29yZS5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIENvcmU7XG4gICAgICAgIChmdW5jdGlvbiAoQ29yZSkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUEkxODAgPSAwLjAxNzQ1MzI5MjUxOTk0MzI5NTsgLy8gKE1hdGguUEkvMTgwKVxuICAgICAgICAgICAgICAgIHZhciBHZW9TZXJ2aWNlID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gR2VvU2VydmljZSgkcSwgY29uZmlnU2VydmljZSwgJGxvZykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGxvZyA9ICRsb2c7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgR2VvU2VydmljZS5wcm90b3R5cGUuZ2VvbG9jYXRpb25BcGlBdmFpbGFibGUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKG5hdmlnYXRvci5nZW9sb2NhdGlvbiAmJiBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uZ2V0Q3VycmVudFBvc2l0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgR2VvU2VydmljZS5wcm90b3R5cGUuZ2V0UG9zaXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRsb2cuaW5mbygnR2VvbG9jYXRpb24gcmVxdWVzdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF90aGlzLmNvbmZpZ1NlcnZpY2UuR2VuZXJhbC5GYWtlR2VvbG9jYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGxvZy5pbmZvKCctIFJldHVybmluZyBmYWtlIGdlb2xvY2F0aW9uJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoX3RoaXMuY29uZmlnU2VydmljZS5HZW5lcmFsLkdlb2xvY2F0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoX3RoaXMuZ2VvbG9jYXRpb25BcGlBdmFpbGFibGUoKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uZ2V0Q3VycmVudFBvc2l0aW9uKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhdGl0dWRlOiByZXN1bHQuY29vcmRzLmxhdGl0dWRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvbmdpdHVkZTogcmVzdWx0LmNvb3Jkcy5sb25naXR1ZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kbG9nLndhcm4oJy0gR2VvbG9jYXRpb24gQVBJIG5vdCBhdmFpbGFibGUnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIEdlb1NlcnZpY2UucHJvdG90eXBlLmdldERpc3RhbmNlQmV0d2VlbiA9IGZ1bmN0aW9uIChhLCBiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcCA9IFBJMTgwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGMgPSBNYXRoLmNvcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByID0gMC41IC0gYygoYS5sYXRpdHVkZSAtIGIubGF0aXR1ZGUpICogcCkgLyAyICsgYyhiLmxhdGl0dWRlICogcCkgKlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGMoYS5sYXRpdHVkZSAqIHApICogKDEgLSBjKChhLmxvbmdpdHVkZSAtIGIubG9uZ2l0dWRlKSAqIHApKSAvIDI7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gKDEyNzQyICogTWF0aC5hc2luKE1hdGguc3FydChyKSkgKiAwLjYyMTM3MSk7IC8vIDIgKiBSOyBSID0gNjM3MSBrbVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE1hdGgucm91bmQocmVzdWx0ICogMWUyKSAvIDFlMjtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5HZW9TZXJ2aWNlID0gR2VvU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnZ2VvU2VydmljZScsIEdlb1NlcnZpY2UpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBDb3JlLlNlcnZpY2VzIHx8IChDb3JlLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoQ29yZSA9IEFwcC5Db3JlIHx8IChBcHAuQ29yZSA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgQ29yZTtcbiAgICAgICAgKGZ1bmN0aW9uIChDb3JlKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBOYXZpZ2F0aW9uU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIE5hdmlnYXRpb25TZXJ2aWNlKCRzdGF0ZSwgJGlvbmljSGlzdG9yeSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUgPSAkc3RhdGU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkgPSAkaW9uaWNIaXN0b3J5O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0hvbWUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY0hpc3RvcnkubmV4dFZpZXdPcHRpb25zKHsgZGlzYWJsZUJhY2s6IHRydWUsIGhpc3RvcnlSb290OiB0cnVlIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGUuZ28oJ2FwcC5ob21lJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5hdmlnYXRpb25TZXJ2aWNlLnByb3RvdHlwZS5nb0JhY2sgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW9uaWMuUGxhdGZvcm1bJ2lzJ10oJ2Jyb3dzZXInKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpbmRvdy5oaXN0b3J5LmJhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGlvbmljSGlzdG9yeS5nb0JhY2soKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTmF2aWdhdGlvblNlcnZpY2UgPSBOYXZpZ2F0aW9uU2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmNvcmUnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnbmF2aWdhdGlvblNlcnZpY2UnLCBOYXZpZ2F0aW9uU2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IENvcmUuU2VydmljZXMgfHwgKENvcmUuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShDb3JlID0gQXBwLkNvcmUgfHwgKEFwcC5Db3JlID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBDb3JlO1xuICAgICAgICAoZnVuY3Rpb24gKENvcmUpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFN1bW1hcnlJbmZvQVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gU3VtbWFyeUluZm9BUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFN1bW1hcnlJbmZvQVBJLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInN1bW1hcmllc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3VtbWFyeUluZm9BUEk7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5TdW1tYXJ5SW5mb0FQSSA9IFN1bW1hcnlJbmZvQVBJO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuY29yZScpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdzdW1tYXJ5SW5mb0FQSScsIFN1bW1hcnlJbmZvQVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gQ29yZS5TZXJ2aWNlcyB8fCAoQ29yZS5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKENvcmUgPSBBcHAuQ29yZSB8fCAoQXBwLkNvcmUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIERpbmluZztcbiAgICAgICAgKGZ1bmN0aW9uIChEaW5pbmcpIHtcbiAgICAgICAgICAgIHZhciBDb250cm9sbGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoQ29udHJvbGxlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIExldmVsT2ZOb2lzZSA9IERpbmluZy5Nb2RlbHMuTGV2ZWxPZk5vaXNlO1xuICAgICAgICAgICAgICAgIHZhciBEaW5pbmdEZXRhaWxDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gRGluaW5nRGV0YWlsQ29udHJvbGxlcigkc3RhdGVQYXJhbXMsIGRpbmluZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZVBhcmFtcyA9ICRzdGF0ZVBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZSA9IGRpbmluZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlY29tbWVuZGF0aW9ucyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGlkID0gJHN0YXRlUGFyYW1zWydpZCddO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCEkc3RhdGVQYXJhbXNbJ3Jlc3RhdXJhbnQnXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZGluaW5nU2VydmljZS5nZXRTaW5nbGUoaWQpLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVzdGF1cmFudCA9IHJlc3RhdXJhbnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdldEV4dHJhSW5mb3JtYXRpb24oKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVzdGF1cmFudCA9ICRzdGF0ZVBhcmFtc1sncmVzdGF1cmFudCddO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0RXh0cmFJbmZvcm1hdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldEV4dHJhSW5mb3JtYXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaW5pbmdTZXJ2aWNlLmdldFJlY29tbWVuZGF0aW9ucyh0aGlzLnJlc3RhdXJhbnQubmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdGF1cmFudHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZWNvbW1lbmRhdGlvbnMgPSByZXN0YXVyYW50cztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nRGV0YWlsQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0SW1hZ2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRpbmluZ1NlcnZpY2UuZ2V0SW1hZ2UoaWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdEZXRhaWxDb250cm9sbGVyLnByb3RvdHlwZS5nZXRMZXZlbE9mTm9pc2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBMZXZlbE9mTm9pc2VbaWRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gRGluaW5nRGV0YWlsQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ0RpbmluZ0RldGFpbENvbnRyb2xsZXInLCBEaW5pbmdEZXRhaWxDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gRGluaW5nLkNvbnRyb2xsZXJzIHx8IChEaW5pbmcuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBEaW5pbmc7XG4gICAgICAgIChmdW5jdGlvbiAoRGluaW5nKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMZXZlbE9mTm9pc2UgPSBEaW5pbmcuTW9kZWxzLkxldmVsT2ZOb2lzZTtcbiAgICAgICAgICAgICAgICB2YXIgRGluaW5nQ29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIERpbmluZ0NvbnRyb2xsZXIoZGluaW5nU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaW5pbmdTZXJ2aWNlID0gZGluaW5nU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0UmVzdGF1cmFudHMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmlsbEZpbHRlcnMoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMub3JkZXJCeSA9ICcnO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0NvbnRyb2xsZXIucHJvdG90eXBlLmdldFJlc3RhdXJhbnRzID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpbmluZ1NlcnZpY2UuZ2V0TmVhcigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVzdGF1cmFudHMgPSByZXN0YXVyYW50cztcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdDb250cm9sbGVyLnByb3RvdHlwZS5maWxsRmlsdGVycyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZmlsdGVycyA9IHRoaXMuZGluaW5nU2VydmljZS5nZXRGaWx0ZXJzKCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0NvbnRyb2xsZXIucHJvdG90eXBlLmdldEltYWdlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kaW5pbmdTZXJ2aWNlLmdldEltYWdlKGlkKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0TGV2ZWxPZk5vaXNlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gTGV2ZWxPZk5vaXNlW2lkXTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIERpbmluZ0NvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmRpbmluZycpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdEaW5pbmdDb250cm9sbGVyJywgRGluaW5nQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IERpbmluZy5Db250cm9sbGVycyB8fCAoRGluaW5nLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgRGluaW5nQVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gRGluaW5nQVBJKCRxLCAkaHR0cCwgY29uZmlnU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kaHR0cCA9ICRodHRwO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTZXJ2aWNlID0gY29uZmlnU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBEaW5pbmdBUEkucHJvdG90eXBlLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVzdGF1cmFudHNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCkudGhlbihmdW5jdGlvbiAocmVzdWx0cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHRzLmRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nQVBJLnByb3RvdHlwZS5nZXROZWFyID0gZnVuY3Rpb24gKGxhdGl0dWRlLCBsb25naXR1ZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKCh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlc3RhdXJhbnRzL25lYXJieVwiKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcIj9sYXRpdHVkZT1cIiArIGxhdGl0dWRlKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcIiZsb25naXR1ZGU9XCIgKyBsb25naXR1ZGUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KS50aGVuKGZ1bmN0aW9uIChyZXN1bHRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3VsdHMuZGF0YTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBEaW5pbmdBUEkucHJvdG90eXBlLmdldFJlY29tbWVuZGF0aW9ucyA9IGZ1bmN0aW9uIChzZWFyY2h0ZXh0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlc3RhdXJhbnRzL3JlY29tbWVuZGF0aW9ucy9cIiArIHNlYXJjaHRleHQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpLnRoZW4oZnVuY3Rpb24gKHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cy5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0FQSS5wcm90b3R5cGUuZ2V0U2luZ2xlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlc3RhdXJhbnRzL1wiICsgaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRodHRwKHJlcXVlc3QpLnRoZW4oZnVuY3Rpb24gKHJlc3VsdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0cy5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ0FQSS5wcm90b3R5cGUuZ2V0SW1hZ2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZXN0YXVyYW50cy9waG90by9cIiArIGlkO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gRGluaW5nQVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuRGluaW5nQVBJID0gRGluaW5nQVBJO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2RpbmluZ0FQSScsIERpbmluZ0FQSSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IERpbmluZy5TZXJ2aWNlcyB8fCAoRGluaW5nLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoRGluaW5nID0gQXBwLkRpbmluZyB8fCAoQXBwLkRpbmluZyA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgRGluaW5nO1xuICAgICAgICAoZnVuY3Rpb24gKERpbmluZykge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgRGluaW5nU2VydmljZSA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIERpbmluZ1NlcnZpY2UoJHEsIGRpbmluZ0FQSSwgZ2VvU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaW5pbmdBUEkgPSBkaW5pbmdBUEk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb1NlcnZpY2UgPSBnZW9TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sYXRpdHVkZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvbmdpdHVkZSA9IDA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0RGlzdGFuY2UgPSBmdW5jdGlvbiAobGF0aXR1ZGUsIGxvbmdpdHVkZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2VvU2VydmljZS5nZXREaXN0YW5jZUJldHdlZW4oeyBsYXRpdHVkZTogbGF0aXR1ZGUsIGxvbmdpdHVkZTogbG9uZ2l0dWRlIH0sIHsgbGF0aXR1ZGU6IHRoaXMubGF0aXR1ZGUsIGxvbmdpdHVkZTogdGhpcy5sb25naXR1ZGUgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmNhbGN1bGF0ZURpc3RhbmNlcyA9IGZ1bmN0aW9uIChyZXN0YXVyYW50cykge1xuICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDAsIGwgPSByZXN0YXVyYW50cy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN0YXVyYW50c1tpXS5kaXN0YW5jZSA9IHRoaXMuZ2V0RGlzdGFuY2UocmVzdGF1cmFudHNbaV0ubGF0aXR1ZGUsIHJlc3RhdXJhbnRzW2ldLmxvbmdpdHVkZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzdGF1cmFudHM7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmRpbmluZ0FQSS5nZXRBbGwoKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0TmVhciA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5nZW9TZXJ2aWNlLmdldFBvc2l0aW9uKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sYXRpdHVkZSA9IHJlc3VsdC5sYXRpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9uZ2l0dWRlID0gcmVzdWx0LmxvbmdpdHVkZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmRpbmluZ0FQSS5nZXROZWFyKF90aGlzLmxhdGl0dWRlLCBfdGhpcy5sb25naXR1ZGUpLnRoZW4oZnVuY3Rpb24gKHJlc3RhdXJhbnRzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzb2x2ZShfdGhpcy5jYWxjdWxhdGVEaXN0YW5jZXMocmVzdGF1cmFudHMpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgRGluaW5nU2VydmljZS5wcm90b3R5cGUuZ2V0UmVjb21tZW5kYXRpb25zID0gZnVuY3Rpb24gKF9zZWFyY2h0ZXh0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHNlYXJjaHRleHRTcGxpdHRlZCA9IF9zZWFyY2h0ZXh0LnNwbGl0KCcgJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc2VhcmNodGV4dCA9IHNlYXJjaHRleHRTcGxpdHRlZFtzZWFyY2h0ZXh0U3BsaXR0ZWQubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5kaW5pbmdBUEkuZ2V0UmVjb21tZW5kYXRpb25zKHNlYXJjaHRleHQpLnRoZW4oZnVuY3Rpb24gKGlkcykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdGF1cmFudHMgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByb21pc2VzID0gW107XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwLCBsID0gaWRzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJvbWlzZXMucHVzaCgoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5nZXRTaW5nbGUoaWRzW2ldKS50aGVuKGZ1bmN0aW9uIChyZXN0YXVyYW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RhdXJhbnRzLnB1c2gocmVzdGF1cmFudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSgpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kcS5hbGwocHJvbWlzZXMpLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXN0YXVyYW50cyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldFNpbmdsZSA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuZGluaW5nQVBJLmdldFNpbmdsZShpZCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldEZpbHRlcnMgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gW1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICctcmF0aW5nJywgbGFiZWw6ICdSYXRpbmcnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ2xldmVsT2ZOb2lzZScsIGxhYmVsOiAnTGV2ZWwgTm9pc2UnIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ3ByaWNlTGV2ZWwnLCBsYWJlbDogJ1ByaWNlJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdkaXN0YW5jZScsIGxhYmVsOiAnTWlsZXMgQXdheScgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAnLWZhbWlseUZyaWVuZGx5JywgbGFiZWw6ICdGYW1pbHkgRnJpZW5kbHknIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIF07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIERpbmluZ1NlcnZpY2UucHJvdG90eXBlLmdldEltYWdlID0gZnVuY3Rpb24gKGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5kaW5pbmdBUEkuZ2V0SW1hZ2UoaWQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gRGluaW5nU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLkRpbmluZ1NlcnZpY2UgPSBEaW5pbmdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuZGluaW5nJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2RpbmluZ1NlcnZpY2UnLCBEaW5pbmdTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gRGluaW5nLlNlcnZpY2VzIHx8IChEaW5pbmcuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShEaW5pbmcgPSBBcHAuRGluaW5nIHx8IChBcHAuRGluaW5nID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBIb21lO1xuICAgICAgICAoZnVuY3Rpb24gKEhvbWUpIHtcbiAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgIHZhciBIb21lQ29udHJvbGxlciA9IChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gSG9tZUNvbnRyb2xsZXIoJHNjb3BlLCBhdXRoU2VydmljZSwgYXV0aEltYWdlU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5hdXRoU2VydmljZSA9IGF1dGhTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmF1dGhJbWFnZVNlcnZpY2UgPSBhdXRoSW1hZ2VTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBIb21lQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0SW1hZ2UgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuYXV0aEltYWdlU2VydmljZS5nZXQoaWQpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgcmV0dXJuIEhvbWVDb250cm9sbGVyO1xuICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAuaG9tZScpXG4gICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ0hvbWVDb250cm9sbGVyJywgSG9tZUNvbnRyb2xsZXIpO1xuICAgICAgICB9KShIb21lID0gQXBwLkhvbWUgfHwgKEFwcC5Ib21lID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIEhvbWU7XG4gICAgICAgIChmdW5jdGlvbiAoSG9tZSkge1xuICAgICAgICAgICAgdmFyIERpcmVjdGl2ZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKERpcmVjdGl2ZXMpIHtcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBIb21lTWVudURpcmVjdGl2ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICAgICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ2hvbWUvdGVtcGxhdGVzL2hvbWUtbWVudS50ZW1wbGF0ZS5odG1sJ1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmhvbWUnKVxuICAgICAgICAgICAgICAgICAgICAuZGlyZWN0aXZlKCdza2lIb21lTWVudScsIEhvbWVNZW51RGlyZWN0aXZlKTtcbiAgICAgICAgICAgIH0pKERpcmVjdGl2ZXMgPSBIb21lLkRpcmVjdGl2ZXMgfHwgKEhvbWUuRGlyZWN0aXZlcyA9IHt9KSk7XG4gICAgICAgIH0pKEhvbWUgPSBBcHAuSG9tZSB8fCAoQXBwLkhvbWUgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcihsaWZ0U2VydmljZSwgJHN0YXRlUGFyYW1zLCBnZW9TZXJ2aWNlLCAkc2NvcGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxpZnRTZXJ2aWNlID0gbGlmdFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZVBhcmFtcyA9ICRzdGF0ZVBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy51c2VyR2VvbG9jYXRpb24gPSBudWxsO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5kaXN0YW5jZSA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldExpZnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kd2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdldERpc3RhbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0TGlmdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZS5nZXQodGhpcy4kc3RhdGVQYXJhbXMubGlmdElkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChsaWZ0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGlmdCA9IGxpZnQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSGFuZGxlIGVycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmdldERpc3RhbmNlID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLnVzZXJHZW9sb2NhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY2FsY0Rpc3RhbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdlb1NlcnZpY2UuZ2V0UG9zaXRpb24oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy51c2VyR2VvbG9jYXRpb24gPSBkYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5jYWxjRGlzdGFuY2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0RldGFpbENvbnRyb2xsZXIucHJvdG90eXBlLmNhbGNEaXN0YW5jZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmxpZnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmRpc3RhbmNlID0gdGhpcy5nZW9TZXJ2aWNlLmdldERpc3RhbmNlQmV0d2Vlbih0aGlzLnVzZXJHZW9sb2NhdGlvbiwgeyBsYXRpdHVkZTogdGhpcy5saWZ0LmxhdGl0dWRlLCBsb25naXR1ZGU6IHRoaXMubGlmdC5sb25naXR1ZGUgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdMaWZ0U3RhdHVzRGV0YWlsQ29udHJvbGxlcicsIExpZnRTdGF0dXNEZXRhaWxDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gTGlmdC5Db250cm9sbGVycyB8fCAoTGlmdC5Db250cm9sbGVycyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyKGxpZnRTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxpZnRTZXJ2aWNlID0gbGlmdFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmdldExpZnRzKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdFN0YXR1c0xpc3RDb250cm9sbGVyLnByb3RvdHlwZS5nZXRMaWZ0cyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0U2VydmljZS5nZXROZWFyKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAoZGF0YSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmRpZ2VzdExpZnRzKGRhdGEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlci5wcm90b3R5cGUuZGlnZXN0TGlmdHMgPSBmdW5jdGlvbiAobGlmdHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm9wZW5MaWZ0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5jbG9zZWRMaWZ0cyA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGlmdHMuZm9yRWFjaChmdW5jdGlvbiAobGlmdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChsaWZ0LnN0YXR1cyA9PT0gTGlmdC5Nb2RlbHMuTGlmdFN0YXR1cy5PcGVuKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLm9wZW5MaWZ0cy5wdXNoKGxpZnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChsaWZ0LnN0YXR1cyA9PT0gTGlmdC5Nb2RlbHMuTGlmdFN0YXR1cy5DbG9zZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY2xvc2VkTGlmdHMucHVzaChsaWZ0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExpZnRTdGF0dXNMaXN0Q29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAubGlmdCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXInLCBMaWZ0U3RhdHVzTGlzdENvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfSkoQ29udHJvbGxlcnMgPSBMaWZ0LkNvbnRyb2xsZXJzIHx8IChMaWZ0LkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoTGlmdCA9IEFwcC5MaWZ0IHx8IChBcHAuTGlmdCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgTGlmdDtcbiAgICAgICAgKGZ1bmN0aW9uIChMaWZ0KSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBMaWZ0QVBJID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gTGlmdEFQSSgkcSwgJGh0dHAsIGNvbmZpZ1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJGh0dHAgPSAkaHR0cDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU2VydmljZSA9IGNvbmZpZ1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdEFQSS5wcm90b3R5cGUuZ2V0QWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAoX3RoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgX3RoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcImxpZnRzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLiRodHRwKHJlcXVlc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0QVBJLnByb3RvdHlwZS5nZXROZWFyID0gZnVuY3Rpb24gKGxhdGl0dWRlLCBsb25naXR1ZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwibGlmdHMvbmVhcmJ5XCIpICtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIChcIj9sYXRpdHVkZT1cIiArIGxhdGl0dWRlKSArXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoXCImbG9uZ2l0dWRlPVwiICsgbG9uZ2l0dWRlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuJGh0dHAocmVxdWVzdClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBMaWZ0QVBJLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAoaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVybDogKHRoaXMuY29uZmlnU2VydmljZS5BUEkuVVJMICsgdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwibGlmdHMvXCIgKyBpZCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGh0dHAocmVxdWVzdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBMaWZ0QVBJO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTGlmdEFQSSA9IExpZnRBUEk7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5saWZ0JylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ2xpZnRBUEknLCBMaWZ0QVBJKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gTGlmdC5TZXJ2aWNlcyB8fCAoTGlmdC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKExpZnQgPSBBcHAuTGlmdCB8fCAoQXBwLkxpZnQgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIExpZnQ7XG4gICAgICAgIChmdW5jdGlvbiAoTGlmdCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgTGlmdFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBMaWZ0U2VydmljZSgkcSwgbGlmdEFQSSwgZ2VvU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kcSA9ICRxO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5saWZ0QVBJID0gbGlmdEFQSTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2VvU2VydmljZSA9IGdlb1NlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldEFsbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubGlmdEFQSS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldE5lYXIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLmdlb1NlcnZpY2UuZ2V0UG9zaXRpb24oKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzdWx0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcy5saWZ0QVBJLmdldE5lYXIocmVzdWx0LmxhdGl0dWRlLCByZXN1bHQubG9uZ2l0dWRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKGl0ZW0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTGlmdFNlcnZpY2UucHJvdG90eXBlLmdldCA9IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLiRxKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5saWZ0QVBJLmdldChpZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3VsdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKG5ldyBMaWZ0Lk1vZGVscy5MaWZ0KCkuc2VyaWFsaXplKHJlc3VsdC5kYXRhKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKHJlamVjdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIExpZnRTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgU2VydmljZXMuTGlmdFNlcnZpY2UgPSBMaWZ0U2VydmljZTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLmxpZnQnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnbGlmdFNlcnZpY2UnLCBMaWZ0U2VydmljZSk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IExpZnQuU2VydmljZXMgfHwgKExpZnQuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShMaWZ0ID0gQXBwLkxpZnQgfHwgKEFwcC5MaWZ0ID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIoJHNjb3BlLCByZW50YWxTZXJ2aWNlLCByZW50YWxBY3Rpdml0aWVzLCByZW50YWxDYXRlZ29yaWVzLCByZW50YWxHb2Fscywgc2hvZVNpemVzLCBza2lTaXplcywgcG9sZVNpemVzLCAkc3RhdGVQYXJhbXMsIHBpY2t1cEhvdXJzLCBuYXZpZ2F0aW9uU2VydmljZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlID0gJHNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxTZXJ2aWNlID0gcmVudGFsU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsQWN0aXZpdGllcyA9IHJlbnRhbEFjdGl2aXRpZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbENhdGVnb3JpZXMgPSByZW50YWxDYXRlZ29yaWVzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5yZW50YWxHb2FscyA9IHJlbnRhbEdvYWxzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5zaG9lU2l6ZXMgPSBzaG9lU2l6ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnNraVNpemVzID0gc2tpU2l6ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBvbGVTaXplcyA9IHBvbGVTaXplcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHN0YXRlUGFyYW1zID0gJHN0YXRlUGFyYW1zO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5waWNrdXBIb3VycyA9IHBpY2t1cEhvdXJzO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uU2VydmljZSA9IG5hdmlnYXRpb25TZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmhpZ2hEZW1hbmRBbGVydCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gSW5pdGlhbGl6ZSByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsID0gbmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnBpY2t1cEhvdXJzLmdlbmVyYXRlQWxsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBJZiB0aGVyZSdzIGEgcmVudGFsSWQsIHdlJ3JlIGVkaXRpbmcsIG5vdCBjcmVhdGluZ1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCRzdGF0ZVBhcmFtcy5yZW50YWxJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0UmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlc2V0UmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBTZXQgdGhlIHRvZGF5RGF0ZWQsIHVzZWQgYXMgJ21pbicgdmFsdWUgZm9yIHN0YXJ0RGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUudG9kYXlEYXRlLnNldEhvdXJzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZS5zZXRNaW51dGVzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnRvZGF5RGF0ZS5zZXRTZWNvbmRzKDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGFydERhdGUgaXMgZWRpdGVkIGluIHR3byBzZXBhcmF0ZWQgaW5wdXRzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNvLCBpdCBuZWVkcyB0byBiZSBpbiByZXBhcmF0ZWQgbW9kZWxzIGZvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVhY2ggbmctbW9kZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuc3RhcnREYXRlID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRheTogbnVsbCxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBob3VyOiBudWxsXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaGVzZSB2YWx1ZXMgKG9wdGlvbnMgaW4gc2VsZWN0b3JzKSBhcmUgbWFwcGVkIHRvIHRoZSBvcmlnaW5hbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlbnRhbCBtb2RlbCB1c2luZyAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvblxuICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS5yZW50YWxUZW1wID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFjdGl2aXR5OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvbGVTaXplOiBudWxsLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraVNpemU6IG51bGxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgc3RhcnREYXRlXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbignc3RhcnREYXRlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghJHNjb3BlLnN0YXJ0RGF0ZS5kYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuc3RhcnREYXRlID0gYW5ndWxhci5jb3B5KCRzY29wZS5zdGFydERhdGUuZGF5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoJHNjb3BlLnN0YXJ0RGF0ZS5ob3VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbC5zdGFydERhdGUuc2V0SG91cnMoJHNjb3BlLnN0YXJ0RGF0ZS5ob3VyLmhvdXJzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsLnN0YXJ0RGF0ZS5zZXRNaW51dGVzKCRzY29wZS5zdGFydERhdGUuaG91ci5taW51dGVzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuY2hlY2tIaWdoRGVtYW5kKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSBhY3Rpdml0eSwgY2F0ZWdvcnksIHBvbGVTaXplIGFuZCBza2lTaXplXG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbigncmVudGFsVGVtcCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuYWN0aXZpdHkgPSAkc2NvcGUucmVudGFsVGVtcC5hY3Rpdml0eSA/ICRzY29wZS5yZW50YWxUZW1wLmFjdGl2aXR5LmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuY2F0ZWdvcnkgPSAkc2NvcGUucmVudGFsVGVtcC5jYXRlZ29yeSA/ICRzY29wZS5yZW50YWxUZW1wLmNhdGVnb3J5LmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwucG9sZVNpemUgPSAkc2NvcGUucmVudGFsVGVtcC5wb2xlU2l6ZSA/ICRzY29wZS5yZW50YWxUZW1wLnBvbGVTaXplLmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwuc2tpU2l6ZSA9ICRzY29wZS5yZW50YWxUZW1wLnNraVNpemUgPyAkc2NvcGUucmVudGFsVGVtcC5za2lTaXplLmlkIDogbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuZ2V0UmVudGFsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMubG9hZGluZyA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbFNlcnZpY2UuZ2V0KHRoaXMuJHN0YXRlUGFyYW1zLnJlbnRhbElkKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZW50YWwgPSByZW50YWw7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMudXBkYXRlVGVtcERhdGEoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHVwZGF0ZSBhbGwgdGhlIHRlbXBvcmFsIGRhdGEgdXNlZCBpbiB0aGUgY3VzdG9tIHNlbGVjdHNcbiAgICAgICAgICAgICAgICAgICAgLy8gYmFzZWQgb24gdGhlIGFjdHVhbCByZW50YWwgb2JqZWN0LlxuICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGlzIG1ldGhvZCBpcyB1c2VkIGF0IHN0YXJ0IHdoZW4gd2UncmUgZWRpdGluZyBhIHJlbnRhbFxuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLnVwZGF0ZVRlbXBEYXRhID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGhvdXJzID0gdGhpcy5yZW50YWwuc3RhcnREYXRlLmdldEhvdXJzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWludXRlcyA9IHRoaXMucmVudGFsLnN0YXJ0RGF0ZS5nZXRNaW51dGVzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5zdGFydERhdGUgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF5OiB0aGlzLnJlbnRhbC5zdGFydERhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cjogdGhpcy5waWNrdXBIb3Vycy5nZXRCeUlkKChob3VycyAqIDYwKSArIG1pbnV0ZXMpXG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUucmVudGFsVGVtcCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpdml0eTogdGhpcy5yZW50YWxBY3Rpdml0aWVzLmdldEJ5SWQodGhpcy5yZW50YWwuYWN0aXZpdHkpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhdGVnb3J5OiB0aGlzLnJlbnRhbENhdGVnb3JpZXMuZ2V0QnlJZCh0aGlzLnJlbnRhbC5jYXRlZ29yeSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9sZVNpemU6IHRoaXMucG9sZVNpemVzLmdldEJ5SWQodGhpcy5yZW50YWwucG9sZVNpemUpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNraVNpemU6IHRoaXMuc2tpU2l6ZXMuZ2V0QnlJZCh0aGlzLnJlbnRhbC5za2lTaXplKVxuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgLy8gVGhpcyB3aWxsIHB1dCB0aGUgcmVudGFsIGFuZCBhbGwgdGhlIHRlbXBvcmFsIHZhbHVlcyBmb3IgY3VzdG9tXG4gICAgICAgICAgICAgICAgICAgIC8vIHNlbGVjdHMgdG8gbnVsbFxuICAgICAgICAgICAgICAgICAgICAvL1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGlzIG1ldGhvZCBpcyB1c2VkIGF0IHN0YXJ0IHdoZW4gd2UncmUgY3JlYXRpbmcgYSByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5yZXNldFJlbnRhbCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsID0gbmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBpIGluIHRoaXMuJHNjb3BlLnN0YXJ0RGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLiRzY29wZS5zdGFydERhdGUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc2NvcGUuc3RhcnREYXRlW2ldID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciB4IGluIHRoaXMuJHNjb3BlLnJlbnRhbFRlbXApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc2NvcGUucmVudGFsVGVtcC5oYXNPd25Qcm9wZXJ0eSh4KSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS5yZW50YWxUZW1wW3hdID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuZW1pdFNhdmUgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZS4kZW1pdCgncmVudGFsX3NhdmVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuc3VibWl0UmVzZXJ2YXRpb24gPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHRoaXMucmVudGFsRm9ybS4kdmFsaWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb25Qcm9taXNlID0gbnVsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy4kc3RhdGVQYXJhbXMucmVudGFsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWN0aW9uUHJvbWlzZSA9IHRoaXMuc2F2ZVJlc2VydmF0aW9uKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25Qcm9taXNlID0gdGhpcy5hZGRSZXNlcnZhdGlvbigpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25Qcm9taXNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLmFkZFJlc2VydmF0aW9uID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLnJlbnRhbFNlcnZpY2UuYWRkKHRoaXMucmVudGFsKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5yZXNldFJlbnRhbCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEZvcm0uJHNldFByaXN0aW5lKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsRm9ybS4kc2V0VW50b3VjaGVkKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuZW1pdFNhdmUoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBOZXdSZXNlcnZhdGlvbkNvbnRyb2xsZXIucHJvdG90eXBlLnNhdmVSZXNlcnZhdGlvbiA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5yZW50YWxTZXJ2aWNlLnNhdmUodGhpcy5yZW50YWwpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLm5hdmlnYXRpb25TZXJ2aWNlLmdvQmFjaygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlci5wcm90b3R5cGUuY2hlY2tIaWdoRGVtYW5kID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsU2VydmljZS5jaGVja0hpZ2hEZW1hbmQodGhpcy5yZW50YWwuc3RhcnREYXRlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5oaWdoRGVtYW5kQWxlcnQgPSByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gSGFuZGxlIGVycm9yXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgTmV3UmVzZXJ2YXRpb25Db250cm9sbGVyLnByb3RvdHlwZS5nZXRDYWxjdWxhdGVkQ29zdCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsLnRvdGFsQ29zdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpcy5yZW50YWwuc3RhcnREYXRlICYmIHRoaXMucmVudGFsLmVuZERhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbC50b3RhbENvc3QgPSAyMDtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgZGF5cyA9IE1hdGguZmxvb3IoKHRoaXMucmVudGFsLmVuZERhdGUuZ2V0VGltZSgpIC0gdGhpcy5yZW50YWwuc3RhcnREYXRlLmdldFRpbWUoKSkgLyAxMDAwIC8gNjAgLyA2MCAvIDI0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbnRhbC50b3RhbENvc3QgPSB0aGlzLnJlbnRhbC50b3RhbENvc3QgKyAoZGF5cyAqIDUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVudGFsLnRvdGFsQ29zdDtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLmNvbnRyb2xsZXIoJ05ld1Jlc2VydmF0aW9uQ29udHJvbGxlcicsIE5ld1Jlc2VydmF0aW9uQ29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IFJlbnRhbC5Db250cm9sbGVycyB8fCAoUmVudGFsLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIENvbnRyb2xsZXJzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChDb250cm9sbGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICB2YXIgUmVudGFsc0NvbnRyb2xsZXIgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxzQ29udHJvbGxlcigkaW9uaWNUYWJzRGVsZWdhdGUsICRzY29wZSwgJHN0YXRlUGFyYW1zKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRpb25pY1RhYnNEZWxlZ2F0ZSA9ICRpb25pY1RhYnNEZWxlZ2F0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHNjb3BlID0gJHNjb3BlO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy4kc3RhdGVQYXJhbXMgPSAkc3RhdGVQYXJhbXM7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJG9uKCdyZW50YWxfc2F2ZWQnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJGlvbmljVGFic0RlbGVnYXRlLiRnZXRCeUhhbmRsZSgnc2VjdGlvbi10YWJzJykuc2VsZWN0KDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS4kYnJvYWRjYXN0KCd1cGRhdGVfcmVzZXJ2YXRpb25fbGlzdCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbHNDb250cm9sbGVyO1xuICAgICAgICAgICAgICAgIH0oKSk7XG4gICAgICAgICAgICAgICAgQ29udHJvbGxlcnMuUmVudGFsc0NvbnRyb2xsZXIgPSBSZW50YWxzQ29udHJvbGxlcjtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdSZW50YWxzQ29udHJvbGxlcicsIFJlbnRhbHNDb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0pKENvbnRyb2xsZXJzID0gUmVudGFsLkNvbnRyb2xsZXJzIHx8IChSZW50YWwuQ29udHJvbGxlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgQ29udHJvbGxlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKENvbnRyb2xsZXJzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZXNlcnZhdGlvbkxpc3RDb250cm9sbGVyID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlcigkc2NvcGUsIHJlbnRhbFNlcnZpY2UsICRzdGF0ZSwgJHRpbWVvdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzY29wZSA9ICRzY29wZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsU2VydmljZSA9IHJlbnRhbFNlcnZpY2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRzdGF0ZSA9ICRzdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHRpbWVvdXQgPSAkdGltZW91dDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuc2hvd01lc3NhZ2UgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0UmVudGFscygpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiRvbigndXBkYXRlX3Jlc2VydmF0aW9uX2xpc3QnLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuZ2V0UmVudGFscygpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2hvd01lc3NhZ2UgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlci5wcm90b3R5cGUuZ2V0UmVudGFscyA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVudGFsU2VydmljZS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIChkYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFscyA9IGRhdGE7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5maW5hbGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlci5wcm90b3R5cGUubmF2aWdhdGVUb1JlbnRhbCA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5hdmlnYXRpbmdSZW50YWwgPSByZW50YWw7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiR0aW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kc3RhdGUuZ28oJ2FwcC5yZW50YWwtZGV0YWlsJywgeyByZW50YWxJZDogcmVudGFsLnJlbnRhbElkIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlc2VydmF0aW9uTGlzdENvbnRyb2xsZXI7XG4gICAgICAgICAgICAgICAgfSgpKTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5jb250cm9sbGVyKCdSZXNlcnZhdGlvbkxpc3RDb250cm9sbGVyJywgUmVzZXJ2YXRpb25MaXN0Q29udHJvbGxlcik7XG4gICAgICAgICAgICB9KShDb250cm9sbGVycyA9IFJlbnRhbC5Db250cm9sbGVycyB8fCAoUmVudGFsLkNvbnRyb2xsZXJzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIEZpbHRlcnM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKEZpbHRlcnMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gUmVudGFsQWN0aXZpdHlGaWx0ZXIoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaW5wdXQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5W2lucHV0XTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKCdza2lSZW50YWxBY3Rpdml0eScsIFJlbnRhbEFjdGl2aXR5RmlsdGVyKTtcbiAgICAgICAgICAgIH0pKEZpbHRlcnMgPSBSZW50YWwuRmlsdGVycyB8fCAoUmVudGFsLkZpbHRlcnMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgRmlsdGVycztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoRmlsdGVycykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxDYXRlZ29yeUZpbHRlcigpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChpbnB1dCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbC5Nb2RlbHMuUmVudGFsQ2F0ZWdvcnlbaW5wdXRdO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoJ3NraVJlbnRhbENhdGVnb3J5JywgUmVudGFsQ2F0ZWdvcnlGaWx0ZXIpO1xuICAgICAgICAgICAgfSkoRmlsdGVycyA9IFJlbnRhbC5GaWx0ZXJzIHx8IChSZW50YWwuRmlsdGVycyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFBpY2t1cEhvdXJzID0gKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gUGlja3VwSG91cnMoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmFsbCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFBpY2t1cEhvdXJzLnByb3RvdHlwZS5nZXRCeUlkID0gZnVuY3Rpb24gKGkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfaG91cnMgPSBNYXRoLmZsb29yKGkgLyA2MCk7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX21pbnV0ZXMgPSBpIC0gKF9ob3VycyAqIDYwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBob3VycyA9IF9ob3VycztcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW51dGVzID0gX21pbnV0ZXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWVyID0gJ2FtJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChob3VycyA+IDEyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnMgPSBob3VycyAtIDEyO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1lciA9ICdwbSc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaG91cnNfc3RyID0gaG91cnMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBtaW51dGVzX3N0ciA9IG1pbnV0ZXMudG9TdHJpbmcoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChob3Vyc19zdHIubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnNfc3RyID0gJzAnICsgaG91cnNfc3RyO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1pbnV0ZXNfc3RyLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbnV0ZXNfc3RyID0gJzAnICsgbWludXRlc19zdHI7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiBpLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsOiBob3Vyc19zdHIgKyBcIjpcIiArIG1pbnV0ZXNfc3RyICsgXCIgXCIgKyBtZXIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaG91cnM6IF9ob3VycyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW51dGVzOiBfbWludXRlc1xuICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUGlja3VwSG91cnMucHJvdG90eXBlLmdlbmVyYXRlQWxsID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIG1pbk1pbnV0ZXMgPSAzNjA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbWF4TWludXRlcyA9IDEyMDA7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgc3RlcHMgPSAxNTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSBtaW5NaW51dGVzOyBpIDw9IG1heE1pbnV0ZXM7IGkgPSBpICsgc3RlcHMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh0aGlzLmdldEJ5SWQoaSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5hbGwgPSByZXN1bHQ7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBQaWNrdXBIb3VycztcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlBpY2t1cEhvdXJzID0gUGlja3VwSG91cnM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncGlja3VwSG91cnMnLCBQaWNrdXBIb3Vycyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBQb2xlU2l6ZXMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgaSA9IDMyOyBpIDw9IDU3OyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaSArICcgaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IGlkICsgJyBpbicgfSk7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGw6IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5Qb2xlU2l6ZXMgPSBQb2xlU2l6ZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgncG9sZVNpemVzJywgUG9sZVNpemVzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFJlbnRhbEFjdGl2aXRpZXMoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IFJlbnRhbC5Nb2RlbHMuUmVudGFsQWN0aXZpdHlbaWRdIH0pOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgYWxsOiBPYmplY3Qua2V5cyhSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuIHBhcnNlSW50KGksIDEwKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuZmlsdGVyKGZ1bmN0aW9uIChpKSB7IHJldHVybiAhaXNOYU4oaSk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoaSkgeyByZXR1cm4gKHsgaWQ6IGksIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbEFjdGl2aXR5W2ldIH0pOyB9KVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxBY3Rpdml0aWVzID0gUmVudGFsQWN0aXZpdGllcztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxBY3Rpdml0aWVzJywgUmVudGFsQWN0aXZpdGllcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxDYXRlZ29yaWVzKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0QnlJZDogZnVuY3Rpb24gKGlkKSB7IHJldHVybiAoeyBpZDogaWQsIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbENhdGVnb3J5W2lkXSB9KTsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsbDogT2JqZWN0LmtleXMoUmVudGFsLk1vZGVscy5SZW50YWxDYXRlZ29yeSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAubWFwKGZ1bmN0aW9uIChpKSB7IHJldHVybiBwYXJzZUludChpLCAxMCk7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmZpbHRlcihmdW5jdGlvbiAoaSkgeyByZXR1cm4gIWlzTmFOKGkpICYmIGkgIT09IDA7IH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLm1hcChmdW5jdGlvbiAoaSkgeyByZXR1cm4gKHsgaWQ6IGksIGxhYmVsOiBSZW50YWwuTW9kZWxzLlJlbnRhbENhdGVnb3J5W2ldIH0pOyB9KVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5SZW50YWxDYXRlZ29yaWVzID0gUmVudGFsQ2F0ZWdvcmllcztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxDYXRlZ29yaWVzJywgUmVudGFsQ2F0ZWdvcmllcyk7XG4gICAgICAgICAgICB9KShTZXJ2aWNlcyA9IFJlbnRhbC5TZXJ2aWNlcyB8fCAoUmVudGFsLlNlcnZpY2VzID0ge30pKTtcbiAgICAgICAgfSkoUmVudGFsID0gQXBwLlJlbnRhbCB8fCAoQXBwLlJlbnRhbCA9IHt9KSk7XG4gICAgfSkoQXBwID0gU2tpUmVzb3J0LkFwcCB8fCAoU2tpUmVzb3J0LkFwcCA9IHt9KSk7XG59KShTa2lSZXNvcnQgfHwgKFNraVJlc29ydCA9IHt9KSk7XG4vLy8gPHJlZmVyZW5jZSBwYXRoPScuLi8uLi8uLi8uLi8uLi90eXBpbmdzL2Jyb3dzZXIuZC50cycvPlxudmFyIFNraVJlc29ydDtcbihmdW5jdGlvbiAoU2tpUmVzb3J0KSB7XG4gICAgdmFyIEFwcDtcbiAgICAoZnVuY3Rpb24gKEFwcCkge1xuICAgICAgICB2YXIgUmVudGFsO1xuICAgICAgICAoZnVuY3Rpb24gKFJlbnRhbCkge1xuICAgICAgICAgICAgdmFyIFNlcnZpY2VzO1xuICAgICAgICAgICAgKGZ1bmN0aW9uIChTZXJ2aWNlcykge1xuICAgICAgICAgICAgICAgICd1c2Ugc3RyaWN0JztcbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxHb2FscygpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIE9iamVjdC5rZXlzKFJlbnRhbC5Nb2RlbHMuUmVudGFsR29hbClcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuIHBhcnNlSW50KGksIDEwKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5maWx0ZXIoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICFpc05hTihpKTsgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC5tYXAoZnVuY3Rpb24gKGkpIHsgcmV0dXJuICh7IGlkOiBpLCBsYWJlbDogUmVudGFsLk1vZGVscy5SZW50YWxHb2FsW2ldIH0pOyB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgU2VydmljZXMuUmVudGFsR29hbHMgPSBSZW50YWxHb2FscztcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxHb2FscycsIFJlbnRhbEdvYWxzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIHZhciBSZW50YWxBUEkgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxBUEkoJHEsICRodHRwLCBjb25maWdTZXJ2aWNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRxID0gJHE7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLiRodHRwID0gJGh0dHA7XG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1NlcnZpY2UgPSBjb25maWdTZXJ2aWNlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbEFQSS5wcm90b3R5cGUuZ2V0ID0gZnVuY3Rpb24gKHJlbnRhbElkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFscy9cIiArIHJlbnRhbElkLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kaHR0cChyZXF1ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciByZXF1ZXN0ID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6IChfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyBfdGhpcy5jb25maWdTZXJ2aWNlLkFQSS5QYXRoKSArIFwicmVudGFsc1wiLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy4kaHR0cChyZXF1ZXN0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5hZGQgPSBmdW5jdGlvbiAocmVudGFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgcmVxdWVzdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cmw6ICh0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlVSTCArIHRoaXMuY29uZmlnU2VydmljZS5BUEkuUGF0aCkgKyBcInJlbnRhbHNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5zYXZlID0gZnVuY3Rpb24gKHJlbnRhbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZW50YWxzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkYXRhOiByZW50YWxcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsQVBJLnByb3RvdHlwZS5jaGVja0hpZ2hEZW1hbmQgPSBmdW5jdGlvbiAoZGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHJlcXVlc3QgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXJsOiAodGhpcy5jb25maWdTZXJ2aWNlLkFQSS5VUkwgKyB0aGlzLmNvbmZpZ1NlcnZpY2UuQVBJLlBhdGgpICsgXCJyZW50YWxzL2NoZWNrX2hpZ2hfZGVtYW5kP2RhdGU9XCIgKyBkYXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kaHR0cChyZXF1ZXN0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFJlbnRhbEFQSTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlJlbnRhbEFQSSA9IFJlbnRhbEFQSTtcbiAgICAgICAgICAgICAgICBhbmd1bGFyLm1vZHVsZSgnYXBwLnJlbnRhbCcpXG4gICAgICAgICAgICAgICAgICAgIC5zZXJ2aWNlKCdyZW50YWxBUEknLCBSZW50YWxBUEkpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuLy8vIDxyZWZlcmVuY2UgcGF0aD0nLi4vLi4vLi4vLi4vLi4vdHlwaW5ncy9icm93c2VyLmQudHMnLz5cbnZhciBTa2lSZXNvcnQ7XG4oZnVuY3Rpb24gKFNraVJlc29ydCkge1xuICAgIHZhciBBcHA7XG4gICAgKGZ1bmN0aW9uIChBcHApIHtcbiAgICAgICAgdmFyIFJlbnRhbDtcbiAgICAgICAgKGZ1bmN0aW9uIChSZW50YWwpIHtcbiAgICAgICAgICAgIHZhciBTZXJ2aWNlcztcbiAgICAgICAgICAgIChmdW5jdGlvbiAoU2VydmljZXMpIHtcbiAgICAgICAgICAgICAgICAndXNlIHN0cmljdCc7XG4gICAgICAgICAgICAgICAgdmFyIFJlbnRhbFNlcnZpY2UgPSAoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBSZW50YWxTZXJ2aWNlKCRxLCByZW50YWxBUEksIGdlb1NlcnZpY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuJHEgPSAkcTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVudGFsQVBJID0gcmVudGFsQVBJO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5nZW9TZXJ2aWNlID0gZ2VvU2VydmljZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbiAocmVudGFsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLmdldChyZW50YWxJZClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlc29sdmUobmV3IFJlbnRhbC5Nb2RlbHMuUmVudGFsKCkuc2VyaWFsaXplKHJlc3BvbnNlLmRhdGEpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICBSZW50YWxTZXJ2aWNlLnByb3RvdHlwZS5nZXRBbGwgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5nZXRBbGwoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhLm1hcChmdW5jdGlvbiAoaXRlbSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBSZW50YWwuTW9kZWxzLlJlbnRhbCgpLnNlcmlhbGl6ZShpdGVtKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbFNlcnZpY2UucHJvdG90eXBlLmFkZCA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLmFkZChyZW50YWwuZGVzZXJpYWxpemUoKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVqZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgUmVudGFsU2VydmljZS5wcm90b3R5cGUuc2F2ZSA9IGZ1bmN0aW9uIChyZW50YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy4kcShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMucmVudGFsQVBJLnNhdmUocmVudGFsLmRlc2VyaWFsaXplKCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIFJlbnRhbFNlcnZpY2UucHJvdG90eXBlLmNoZWNrSGlnaERlbWFuZCA9IGZ1bmN0aW9uIChkYXRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJHEoZnVuY3Rpb24gKHJlc29sdmUsIHJlamVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnJlbnRhbEFQSS5jaGVja0hpZ2hEZW1hbmQoZGF0ZS50b0lTT1N0cmluZygpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVzb2x2ZShyZXNwb25zZS5kYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZWplY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gUmVudGFsU2VydmljZTtcbiAgICAgICAgICAgICAgICB9KCkpO1xuICAgICAgICAgICAgICAgIFNlcnZpY2VzLlJlbnRhbFNlcnZpY2UgPSBSZW50YWxTZXJ2aWNlO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3JlbnRhbFNlcnZpY2UnLCBSZW50YWxTZXJ2aWNlKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNob2VTaXplcygpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFsxLCAyLCAzLCA0LCA0LjUsIDUsIDUuNSwgNiwgNi41LCA3LCA3LjUsIDgsIDguNSwgOSwgOS41LCAxMCwgMTAuNSxcbiAgICAgICAgICAgICAgICAgICAgICAgIDExLCAxMS41LCAxMiwgMTIuNSwgMTMsIDEzLjUsIDE0LCAxNC41LCAxNSwgMTUuNSwgMTYsIDE2LjVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5TaG9lU2l6ZXMgPSBTaG9lU2l6ZXM7XG4gICAgICAgICAgICAgICAgYW5ndWxhci5tb2R1bGUoJ2FwcC5yZW50YWwnKVxuICAgICAgICAgICAgICAgICAgICAuc2VydmljZSgnc2hvZVNpemVzJywgU2hvZVNpemVzKTtcbiAgICAgICAgICAgIH0pKFNlcnZpY2VzID0gUmVudGFsLlNlcnZpY2VzIHx8IChSZW50YWwuU2VydmljZXMgPSB7fSkpO1xuICAgICAgICB9KShSZW50YWwgPSBBcHAuUmVudGFsIHx8IChBcHAuUmVudGFsID0ge30pKTtcbiAgICB9KShBcHAgPSBTa2lSZXNvcnQuQXBwIHx8IChTa2lSZXNvcnQuQXBwID0ge30pKTtcbn0pKFNraVJlc29ydCB8fCAoU2tpUmVzb3J0ID0ge30pKTtcbi8vLyA8cmVmZXJlbmNlIHBhdGg9Jy4uLy4uLy4uLy4uLy4uL3R5cGluZ3MvYnJvd3Nlci5kLnRzJy8+XG52YXIgU2tpUmVzb3J0O1xuKGZ1bmN0aW9uIChTa2lSZXNvcnQpIHtcbiAgICB2YXIgQXBwO1xuICAgIChmdW5jdGlvbiAoQXBwKSB7XG4gICAgICAgIHZhciBSZW50YWw7XG4gICAgICAgIChmdW5jdGlvbiAoUmVudGFsKSB7XG4gICAgICAgICAgICB2YXIgU2VydmljZXM7XG4gICAgICAgICAgICAoZnVuY3Rpb24gKFNlcnZpY2VzKSB7XG4gICAgICAgICAgICAgICAgJ3VzZSBzdHJpY3QnO1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFNraVNpemVzKCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVzdWx0ID0gW107XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAxMTU7IGkgPD0gMjAwOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogaSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbDogaSArICcgaW4nXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRCeUlkOiBmdW5jdGlvbiAoaWQpIHsgcmV0dXJuICh7IGlkOiBpZCwgbGFiZWw6IGlkICsgJyBpbicgfSk7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGw6IHJlc3VsdFxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBTZXJ2aWNlcy5Ta2lTaXplcyA9IFNraVNpemVzO1xuICAgICAgICAgICAgICAgIGFuZ3VsYXIubW9kdWxlKCdhcHAucmVudGFsJylcbiAgICAgICAgICAgICAgICAgICAgLnNlcnZpY2UoJ3NraVNpemVzJywgU2tpU2l6ZXMpO1xuICAgICAgICAgICAgfSkoU2VydmljZXMgPSBSZW50YWwuU2VydmljZXMgfHwgKFJlbnRhbC5TZXJ2aWNlcyA9IHt9KSk7XG4gICAgICAgIH0pKFJlbnRhbCA9IEFwcC5SZW50YWwgfHwgKEFwcC5SZW50YWwgPSB7fSkpO1xuICAgIH0pKEFwcCA9IFNraVJlc29ydC5BcHAgfHwgKFNraVJlc29ydC5BcHAgPSB7fSkpO1xufSkoU2tpUmVzb3J0IHx8IChTa2lSZXNvcnQgPSB7fSkpO1xuIl0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
